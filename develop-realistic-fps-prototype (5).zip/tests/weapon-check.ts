import * as THREE from 'three';
import { createEnvironmentMap } from '../src/game/textures';
import { AR_RELOAD_TIMING, createFirstPersonWeapons, updateWeaponAnimation, type ViewmodelAnimParams, type WeaponRig } from '../src/game/weapons';
import { FirstPersonArms } from '../src/game/fpArms';
import { TacticalOperator, decodeXbotPayload } from '../src/game/playerModel';
import { WEAPON_SPECS, type WeaponId } from '../src/game/types';
import { XBOT_BONES } from '../src/game/xbotModelData';

interface RenderOptions {
  weapon?: WeaponId;
  view?: 'product' | 'side' | 'magazine' | 'first' | 'ads' | 'third' | 'third-side' | 'third-rear' | 'third-front';
  reload?: number;
  dry?: boolean;
  shot?: boolean;
  pitch?: number;
  ads?: number;
  crouch?: number;
  sprint?: boolean;
  yaw?: number;
  external?: boolean;
}

const renderer = new THREE.WebGLRenderer({ antialias: true, preserveDrawingBuffer: true });
renderer.setSize(1280, 800);
renderer.setPixelRatio(1);
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 1.08;
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFShadowMap;
document.body.appendChild(renderer.domElement);
const scene = new THREE.Scene();
scene.background = new THREE.Color(0x46515e);
scene.environment = createEnvironmentMap(renderer);
scene.add(new THREE.HemisphereLight(0xe2efff, 0x303039, 1.0));
const key = new THREE.DirectionalLight(0xffefd8, 2.8);
key.position.set(3, 5, 4);
scene.add(key);
const rim = new THREE.DirectionalLight(0xafcaff, 1.2);
rim.position.set(-4, 2, -3);
scene.add(rim);
const floor = new THREE.Mesh(new THREE.PlaneGeometry(20, 20), new THREE.MeshStandardMaterial({ color: 0x30383e, roughness: 0.95 }));
floor.rotation.x = -Math.PI / 2;
floor.position.y = -0.3;
scene.add(floor);
const camera = new THREE.PerspectiveCamera(38, 1280 / 800, 0.01, 50);
scene.add(camera);
const weapons = createFirstPersonWeapons();
scene.add(weapons.ar.root, weapons.pistol.root);
const arms = new FirstPersonArms();
scene.add(arms.root);
const operator = new TacticalOperator();
scene.add(operator.root);

function frame(weapon: WeaponId, options: RenderOptions = {}): ViewmodelAnimParams {
  return {
    dt: 1 / 60, time: 0, adsAmount: options.view === 'ads' ? 1 : 0,
    isSprinting: false, moveSpeedNorm: 0, grounded: true, verticalVel: 0, landDip: 0,
    mouseSwayX: 0, mouseSwayY: 0, recoilPosZ: options.shot ? 0.04 : 0,
    recoilPitch: options.shot ? 0.055 : 0, recoilRoll: 0,
    boltCycle: options.shot ? 1 : 0, ammoInMag: options.dry ? 0 : WEAPON_SPECS[weapon].magSize,
    isReloading: options.reload !== undefined, reloadProgress: options.reload ?? 0,
    isDryReload: !!options.dry, firstPerson: options.view === 'first' || options.view === 'ads',
    equipAlpha: 1, muzzleFlashTimer: 0,
  };
}

function render(options: RenderOptions = {}) {
  const weapon = options.weapon ?? 'ar';
  const view = options.view ?? 'product';
  const rig = weapons[weapon];
  for (const id of ['ar', 'pistol'] as WeaponId[]) weapons[id].root.visible = id === weapon;
  const thirdPerson = view.startsWith('third');
  operator.root.visible = thirdPerson;
  operator.root.rotation.y = options.yaw ?? 0;
  arms.root.visible = view === 'first' || view === 'ads';
  const p = frame(weapon, options);
  updateWeaponAnimation(rig, p);
  if (view === 'first' || view === 'ads') {
    arms.update(rig);
    camera.position.set(0, 0, 0);
    camera.rotation.set(0, 0, 0);
    camera.fov = view === 'ads' ? 42 : 50;
    floor.visible = false;
  } else if (thirdPerson) {
    weapons.ar.root.visible = weapons.pistol.root.visible = false;
    for (let i = 0; i < 30; i++) operator.update({
      dt: 1 / 60, time: i / 60, speed: options.sprint ? 6.8 : 0, maxSprintSpeed: 7.2, forwardMove: options.sprint ? 1 : 0, strafeMove: 0,
      isSprinting: !!options.sprint, crouchAmount: options.crouch ?? 0, grounded: true, verticalVel: 0, landImpact: 0,
      aimPitch: options.pitch ?? 0, adsAmount: options.ads ?? 0, recoilKick: options.shot ? 1 : 0,
      isReloading: options.reload !== undefined, reloadProgress: options.reload ?? 0,
      activeWeapon: weapon, firstPersonHideUpper: !!options.external, isDryReload: !!options.dry,
      ammoInMag: options.dry ? 0 : WEAPON_SPECS[weapon].magSize, boltCycle: options.shot ? 1 : 0,
    });
    if (view === 'third-side') {
      camera.position.set(1.9, 1.43, -0.25);
      camera.lookAt(0, 1.35, -0.22);
      camera.fov = 36;
    } else if (view === 'third-rear') {
      camera.position.set(0.62, 1.57, 1.8);
      camera.lookAt(0, 1.37, -0.28);
      camera.fov = 39;
    } else if (view === 'third-front') {
      camera.position.set(-1.15, 1.55, -1.55);
      camera.lookAt(0, 1.36, -0.26);
      camera.fov = 38;
    } else {
      camera.position.set(1.4, 1.51, -1.6);
      camera.lookAt(0, 1.35, -0.27);
      camera.fov = 44;
    }
    floor.visible = true;
    floor.position.y = -0.003;
  } else {
    rig.root.position.set(0, 0, 0);
    rig.root.rotation.set(0, 0, 0);
    camera.fov = 36;
    floor.visible = false;
    if (view === 'magazine') {
      camera.position.set(0.31, -0.045, 0.15);
      camera.lookAt(0, -0.092, weapon === 'ar' ? -0.05 : 0.055);
    } else if (view === 'side') {
      const d = weapon === 'ar' ? 1.25 : 0.42;
      camera.position.set(-d, d * 0.10, 0.02);
      camera.lookAt(0, -0.045, weapon === 'ar' ? -0.11 : -0.02);
    } else {
      const d = weapon === 'ar' ? 1.16 : 0.4;
      camera.position.set(d * 0.72, d * 0.26, d * 0.50);
      camera.lookAt(0, -0.035, weapon === 'ar' ? -0.12 : -0.02);
    }
  }
  camera.updateProjectionMatrix();
  scene.updateMatrixWorld(true);
  if (thirdPerson && options.external) operator.setExternalCameraPass(true);
  renderer.render(scene, camera);
  if (thirdPerson && options.external) operator.setExternalCameraPass(false);
  return { calls: renderer.info.render.calls, triangles: renderer.info.render.triangles };
}

function inspectThirdPerson() {
  const bodyRig = operator as unknown as {
    tpWeapons: Record<WeaponId, WeaponRig>;
    bonesByName: Map<string, THREE.Bone>;
    modelWrap: THREE.Group;
    shoulderSurface: THREE.SkinnedMesh;
    shoulderContactVertex: number;
  };
  const rig = bodyRig.tpWeapons.ar;
  scene.updateMatrixWorld(true);
  const pad = rig.stockPad!;
  pad.geometry.computeBoundingBox();
  const padBack = pad.localToWorld(new THREE.Vector3(0, 0, pad.geometry.boundingBox!.max.z + 0.001));
  const surfaceAnchor = bodyRig.shoulderSurface.getVertexPosition(bodyRig.shoulderContactVertex, new THREE.Vector3())
    .applyMatrix4(bodyRig.shoulderSurface.matrixWorld);
  const localOffset = operator.root.worldToLocal(padBack.clone()).sub(operator.root.worldToLocal(surfaceAnchor.clone()));
  const padInverse = pad.matrixWorld.clone().invert();
  const point = new THREE.Vector3();
  const bounds = pad.geometry.boundingBox!;
  let torsoVerticesInPad = 0;
  const padIntersections: { mesh: string; index: number; bind: number[]; local: number[]; bone: string }[] = [];
  for (const meshName of ['Beta_Surface', 'Beta_Joints']) {
    const skin = bodyRig.modelWrap.getObjectByName(meshName) as THREE.SkinnedMesh;
    const position = skin.geometry.getAttribute('position');
    const skinIndex = skin.geometry.getAttribute('skinIndex');
    const skinWeight = skin.geometry.getAttribute('skinWeight');
    for (let i = 0; i < position.count; i++) {
      const x = position.getX(i);
      const y = position.getY(i);
      if (x > -0.03 || x < -0.23 || y < 1.25 || y > 1.7) continue;
      const influences = [skinWeight.getX(i), skinWeight.getY(i), skinWeight.getZ(i), skinWeight.getW(i)];
      const indices = [skinIndex.getX(i), skinIndex.getY(i), skinIndex.getZ(i), skinIndex.getW(i)];
      const max = influences.indexOf(Math.max(...influences));
      const name = XBOT_BONES[indices[max]].name;
      if (!/Spine|Neck|Head|RightShoulder/.test(name)) continue;
      skin.getVertexPosition(i, point).applyMatrix4(skin.matrixWorld).applyMatrix4(padInverse);
      if (bounds.containsPoint(point)) {
        torsoVerticesInPad++;
        padIntersections.push({ mesh: meshName, index: i, bind: [x, y, position.getZ(i)], local: point.toArray(), bone: name });
      }
    }
  }
  const shoulder = bodyRig.bonesByName.get('mixamorig:RightArm')!.getWorldPosition(new THREE.Vector3());
  const surface = bodyRig.modelWrap.getObjectByName('Beta_Surface') as THREE.SkinnedMesh;
  const ray = new THREE.Raycaster(new THREE.Vector3(padBack.x, padBack.y, padBack.z - 2), new THREE.Vector3(0, 0, 1));
  const hits = ray.intersectObject(surface, false);
  const firstHit = hits[0]?.point;
  const wrist = bodyRig.bonesByName.get('mixamorig:LeftHand')!.getWorldPosition(new THREE.Vector3());
  const handTarget = rig.leftHandTarget.getWorldPosition(new THREE.Vector3());
  const chargingLatch = rig.chargingOrHammer.localToWorld(new THREE.Vector3(-0.025, 0.027, 0.133));
  const tips = ['Index', 'Middle', 'Thumb'].map((finger) =>
    bodyRig.bonesByName.get(`mixamorig:LeftHand${finger}4`)!.getWorldPosition(new THREE.Vector3()).distanceTo(chargingLatch));
  const fingertipLocal = Object.fromEntries(['Index', 'Middle', 'Thumb'].map((finger) => {
    const bone = bodyRig.bonesByName.get(`mixamorig:LeftHand${finger}4`)!;
    return [finger, rig.gunBody.worldToLocal(bone.getWorldPosition(new THREE.Vector3())).toArray()];
  }));
  return {
    padBack: padBack.toArray(),
    shoulder: shoulder.toArray(),
    bodyFront: firstHit?.toArray() ?? null,
    frontGap: firstHit ? firstHit.z - padBack.z : null,
    shoulderSurface: surfaceAnchor.toArray(),
    shoulderLocalOffset: localOffset.toArray(),
    torsoVerticesInPad,
    padIntersections,
    handError: wrist.distanceTo(handTarget),
    handTarget: handTarget.toArray(),
    chargingOffset: rig.chargingOrHammer.position.z,
    closestFingerToLatch: Math.min(...tips),
    fingertipLocal,
    latchLocal: rig.gunBody.worldToLocal(chargingLatch.clone()).toArray(),
  };
}

function inspectFirstPersonCharge() {
  const rig = weapons.ar;
  const latch = rig.chargingOrHammer.localToWorld(new THREE.Vector3(-0.025, 0.027, 0.133));
  const fingertips = ['Index', 'Middle', 'Thumb'].map((finger) => {
    const bone = arms.root.getObjectByName(`mixamorig:LeftHand${finger}4`)!;
    return bone.getWorldPosition(new THREE.Vector3()).distanceTo(latch);
  });
  return { closestFingerToLatch: Math.min(...fingertips), chargingOffset: rig.chargingOrHammer.position.z };
}

function inspectStockIntersections() {
  const bodyRig = operator as unknown as { tpWeapons: Record<WeaponId, WeaponRig>; modelWrap: THREE.Group };
  const stock = bodyRig.tpWeapons.ar.stockAssembly!;
  stock.updateWorldMatrix(true, true);
  const parts: { mesh: THREE.Mesh; bounds: THREE.Box3 }[] = [];
  const originalSides = new Map<THREE.Material, THREE.Side>();
  stock.traverse((object) => {
    if (!(object instanceof THREE.Mesh) || Array.isArray(object.material)) return;
    object.geometry.computeBoundingBox();
    const material = object.material;
    parts.push({ mesh: object, bounds: object.geometry.boundingBox!.clone().applyMatrix4(object.matrixWorld) });
    if (!originalSides.has(material)) originalSides.set(material, material.side);
    material.side = THREE.DoubleSide;
  });
  const position = new THREE.Vector3();
  const direction = new THREE.Vector3(1, 1, 1).normalize();
  const ray = new THREE.Raycaster();
  let inside = 0;
  for (const meshName of ['Beta_Surface', 'Beta_Joints']) {
    const skin = bodyRig.modelWrap.getObjectByName(meshName) as THREE.SkinnedMesh;
    const positions = skin.geometry.getAttribute('position');
    const weights = skin.geometry.getAttribute('skinWeight');
    const bones = skin.geometry.getAttribute('skinIndex');
    for (let i = 0; i < positions.count; i++) {
      const x = positions.getX(i);
      const y = positions.getY(i);
      if (x < -0.23 || x > -0.03 || y < 1.25 || y > 1.7) continue;
      const influence = [weights.getX(i), weights.getY(i), weights.getZ(i), weights.getW(i)];
      const boneIds = [bones.getX(i), bones.getY(i), bones.getZ(i), bones.getW(i)];
      const dominant = XBOT_BONES[boneIds[influence.indexOf(Math.max(...influence))]].name;
      if (!/Spine|Neck|Head|RightShoulder/.test(dominant)) continue;
      skin.getVertexPosition(i, position).applyMatrix4(skin.matrixWorld);
      for (const part of parts) {
        if (!part.bounds.containsPoint(position)) continue;
        ray.set(position, direction);
        const hits = ray.intersectObject(part.mesh, false);
        let count = 0;
        let last = -1;
        for (const hit of hits) {
          // Adjacent triangles can report the same surface hit twice.
          if (hit.distance > 0.00001 && hit.distance - last > 0.00002) {
            count++;
            last = hit.distance;
          }
        }
        if (count % 2 === 1) inside++;
      }
    }
  }
  for (const [material, side] of originalSides) material.side = side;
  return inside;
}

function check() {
  const results: { test: string; pass: boolean; value?: number | string }[] = [];
  const assert = (test: string, pass: boolean, value?: number | string) => results.push({ test, pass, value });
  for (const id of ['ar', 'pistol'] as WeaponId[]) {
    const rig = weapons[id];
    assert(`${id} magazine uses weapon-local parent`, rig.magGroup.parent === rig.gunBody);
    rig.magazineBody.geometry.computeBoundingBox();
    const bodyBox = rig.magazineBody.geometry.boundingBox!;
    assert(`${id} magazine is a solid full-length body`, bodyBox.max.y - bodyBox.min.y > 0.09);
    assert(`${id} magazine has UVs`, !!rig.magazineBody.geometry.getAttribute('uv'));
    for (const test of [
      { view: 'first' }, { view: 'ads' }, { view: 'first', shot: true },
      { reload: 0.66 }, { reload: 0.68 }, { reload: 0.9, dry: true }, {},
    ] as RenderOptions[]) {
      updateWeaponAnimation(rig, frame(id, test));
      if (test.reload === 0.66 && id === 'ar') continue;
      const error = rig.magGroup.position.distanceTo(rig.magazineSocket.position);
      assert(`${id} seated after ${JSON.stringify(test)}`, error < 0.00001, error);
    }
    // Both rig and magazine use the same moving parent during extraction.
    updateWeaponAnimation(rig, frame(id, { reload: 0.53 }));
    rig.root.updateWorldMatrix(true, true);
    const handWorld = rig.leftHandTarget.getWorldPosition(new THREE.Vector3());
    const magWorld = rig.magazineGrip.getWorldPosition(new THREE.Vector3());
    assert(`${id} insertion hand follows magazine`, handWorld.distanceTo(magWorld) < 0.00001, handWorld.distanceTo(magWorld));
    updateWeaponAnimation(rig, frame(id));
    assert(`${id} interrupted reload reseats magazine`, rig.magGroup.position.distanceTo(rig.magazineSocket.position) < 0.00001);
    const position = rig.magazineBody.geometry.getAttribute('position');
    const normal = rig.magazineBody.geometry.getAttribute('normal');
    let outward = 0, tested = 0;
    for (let i = 0; i < position.count; i++) {
      if (Math.abs(position.getX(i)) < 0.009 || Math.abs(normal.getX(i)) < 0.5) continue;
      tested++;
      if (normal.getX(i) * position.getX(i) > 0) outward++;
    }
    assert(`${id} magazine normals point outward`, tested > 0 && outward / tested > 0.98, outward / tested);
  }
  const ar = weapons.ar;
  const yTop = ar.magazineBody.geometry.boundingBox!.max.y + ar.magazineSocket.position.y;
  const lipY = -0.074;
  assert('AR magazine extends inside magwell (no gap)', yTop > lipY + 0.02, yTop - lipY);
  const well = ar.gunBody.getObjectByName('ar15-magwell') as THREE.Mesh;
  well.geometry.computeBoundingBox();
  const wellTop = well.geometry.boundingBox!.max.y + well.position.y;
  assert('AR magwell touches receiver (not a floating assembly)', wellTop >= -0.007, wellTop);
  const pistol = weapons.pistol;
  assert('Glock magazine socket is not double-offset by grip', pistol.magazineSocket.position.z < 0.07);

  // Rigid gun meshes have no NaN vertices or normals, including all bevels/cutouts.
  for (const id of ['ar', 'pistol'] as WeaponId[]) {
    let bad = 0;
    weapons[id].root.traverse((o) => {
      if (!(o instanceof THREE.Mesh)) return;
      for (const attribute of ['position', 'normal']) {
        const a = o.geometry.getAttribute(attribute);
        if (!a) continue;
        for (let i = 0; i < a.array.length; i++) if (!Number.isFinite(a.array[i])) bad++;
      }
    });
    assert(`${id} geometry has finite positions/normals`, bad === 0, bad);
  }
  const arCore = weapons.ar.gunBody.getObjectByName('ar15-upper-core') as THREE.Mesh;
  arCore.geometry.computeBoundingBox();
  assert('AR upper receiver is solid across full width', arCore.geometry.boundingBox!.max.x - arCore.geometry.boundingBox!.min.x > 0.035);

  const bodyRig = operator as unknown as {
    tpWeapons: Record<WeaponId, WeaponRig>;
    bonesByName: Map<string, THREE.Bone>;
  };
  for (const weapon of ['ar', 'pistol'] as WeaponId[]) {
    for (const pitch of [-0.65, 0, 0.65]) {
      render({ weapon, view: 'third', pitch });
      const rig = bodyRig.tpWeapons[weapon];
      for (const side of ['Left', 'Right'] as const) {
        const hand = bodyRig.bonesByName.get(`mixamorig:${side}Hand`)!;
        const target = side === 'Left' ? rig.leftHandTarget : rig.rightHandTarget;
        const error = hand.getWorldPosition(new THREE.Vector3()).distanceTo(target.getWorldPosition(new THREE.Vector3()));
        assert(`${weapon} third-person ${side} grip at pitch ${pitch}`, error < 0.025, error);
      }
      assert(`${weapon} third-person magazine stays seated at pitch ${pitch}`, rig.magGroup.position.distanceTo(rig.magazineSocket.position) < 0.00001);
    }
  }

  for (const dry of [false, true]) {
    const rig = weapons.ar;
    const at = (t: number) => {
      updateWeaponAnimation(rig, frame('ar', { reload: t, dry }));
      return { handle: rig.chargingOrHammer.position.z, hand: rig.leftHandTarget.position.clone(), bolt: rig.boltOrSlide.position.z };
    };
    const reached = at(AR_RELOAD_TIMING.handleReached);
    const pulled = at(AR_RELOAD_TIMING.handlePulled);
    const released = at(AR_RELOAD_TIMING.handleReleased);
    assert(`AR ${dry ? 'empty' : 'partial'} reload reaches the rear handle`, reached.hand.z > 0.15 && reached.hand.x < -0.05);
    assert(`AR ${dry ? 'empty' : 'partial'} reload pulls the handle`, pulled.handle > 0.04, pulled.handle);
    assert(`AR ${dry ? 'empty' : 'partial'} hand follows the handle`, Math.abs((pulled.hand.z - reached.hand.z) - pulled.handle) < 0.0001);
    assert(`AR ${dry ? 'empty' : 'partial'} bolt moves rearward`, pulled.bolt > 0.045, pulled.bolt);
    assert(`AR ${dry ? 'empty' : 'partial'} handle and bolt return`, released.handle === 0 && released.bolt === 0);
    updateWeaponAnimation(rig, frame('ar'));
    assert(`AR ${dry ? 'empty' : 'partial'} canceled reload resets handle`, rig.chargingOrHammer.position.z === 0);
    for (const t of [AR_RELOAD_TIMING.handleReached, 0.8, AR_RELOAD_TIMING.handlePulled, 0.86]) {
      render({ weapon: 'ar', view: 'first', reload: t, dry });
      const first = inspectFirstPersonCharge();
      assert(`AR ${dry ? 'empty' : 'partial'} first-person fingertips stay on rear latch at ${t}`, first.closestFingerToLatch < 0.012, first.closestFingerToLatch);
      render({ weapon: 'ar', view: 'third-side', reload: t, dry });
      const third = inspectThirdPerson();
      assert(`AR ${dry ? 'empty' : 'partial'} third-person fingertips stay on rear latch at ${t}`, third.closestFingerToLatch < 0.012, third.closestFingerToLatch);
    }
  }

  for (const pose of [
    { pitch: 0, ads: 0 }, { pitch: 0, ads: 1 }, { pitch: -0.65, ads: 1 },
    { pitch: 0.65, ads: 1 }, { pitch: 1.1, ads: 1 }, { pitch: -0.65, crouch: 1 },
    { pitch: 0.65, yaw: 0.8 }, { reload: 0.67, dry: true }, { reload: 0.77, dry: true },
    { reload: 0.83, dry: true }, { reload: 0.87, dry: true }, { reload: 0.93, dry: true },
    { external: true, pitch: 0.65 },
    { sprint: true },
  ]) {
    render({ weapon: 'ar', view: 'third-side', ...pose });
    const info = inspectThirdPerson();
    const offset = info.shoulderLocalOffset;
    const distance = Math.hypot(...offset);
    assert(`AR stock stays close to shoulder ${JSON.stringify(pose)}`, offset[2] < 0 && distance < 0.085, distance);
    assert(`AR stock pad does not intersect torso vertices ${JSON.stringify(pose)}`, info.torsoVerticesInPad === 0, info.torsoVerticesInPad);
    const insideStock = inspectStockIntersections();
    assert(`AR complete stock avoids torso ${JSON.stringify(pose)}`, insideStock === 0, insideStock);
    assert(`AR hand reaches its target ${JSON.stringify(pose)}`, info.handError < 0.03, info.handError);
  }
  return results;
}

const api = { ready: false, render, check, weapons, operator, inspectThirdPerson, inspectFirstPersonCharge, three: THREE };
(window as unknown as { weaponCheck: typeof api }).weaponCheck = api;
Promise.all([arms.whenReady, decodeXbotPayload()]).then(() => {
  api.ready = true;
  render();
});