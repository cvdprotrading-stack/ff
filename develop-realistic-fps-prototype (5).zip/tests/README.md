# Weapon Regression Checks

Start Vite on port 5333, then run `tests/weapons.browser.cjs` with Playwright available to Node. Set `TEST_URL` for another port, or `SHOTS_DIR` to change the screenshot directory.

The browser harness at `/tests/weapon-check.html` loads the production model builders, animations, first-person arms, and third-person player. It checks magazine seating, receiver contact, UVs, outward-facing normals, hand-to-magazine contact during insertion, interrupted reloads, and third-person grip alignment. It checks the rifle's rear charging handle and fingertip contact in both perspectives, plus butt-pad clearance against the animated shoulder and torso. It captures product views, ADS, reload stages, and full-body views for visual inspection.

`tests/game-weapons.browser.cjs` drives the game's actual controls through firing, reloads, weapon switching, third-person view, and DVR playback. It uses fixed simulation steps because software-rendered headless WebGL is much slower than a hardware GPU. This verifies gameplay state and rendering, not real-time frame rate.

The tests do not add code to the production bundle.