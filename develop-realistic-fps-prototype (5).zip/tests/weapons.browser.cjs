/* Run against Vite: NODE_PATH=/path/to/playwright/node_modules node tests/weapons.browser.cjs */
const { chromium } = require('playwright');
const fs = require('node:fs');

(async () => {
  const browser = await chromium.launch({ args: ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
  const page = await browser.newPage({ viewport: { width: 1280, height: 800 }, deviceScaleFactor: 1 });
  const errors = [];
  page.on('pageerror', (error) => errors.push(error.message));
  page.on('console', (message) => {
    if (message.type() === 'error') errors.push(message.text());
  });
  await page.goto(`${process.env.TEST_URL || 'http://127.0.0.1:5333'}/tests/weapon-check.html`, { waitUntil: 'networkidle' });
  await page.waitForFunction(() => window.weaponCheck?.ready, null, { timeout: 120000 });
  const results = await page.evaluate(() => window.weaponCheck.check());
  console.log(JSON.stringify(results, null, 2));
  const out = process.env.SHOTS_DIR || 'test-results/weapons';
  fs.mkdirSync(out, { recursive: true });
  if (!process.env.CHECK_ONLY) {
    for (const weapon of ['ar', 'pistol']) {
      for (const view of ['product', 'side', 'magazine', 'first', 'ads', 'third']) {
        const stats = await page.evaluate((options) => window.weaponCheck.render(options), { weapon, view });
        await page.screenshot({ path: `${out}/${weapon}-${view}.png`, timeout: 60000 });
        console.log(weapon, view, stats);
      }
      for (const reload of [0.25, 0.53, 0.68, 0.77, 0.83, 0.87]) {
        await page.evaluate((options) => window.weaponCheck.render(options), { weapon, view: 'first', reload, dry: true });
        await page.screenshot({ path: `${out}/${weapon}-reload-${reload}.png`, timeout: 60000 });
      }
    }
    for (const view of ['third-side', 'third-front', 'third-rear']) {
      await page.evaluate((options) => window.weaponCheck.render(options), { weapon: 'ar', view, reload: 0.83, dry: true });
      await page.screenshot({ path: `${out}/ar-rear-charge-${view}.png`, timeout: 60000 });
    }
  }
  await browser.close();
  if (errors.length || results.some((r) => !r.pass)) {
    console.error('Failed checks:', results.filter((r) => !r.pass), errors);
    process.exitCode = 1;
  } else {
    console.log(`PASS: ${results.length} weapon checks; no browser errors.`);
  }
})().catch((error) => { console.error(error); process.exitCode = 1; });