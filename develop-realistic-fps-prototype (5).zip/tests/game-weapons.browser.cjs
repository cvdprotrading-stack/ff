// Deterministic input regression: software WebGL is not a real-time performance benchmark.
// The production engine still receives keyboard/mouse events; only the frame clock is driven here.
const { chromium } = require('playwright');
const assert = require('node:assert/strict');
require('node:fs').mkdirSync('test-results/weapons', { recursive: true });
(async()=>{
 const browser=await chromium.launch({args:['--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader','--ignore-gpu-blocklist']});
 const page=await browser.newPage({viewport:{width:1100,height:700}});
 const errors=[];
 page.on('pageerror',e=>{errors.push(e.message);console.log('PAGE ERROR',e.message)});
 await page.goto((process.env.TEST_URL || 'http://127.0.0.1:5333') + '/',{waitUntil:'domcontentloaded'});
 await page.evaluate(async()=>{
   const {WarzoneEngine}=await import('/src/game/WarzoneEngine.ts');
   const update=WarzoneEngine.prototype.updateGameplay;
   WarzoneEngine.prototype.updateGameplay=function(dt){window.__engine=this;return update.call(this,dt);};
 });
 await page.getByRole('button',{name:/DEPLOY TO BLOCKOUT/}).click();
 await page.waitForFunction(()=>!!window.__engine,null,{polling:100,timeout:60000});
 await page.evaluate(()=>cancelAnimationFrame(window.__engine.animFrameId));
 const step=n=>page.evaluate(count=>{
   const e=window.__engine;
   cancelAnimationFrame(e.animFrameId);
   for(let i=0;i<count;i++){e.totalTime+=1/60;e.updateGameplay(1/60);e.updateVfxAndTargets(1/60);}
   e.emitHudState();
   return {...e.ammoInMag};
 },n);
 const shot=async(name)=>{
   await page.evaluate(()=>window.__engine.renderFrame());
   await page.screenshot({path:`test-results/weapons/${name}.png`,timeout:90000});
 };
 await step(80);
 await page.evaluate(()=>window.dispatchEvent(new MouseEvent('mousedown',{button:0})));
 let state=await step(12);
 await page.evaluate(()=>window.dispatchEvent(new MouseEvent('mouseup',{button:0})));
 assert(state.ar<30);console.log('AR firing:',state.ar);
  await page.keyboard.press('KeyR');await step(50);await shot('game-ar-reload-fixed');
  await step(51);
  const charging = await page.evaluate(() => ({
    progress: window.__engine.reloadElapsed / window.__engine.reloadDuration,
    firstPerson: window.__engine.fpWeapons.ar.chargingOrHammer.position.z,
    thirdPerson: window.__engine.operator.tpWeapons.ar.chargingOrHammer.position.z,
  }));
  assert(charging.firstPerson > 0.03 && Math.abs(charging.firstPerson - charging.thirdPerson) < 0.0001);
  console.log('Rear charging handle in both views:', charging);
  await shot('game-ar-rear-charge');
  state=await step(50);assert.equal(state.ar,30);console.log('AR reload:',state.ar);
  // Exercise the empty-magazine path independently of the partial reload.
  await page.evaluate(() => { window.__engine.ammoInMag.ar = 0; });
  await page.keyboard.press('KeyR');
  await step(126);
  const dryCharge = await page.evaluate(() => ({
    dry: window.__engine.isDryReload,
    firstPerson: window.__engine.fpWeapons.ar.chargingOrHammer.position.z,
    thirdPerson: window.__engine.operator.tpWeapons.ar.chargingOrHammer.position.z,
    bolt: window.__engine.fpWeapons.ar.boltOrSlide.position.z,
  }));
  assert(dryCharge.dry && dryCharge.firstPerson > 0.03 && dryCharge.bolt > 0.04);
  assert(Math.abs(dryCharge.firstPerson - dryCharge.thirdPerson) < 0.0001);
  console.log('Empty reload rear charge:', dryCharge);
  state=await step(50);assert.equal(state.ar,30);
 await page.evaluate(()=>window.dispatchEvent(new MouseEvent('mousedown',{button:2})));
 await step(45);await shot('game-ar-ads-fixed');
 await page.evaluate(()=>window.dispatchEvent(new MouseEvent('mouseup',{button:2})));
 await page.keyboard.press('Digit2');await step(90);
 await page.evaluate(()=>window.dispatchEvent(new MouseEvent('mousedown',{button:0})));
 state=await step(12);await page.evaluate(()=>window.dispatchEvent(new MouseEvent('mouseup',{button:0})));
 assert.equal(state.pistol,16);console.log('Glock firing:',state.pistol);
 await page.keyboard.press('KeyR');await step(45);await shot('game-glock-reload-fixed');
 state=await step(100);assert.equal(state.pistol,17);console.log('Glock reload:',state.pistol);
 await page.keyboard.press('KeyV');await step(50);await shot('game-glock-third-fixed');
 await page.keyboard.press('Digit1');await step(90);await shot('game-ar-third-fixed');
 await page.keyboard.press('KeyV');await step(30);
 await page.keyboard.press('KeyH');
 for(let i=0;i<4;i++){await step(5);await page.evaluate(()=>window.__engine.renderFrame());}
 await page.keyboard.press('KeyI');
 await page.getByText('TACTICAL DVR // RECORDED CLIP PLAYBACK').waitFor({state:'visible'});
 await shot('game-recording-fixed');
 const recorded=await page.evaluate(()=>window.__engine.getRecordedFrames().length);
 assert(recorded>0);console.log('recorded frames:',recorded);
 assert.deepEqual(errors,[]);
 console.log('PASS gameplay input with deterministic simulation: fire, ADS, reload, weapon switch, third person and DVR.');
 await browser.close();
})().catch(e=>{console.error(e);process.exit(1)});
