import { useEffect, useRef, useState } from 'react';
import {
  Camera,
  Crosshair,
  Eye,
  Film,
  Pause,
  Play,
  RotateCcw,
  Shield,
  Target,
  Video,
  X,
} from 'lucide-react';
import { HudState, WEAPON_SPECS, WeaponId } from './game/types';
import { REC_FPS, REC_HEIGHT, REC_WIDTH, WarzoneEngine } from './game/WarzoneEngine';

const INITIAL_HUD: HudState = {
  activeWeapon: 'ar',
  ammoInMag: { ar: 30, pistol: 17 },
  ammoReserve: { ar: 150, pistol: 85 },
  isReloading: false,
  reloadProgress: 0,
  adsAmount: 0,
  crosshairSpread: 14,
  stance: 'STAND',
  elevationY: 0,
  cameraPerspective: 'FPV',
  hitmarkerTime: 0,
  isHeadshotHit: false,
  targetsHit: 0,
  pointerLocked: false,
  cameraPlaced: false,
  recordedFramesCount: 0,
  recordedDurationSec: 0,
  isViewingClip: false,
  cameraNotice: null,
};

export function App() {
  const mountRef = useRef<HTMLDivElement | null>(null);
  const engineRef = useRef<WarzoneEngine | null>(null);
  const pipCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const playbackCanvasRef = useRef<HTMLCanvasElement | null>(null);

  const [inMenu, setInMenu] = useState(true);
  const [selectedLoadout, setSelectedLoadout] = useState<WeaponId>('ar');
  const [hud, setHud] = useState<HudState>(INITIAL_HUD);

  // Clip Playback Viewer State ([I])
  const [clipPlaying, setClipPlaying] = useState(true);
  const [clipFrameIdx, setClipFrameIdx] = useState(0);
  const [clipSpeed, setClipSpeed] = useState<0.5 | 1>(1);

  useEffect(() => {
    if (!mountRef.current) return;
    const engine = new WarzoneEngine(mountRef.current, (nextHud) => {
      setHud(nextHud);
    });
    engineRef.current = engine;

    return () => {
      engine.dispose();
      engineRef.current = null;
    };
  }, []);

  // Connect live Picture-in-Picture canvas to the engine when camera is placed
  useEffect(() => {
    if (engineRef.current) {
      engineRef.current.setLivePipCanvas(hud.cameraPlaced ? pipCanvasRef.current : null);
    }
  }, [hud.cameraPlaced, inMenu]);

  // Reset playback to start when opening the [I] Clip Viewer
  useEffect(() => {
    if (hud.isViewingClip) {
      setClipFrameIdx(0);
      setClipPlaying(true);
    }
  }, [hud.isViewingClip]);

  // Advance clip frames during [I] Playback
  useEffect(() => {
    if (!hud.isViewingClip || !clipPlaying) return;
    const frames = engineRef.current?.getRecordedFrames() ?? [];
    if (frames.length <= 1) return;

    const intervalMs = 1000 / (REC_FPS * clipSpeed);
    const timer = window.setInterval(() => {
      setClipFrameIdx((prev) => (prev + 1) % frames.length);
    }, intervalMs);

    return () => window.clearInterval(timer);
  }, [hud.isViewingClip, clipPlaying, clipSpeed, hud.recordedFramesCount]);

  // Draw the current frame + cinema DVR overlay onto the [I] Playback Canvas
  useEffect(() => {
    if (!hud.isViewingClip || !playbackCanvasRef.current) return;
    const canvas = playbackCanvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const frames = engineRef.current?.getRecordedFrames() ?? [];
    const total = frames.length;
    const safeIdx = total > 0 ? Math.min(clipFrameIdx, total - 1) : 0;
    const frame = frames[safeIdx];

    ctx.fillStyle = '#090d12';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    if (frame) {
      ctx.drawImage(frame, 0, 0, canvas.width, canvas.height);
    }

    // Draw Tactical Camera Viewfinder Overlay on the playback monitor
    ctx.strokeStyle = 'rgba(248, 250, 252, 0.45)';
    ctx.lineWidth = 2;
    const m = 22;
    const b = 26;
    // 4 Corner Viewfinder Brackets
    [
      [m, m, 1, 1],
      [canvas.width - m, m, -1, 1],
      [m, canvas.height - m, 1, -1],
      [canvas.width - m, canvas.height - m, -1, -1],
    ].forEach(([cx, cy, dx, dy]) => {
      ctx.beginPath();
      ctx.moveTo(cx, cy + dy * b);
      ctx.lineTo(cx, cy);
      ctx.lineTo(cx + dx * b, cy);
      ctx.stroke();
    });

    // Center crosshair ticks
    const midX = canvas.width / 2;
    const midY = canvas.height / 2;
    ctx.strokeStyle = 'rgba(56, 189, 248, 0.4)';
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(midX - 16, midY);
    ctx.lineTo(midX - 5, midY);
    ctx.moveTo(midX + 5, midY);
    ctx.lineTo(midX + 16, midY);
    ctx.moveTo(midX, midY - 16);
    ctx.lineTo(midX, midY - 5);
    ctx.moveTo(midX, midY + 5);
    ctx.lineTo(midX, midY + 16);
    ctx.stroke();

    // Top-left REC PLAYBACK badge
    ctx.fillStyle = 'rgba(9, 13, 18, 0.72)';
    ctx.fillRect(m + 10, m + 10, 178, 28);
    ctx.fillStyle = clipPlaying ? '#ef4444' : '#f59e0b';
    ctx.beginPath();
    ctx.arc(m + 24, m + 24, 5.5, 0, Math.PI * 2);
    ctx.fill();

    ctx.fillStyle = '#f8fafc';
    ctx.font = 'bold 13px "JetBrains Mono", monospace';
    ctx.fillText(clipPlaying ? 'CAM-01 // PLAYBACK' : 'CAM-01 // PAUSED', m + 36, m + 28);

    // Bottom-right Timecode & Frame Counter
    const sec = (safeIdx / REC_FPS).toFixed(2).padStart(5, '0');
    const totSec = (total / REC_FPS).toFixed(2).padStart(5, '0');
    const timecodeText = `TC 00:${sec} / 00:${totSec}  [FRM ${String(safeIdx + 1).padStart(3, '0')}/${String(total).padStart(3, '0')}]`;
    ctx.fillStyle = 'rgba(9, 13, 18, 0.75)';
    ctx.fillRect(canvas.width - m - 310, canvas.height - m - 34, 300, 24);
    ctx.fillStyle = '#38bdf8';
    ctx.font = 'bold 12px "JetBrains Mono", monospace';
    ctx.fillText(timecodeText, canvas.width - m - 300, canvas.height - m - 18);
  }, [hud.isViewingClip, clipFrameIdx, clipPlaying, hud.recordedFramesCount]);

  // Keyboard navigation inside [I] Clip Viewer (Space = Play/Pause, Arrows = Scrub frames)
  useEffect(() => {
    if (!hud.isViewingClip) return;
    const onKey = (e: KeyboardEvent) => {
      const frames = engineRef.current?.getRecordedFrames() ?? [];
      if (frames.length === 0) return;
      if (e.code === 'Space') {
        e.preventDefault();
        setClipPlaying((p) => !p);
      } else if (e.code === 'ArrowRight') {
        e.preventDefault();
        setClipPlaying(false);
        setClipFrameIdx((prev) => (prev + 1) % frames.length);
      } else if (e.code === 'ArrowLeft') {
        e.preventDefault();
        setClipPlaying(false);
        setClipFrameIdx((prev) => (prev - 1 + frames.length) % frames.length);
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [hud.isViewingClip]);

  const handleSelectLoadout = (weapon: WeaponId) => {
    setSelectedLoadout(weapon);
    engineRef.current?.setMenuPreviewWeapon(weapon);
  };

  const handleDeploy = () => {
    setInMenu(false);
    engineRef.current?.deploy(selectedLoadout);
  };

  const handleReturnToMenu = () => {
    setInMenu(true);
    engineRef.current?.returnToMenu();
  };

  const spec = WEAPON_SPECS[hud.activeWeapon];
  const currentMag = hud.ammoInMag[hud.activeWeapon];
  const currentReserve = hud.ammoReserve[hud.activeWeapon];
  const isLowAmmo = currentMag <= Math.ceil(spec.magSize * 0.25);

  const hipCrosshairOpacity =
    hud.cameraPerspective === 'FPV'
      ? Math.max(0, 1 - hud.adsAmount * 1.45) * (hud.isReloading ? 0.25 : 0.92)
      : 0.9;

  return (
    <div className="relative w-screen h-screen overflow-hidden bg-[#0B0E11] select-none">
      {/* 3D WebGL Viewport */}
      <div ref={mountRef} className="absolute inset-0 w-full h-full" />

      {/* ADS Peripheral Tactical Focus Vignette */}
      {!inMenu && hud.adsAmount > 0.02 && (
        <div
          className="pointer-events-none absolute inset-0 ads-vignette transition-opacity duration-75"
          style={{ opacity: hud.adsAmount * 0.95 }}
        />
      )}

      {/* =========================================================
          PRE-DEPLOYMENT SIMPLE TACTICAL MENU (Live 3D Operator Behind)
         ========================================================= */}
      {inMenu && (
        <div className="absolute inset-0 z-20 flex flex-col justify-between p-7 md:p-12 bg-gradient-to-r from-[#090C10]/92 via-[#090C10]/62 to-transparent menu-scanline">
          {/* Top Status Bar */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <span className="inline-block w-2.5 h-2.5 rounded-full bg-amber-500 animate-pulse" />
              <span className="font-mono-tech text-xs tracking-[0.22em] text-slate-300 uppercase">
                IW-BLOCKOUT // STAGE 01 SANDBOX
              </span>
            </div>
            <div className="hidden sm:flex items-center gap-4 px-3.5 py-1.5 rounded border border-white/10 bg-black/45 backdrop-blur-md font-mono-tech text-xs text-slate-300">
              <span>PHYSICS: 1.0M JUMP CALIBRATED</span>
              <span className="text-white/25">|</span>
              <span className="text-amber-400">X-BOT ONLINE</span>
            </div>
          </div>

          {/* Left Tactical Loadout & Deploy Column */}
          <div className="max-w-md my-auto space-y-6">
            <div>
              <div className="inline-flex items-center gap-2 px-2.5 py-0.5 mb-2 rounded bg-amber-500/15 border border-amber-500/35 text-amber-400 font-mono-tech text-[11px] tracking-widest uppercase">
                Tactical FPS Prototype
              </div>
              <h1 className="font-tactical text-6xl md:text-7xl font-extrabold italic tracking-tight leading-none text-white uppercase">
                WARZONE <span className="text-amber-500">//</span> BLOCKOUT
              </h1>
              <p className="mt-2.5 text-sm text-slate-300/90 leading-relaxed">
                Clean architectural graybox arena with calibrated{' '}
                <span className="text-amber-400 font-semibold">Height 1.0M</span> jumpable boxes,{' '}
                <span className="text-rose-400 font-semibold">1+ Height</span> blocked cover, realistic
                weapons, optical ADS, and deployable{' '}
                <span className="text-sky-400 font-semibold">[H] Field Recording Camera</span> +{' '}
                <span className="text-emerald-400 font-semibold">[I] Clip Replay</span>.
              </p>
            </div>

            {/* Primary Weapon Preview Selector */}
            <div className="space-y-2.5">
              <div className="font-mono-tech text-[11px] tracking-[0.18em] text-slate-400 uppercase">
                Select Starting Weapon
              </div>
              <div className="grid grid-cols-2 gap-3">
                {(['ar', 'pistol'] as WeaponId[]).map((wId, idx) => {
                  const w = WEAPON_SPECS[wId];
                  const active = selectedLoadout === wId;
                  return (
                    <button
                      key={wId}
                      type="button"
                      onClick={() => handleSelectLoadout(wId)}
                      className={`text-left p-3.5 rounded border transition-all cursor-pointer backdrop-blur-md ${
                        active
                          ? 'bg-amber-500/15 border-amber-400 shadow-[0_0_20px_rgba(245,158,11,0.18)]'
                          : 'bg-[#11161D]/80 border-white/10 hover:border-white/25'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <span className="font-mono-tech text-[10px] px-1.5 py-0.5 rounded bg-white/10 text-slate-200">
                          SLOT {idx + 1}
                        </span>
                        <span className="font-mono-tech text-[10px] text-amber-400">{w.fireMode}</span>
                      </div>
                      <div className="mt-2 font-tactical text-xl font-bold tracking-wide text-white uppercase">
                        {w.code}
                      </div>
                      <div className="font-mono-tech text-[11px] text-slate-400">
                        {w.caliber} · {w.magSize} RDS
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Primary DEPLOY CTA */}
            <button
              type="button"
              onClick={handleDeploy}
              className="group w-full flex items-center justify-center gap-3 py-4 px-6 rounded bg-amber-500 hover:bg-amber-400 active:scale-[0.99] text-[#090C10] font-tactical text-2xl font-extrabold tracking-[0.1em] uppercase shadow-[0_0_30px_rgba(245,158,11,0.35)] transition-all cursor-pointer"
            >
              <Play className="w-5 h-5 fill-current" />
              <span>DEPLOY TO BLOCKOUT</span>
            </button>
          </div>

          {/* Bottom Concise Controls Legend */}
          <div className="flex flex-wrap items-center gap-x-5 gap-y-2 pt-3 border-t border-white/10 text-xs text-slate-300 font-mono-tech">
            <span>
              <kbd className="px-1.5 py-0.5 rounded bg-white/10 text-white">WASD</kbd> Move
            </span>
            <span>
              <kbd className="px-1.5 py-0.5 rounded bg-white/10 text-white">SHIFT</kbd> Tac-Sprint
            </span>
            <span>
              <kbd className="px-1.5 py-0.5 rounded bg-white/10 text-amber-400">SPACE</kbd> Jump (1.0M Box)
            </span>
            <span>
              <kbd className="px-1.5 py-0.5 rounded bg-white/10 text-white">C</kbd> Crouch
            </span>
            <span>
              <kbd className="px-1.5 py-0.5 rounded bg-white/10 text-white">LMB</kbd> Fire
            </span>
            <span>
              <kbd className="px-1.5 py-0.5 rounded bg-white/10 text-white">RMB</kbd> Scope / ADS
            </span>
            <span>
              <kbd className="px-1.5 py-0.5 rounded bg-white/10 text-white">R</kbd> Reload
            </span>
            <span>
              <kbd className="px-1.5 py-0.5 rounded bg-white/10 text-white">1 / 2</kbd> Weapons
            </span>
            <span>
              <kbd className="px-1.5 py-0.5 rounded bg-white/10 text-sky-400">V</kbd> 1st / 3rd Person
            </span>
            <span>
              <kbd className="px-1.5 py-0.5 rounded bg-rose-500/25 border border-rose-400/40 text-rose-300">H</kbd>{' '}
              Place Recording Cam
            </span>
            <span>
              <kbd className="px-1.5 py-0.5 rounded bg-emerald-500/25 border border-emerald-400/40 text-emerald-300">
                I
              </kbd>{' '}
              Watch Recorded Clip
            </span>
          </div>
        </div>
      )}

      {/* =========================================================
          IN-GAME WARZONE TACTICAL HUD
         ========================================================= */}
      {!inMenu && (
        <div className="pointer-events-none absolute inset-0 z-10">
          {/* Top-Center Minimal Calibration & Target Score Strip */}
          <div className="absolute top-4 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2">
            <div className="flex items-center gap-4 px-4 py-1.5 rounded bg-[#0B0E11]/75 border border-white/12 backdrop-blur-md font-mono-tech text-xs text-slate-200">
              <span className="flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-sm bg-amber-400" />
                <span>H: 1.0M JUMPABLE</span>
              </span>
              <span className="text-white/20">|</span>
              <span className="flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-sm bg-rose-500" />
                <span>1+ HEIGHT BLOCKED</span>
              </span>
              <span className="text-white/20">|</span>
              <span className="flex items-center gap-1.5 text-amber-400">
                <Target className="w-3.5 h-3.5" />
                <span>HITS: {hud.targetsHit}</span>
              </span>
            </div>

            {/* Camera Action Toast Banner */}
            {hud.cameraNotice && (
              <div className="flex items-center gap-2 px-3.5 py-1.5 rounded bg-rose-500/20 border border-rose-400/50 backdrop-blur-md font-mono-tech text-xs text-rose-200 shadow-lg">
                <span className="w-2 h-2 rounded-full bg-rose-500 animate-ping" />
                <span>{hud.cameraNotice}</span>
              </div>
            )}
          </div>

          {/* Top-Right Live Picture-in-Picture (PiP) Recording Camera Feed when [H] is placed */}
          <div className="absolute top-4 right-6 flex flex-col items-end gap-2">
            {hud.cameraPlaced ? (
              <div className="p-2 rounded-md bg-[#0B0E11]/85 border border-rose-500/45 shadow-[0_0_24px_rgba(239,68,68,0.2)] backdrop-blur-md">
                <div className="flex items-center justify-between gap-3 mb-1.5 px-1 font-mono-tech text-[11px]">
                  <span className="flex items-center gap-1.5 text-rose-400 font-bold">
                    <span className="w-2 h-2 rounded-full bg-rose-500 animate-pulse" />
                    <span>CAM-01 // REC</span>
                  </span>
                  <span className="text-sky-300">{hud.recordedDurationSec.toFixed(1)}s</span>
                </div>
                <div className="relative w-48 h-[108px] rounded overflow-hidden border border-white/15 bg-black">
                  <canvas
                    ref={pipCanvasRef}
                    width={REC_WIDTH / 2}
                    height={REC_HEIGHT / 2}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute bottom-1 right-1.5 px-1.5 py-0.5 rounded bg-black/75 font-mono-tech text-[10px] text-emerald-300">
                    [I] VIEW CLIP
                  </div>
                </div>
                <div className="mt-1.5 flex items-center justify-between px-1 font-mono-tech text-[10px] text-slate-300">
                  <span>[H] Relocate Cam</span>
                  <span className="text-amber-300">[I] Play Clip</span>
                </div>
              </div>
            ) : (
              <div className="flex items-center gap-2 px-3 py-1.5 rounded bg-[#0B0E11]/75 border border-white/12 backdrop-blur-md font-mono-tech text-[11px] text-slate-300">
                <Video className="w-3.5 h-3.5 text-rose-400" />
                <span>
                  PRESS <strong className="text-rose-300">[H]</strong> TO PLACE RECORDING CAMERA
                </span>
              </div>
            )}
          </div>

          {/* Dynamic Center Crosshair */}
          {!hud.isViewingClip && (
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2">
              <div
                className="relative transition-opacity duration-75"
                style={{ opacity: hipCrosshairOpacity }}
              >
                <div className="absolute -translate-x-1/2 -translate-y-1/2 w-1 h-1 rounded-full bg-white shadow-[0_0_4px_rgba(0,0,0,0.95)]" />
                <div
                  className="absolute left-1/2 -translate-x-1/2 w-[2px] h-2.5 bg-white/95 shadow-[0_0_4px_rgba(0,0,0,0.95)]"
                  style={{ bottom: `${hud.crosshairSpread}px` }}
                />
                <div
                  className="absolute left-1/2 -translate-x-1/2 w-[2px] h-2.5 bg-white/95 shadow-[0_0_4px_rgba(0,0,0,0.95)]"
                  style={{ top: `${hud.crosshairSpread}px` }}
                />
                <div
                  className="absolute top-1/2 -translate-y-1/2 h-[2px] w-2.5 bg-white/95 shadow-[0_0_4px_rgba(0,0,0,0.95)]"
                  style={{ right: `${hud.crosshairSpread}px` }}
                />
                <div
                  className="absolute top-1/2 -translate-y-1/2 h-[2px] w-2.5 bg-white/95 shadow-[0_0_4px_rgba(0,0,0,0.95)]"
                  style={{ left: `${hud.crosshairSpread}px` }}
                />
              </div>

              {hud.cameraPerspective === 'TPV' && hud.adsAmount > 0.3 && (
                <div className="absolute -translate-x-1/2 -translate-y-1/2 w-1.5 h-1.5 rounded-full bg-amber-400 shadow-[0_0_6px_rgba(245,158,11,0.9)]" />
              )}

              {hud.hitmarkerTime > 0 && (
                <div className="absolute -translate-x-1/2 -translate-y-1/2 w-7 h-7">
                  {[45, -45].map((deg) => (
                    <div
                      key={deg}
                      className="absolute inset-0 flex items-center justify-between"
                      style={{ transform: `rotate(${deg}deg)` }}
                    >
                      <span
                        className={`block w-2.5 h-[2px] ${
                          hud.isHeadshotHit ? 'bg-amber-400' : 'bg-white'
                        }`}
                      />
                      <span
                        className={`block w-2.5 h-[2px] ${
                          hud.isHeadshotHit ? 'bg-amber-400' : 'bg-white'
                        }`}
                      />
                    </div>
                  ))}
                </div>
              )}

              {hud.isReloading ? (
                <div className="absolute top-11 left-1/2 -translate-x-1/2 flex flex-col items-center gap-1">
                  <span className="font-mono-tech text-[11px] tracking-widest text-amber-400 hud-text-shadow uppercase">
                    RELOADING
                  </span>
                  <div className="w-28 h-1.5 rounded-full bg-black/70 border border-white/15 overflow-hidden">
                    <div
                      className="h-full bg-amber-400 transition-none"
                      style={{ width: `${Math.round(hud.reloadProgress * 100)}%` }}
                    />
                  </div>
                </div>
              ) : (
                isLowAmmo && (
                  <div className="absolute top-10 left-1/2 -translate-x-1/2 whitespace-nowrap px-2 py-0.5 rounded bg-black/65 border border-rose-500/40 font-mono-tech text-[11px] text-rose-400 tracking-wider">
                    {currentMag === 0 ? '[R] EMPTY — RELOAD' : '[R] LOW AMMO'}
                  </div>
                )
              )}
            </div>
          )}

          {/* Bottom-Left Operator Stance, Elevation & Camera Telemetry */}
          <div className="absolute bottom-6 left-6 flex flex-col gap-2">
            <div className="flex items-center gap-3 px-4 py-2.5 rounded bg-[#0B0E11]/78 border border-white/12 backdrop-blur-md">
              <Shield className="w-4 h-4 text-emerald-400 shrink-0" />
              <div>
                <div className="flex items-center gap-2">
                  <span className="font-tactical text-lg font-bold tracking-wider text-white uppercase">
                    STANCE: {hud.stance}
                  </span>
                  <span
                    className={`px-1.5 py-0.5 rounded font-mono-tech text-[11px] ${
                      hud.elevationY >= 0.95
                        ? 'bg-amber-500/20 text-amber-300 border border-amber-400/40'
                        : 'bg-white/10 text-slate-300'
                    }`}
                  >
                    ELEV: {hud.elevationY.toFixed(2)}M
                  </span>
                </div>
                <div className="w-40 h-1.5 mt-1 rounded-full bg-white/15 overflow-hidden">
                  <div className="w-full h-full bg-emerald-400" />
                </div>
              </div>
            </div>

            <div className="flex items-center gap-2 px-3 py-1.5 rounded bg-[#0B0E11]/70 border border-white/10 font-mono-tech text-[11px] text-slate-300">
              <Eye className="w-3.5 h-3.5 text-sky-400" />
              <span>
                CAM:{' '}
                <strong className="text-white">
                  {hud.cameraPerspective === 'FPV' ? '1ST PERSON FPS' : '3RD PERSON X-BOT'}
                </strong>
              </span>
              <span className="text-slate-400 ml-1">[V] Toggle</span>
              <span className="text-white/20">|</span>
              <span className="text-rose-300">[H] Place Cam</span>
              <span className="text-white/20">|</span>
              <span className="text-emerald-300">[I] View Clip</span>
            </div>
          </div>

          {/* Bottom-Right Warzone Weapon & Ammo Telemetry */}
          <div className="absolute bottom-6 right-6 flex flex-col items-end gap-2">
            <div className="flex items-center gap-2">
              {(['ar', 'pistol'] as WeaponId[]).map((wId, idx) => {
                const active = hud.activeWeapon === wId;
                return (
                  <div
                    key={wId}
                    className={`px-2.5 py-1 rounded font-mono-tech text-[11px] border backdrop-blur-md ${
                      active
                        ? 'bg-amber-500/20 border-amber-400 text-amber-300'
                        : 'bg-[#0B0E11]/70 border-white/10 text-slate-400'
                    }`}
                  >
                    [{idx + 1}] {wId === 'ar' ? 'ASSAULT RIFLE' : 'PISTOL'}
                  </div>
                );
              })}
            </div>

            <div className="flex items-center gap-5 px-5 py-3 rounded bg-[#0B0E11]/82 border border-white/15 backdrop-blur-md">
              <div className="text-right">
                <div className="flex items-center justify-end gap-2">
                  <span className="px-1.5 py-0.5 rounded bg-white/10 font-mono-tech text-[10px] text-amber-400">
                    {spec.fireMode}
                  </span>
                  <span className="font-tactical text-xl font-bold tracking-wider text-white uppercase">
                    {spec.code}
                  </span>
                </div>
                <div className="font-mono-tech text-[11px] text-slate-400">{spec.caliber}</div>
              </div>

              <div className="h-10 w-[1px] bg-white/15" />

              <div className="flex items-baseline gap-1.5 font-mono-tech">
                <span
                  className={`text-4xl font-bold leading-none ${
                    isLowAmmo ? 'text-rose-400' : 'text-white'
                  }`}
                >
                  {String(currentMag).padStart(2, '0')}
                </span>
                <span className="text-lg text-slate-400">
                  / {String(currentReserve).padStart(3, '0')}
                </span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* =========================================================
          [I] TACTICAL DVR // RECORDED CLIP PLAYBACK VIEWER
         ========================================================= */}
      {!inMenu && hud.isViewingClip && (
        <div className="absolute inset-0 z-40 flex items-center justify-center p-4 bg-[#070A0E]/82 backdrop-blur-md">
          <div className="w-full max-w-3xl rounded-lg bg-[#10151C]/95 border border-white/15 shadow-2xl overflow-hidden">
            {/* Header Bar */}
            <div className="flex items-center justify-between px-5 py-3.5 border-b border-white/10 bg-black/40">
              <div className="flex items-center gap-3">
                <span className="inline-flex items-center justify-center w-8 h-8 rounded bg-rose-500/20 border border-rose-500/40 text-rose-400">
                  <Film className="w-4 h-4" />
                </span>
                <div>
                  <h2 className="font-tactical text-2xl font-extrabold tracking-wider text-white uppercase leading-none">
                    TACTICAL DVR // RECORDED CLIP PLAYBACK
                  </h2>
                  <p className="font-mono-tech text-[11px] text-slate-400 mt-0.5">
                    FIELD CAMERA FEED · {hud.recordedFramesCount} FRAMES ({hud.recordedDurationSec.toFixed(1)}s)
                  </p>
                </div>
              </div>

              <button
                type="button"
                onClick={() => engineRef.current?.closeClipViewer()}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded bg-white/10 hover:bg-white/15 border border-white/15 font-mono-tech text-xs text-white cursor-pointer transition-colors"
              >
                <X className="w-3.5 h-3.5" />
                <span>CLOSE [I]</span>
              </button>
            </div>

            {/* Video Playback Screen */}
            <div className="relative bg-black flex items-center justify-center">
              <canvas
                ref={playbackCanvasRef}
                width={REC_WIDTH}
                height={REC_HEIGHT}
                className="w-full aspect-video max-h-[60vh] object-contain"
              />
            </div>

            {/* Interactive Scrubber & Playback Controls */}
            <div className="p-4 space-y-3 bg-[#0C1016] border-t border-white/10">
              {/* Scrubber Slider */}
              <div className="flex items-center gap-3 font-mono-tech text-xs text-slate-300">
                <span className="w-16 text-right text-sky-400">
                  {((clipFrameIdx / REC_FPS) || 0).toFixed(2)}s
                </span>
                <input
                  type="range"
                  min={0}
                  max={Math.max(0, hud.recordedFramesCount - 1)}
                  value={Math.min(clipFrameIdx, Math.max(0, hud.recordedFramesCount - 1))}
                  onChange={(e) => {
                    setClipPlaying(false);
                    setClipFrameIdx(Number(e.target.value));
                  }}
                  className="flex-1 accent-amber-500 cursor-pointer"
                />
                <span className="w-16 text-slate-400">
                  {hud.recordedDurationSec.toFixed(2)}s
                </span>
              </div>

              {/* Control Buttons */}
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => setClipPlaying((p) => !p)}
                    className="flex items-center gap-2 px-4 py-2 rounded bg-amber-500 hover:bg-amber-400 text-[#090C10] font-tactical text-lg font-extrabold tracking-wider uppercase cursor-pointer transition-colors"
                  >
                    {clipPlaying ? (
                      <>
                        <Pause className="w-4 h-4 fill-current" />
                        <span>PAUSE [SPACE]</span>
                      </>
                    ) : (
                      <>
                        <Play className="w-4 h-4 fill-current" />
                        <span>PLAY [SPACE]</span>
                      </>
                    )}
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      setClipFrameIdx(0);
                      setClipPlaying(true);
                    }}
                    className="flex items-center gap-1.5 px-3 py-2 rounded bg-white/8 hover:bg-white/14 border border-white/10 font-mono-tech text-xs text-slate-200 cursor-pointer transition-colors"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                    <span>RESTART</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setClipSpeed((s) => (s === 1 ? 0.5 : 1))}
                    className="px-3 py-2 rounded bg-white/8 hover:bg-white/14 border border-white/10 font-mono-tech text-xs text-sky-300 cursor-pointer transition-colors"
                  >
                    SPEED: {clipSpeed === 1 ? '1.0x NORMAL' : '0.5x SLOW-MO'}
                  </button>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      engineRef.current?.placeRecordingCamera();
                      engineRef.current?.requestPointerLock();
                    }}
                    className="flex items-center gap-1.5 px-3 py-2 rounded bg-rose-500/20 hover:bg-rose-500/30 border border-rose-500/40 font-mono-tech text-xs text-rose-300 cursor-pointer transition-colors"
                  >
                    <Camera className="w-3.5 h-3.5" />
                    <span>RELOCATE CAM [H]</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => engineRef.current?.closeClipViewer()}
                    className="px-4 py-2 rounded bg-emerald-500 hover:bg-emerald-400 text-[#090C10] font-tactical text-lg font-extrabold tracking-wider uppercase cursor-pointer transition-colors"
                  >
                    RESUME COMBAT [I]
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* =========================================================
          POINTER-LOCK RELEASED / TACTICAL PAUSE OVERLAY
         ========================================================= */}
      {!inMenu && !hud.pointerLocked && !hud.isViewingClip && (
        <div className="absolute inset-0 z-30 flex items-center justify-center bg-[#090C10]/72 backdrop-blur-sm">
          <div className="w-full max-w-sm p-6 rounded-lg bg-[#11161D]/95 border border-white/15 shadow-2xl space-y-4 text-center">
            <div className="inline-flex items-center justify-center w-11 h-11 rounded-full bg-amber-500/15 border border-amber-500/35 text-amber-400">
              <Crosshair className="w-5 h-5" />
            </div>
            <div>
              <h2 className="font-tactical text-3xl font-extrabold tracking-wide text-white uppercase">
                TACTICAL PAUSE
              </h2>
              <p className="mt-1 text-xs text-slate-400">
                Click resume to lock mouse cursor for 360° FPS aim & scope control.
              </p>
            </div>

            <div className="space-y-2.5 pt-1">
              <button
                type="button"
                onClick={() => engineRef.current?.requestPointerLock()}
                className="w-full py-3 px-4 rounded bg-amber-500 hover:bg-amber-400 text-[#090C10] font-tactical text-xl font-extrabold tracking-wider uppercase cursor-pointer transition-colors"
              >
                RESUME COMBAT
              </button>

              {hud.cameraPlaced && (
                <button
                  type="button"
                  onClick={() => engineRef.current?.toggleClipViewer()}
                  className="w-full py-2.5 px-4 rounded bg-emerald-500/20 hover:bg-emerald-500/30 border border-emerald-400/40 text-emerald-300 font-mono-tech text-xs uppercase cursor-pointer transition-colors"
                >
                  WATCH RECORDED CLIP [I] ({hud.recordedDurationSec.toFixed(1)}s)
                </button>
              )}

              <button
                type="button"
                onClick={() => {
                  engineRef.current?.togglePerspective();
                  engineRef.current?.requestPointerLock();
                }}
                className="w-full py-2.5 px-4 rounded bg-white/8 hover:bg-white/14 border border-white/10 text-slate-200 font-mono-tech text-xs uppercase cursor-pointer transition-colors"
              >
                SWITCH TO {hud.cameraPerspective === 'FPV' ? '3RD-PERSON X-BOT CAM' : '1ST-PERSON FPS CAM'} [V]
              </button>

              <div className="grid grid-cols-2 gap-2.5">
                <button
                  type="button"
                  onClick={() => {
                    engineRef.current?.resetPosition();
                    engineRef.current?.requestPointerLock();
                  }}
                  className="flex items-center justify-center gap-1.5 py-2.5 px-3 rounded bg-white/8 hover:bg-white/14 border border-white/10 text-slate-300 font-mono-tech text-xs uppercase cursor-pointer transition-colors"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>RESPAWN</span>
                </button>

                <button
                  type="button"
                  onClick={handleReturnToMenu}
                  className="py-2.5 px-3 rounded bg-rose-500/15 hover:bg-rose-500/25 border border-rose-500/35 text-rose-300 font-mono-tech text-xs uppercase cursor-pointer transition-colors"
                >
                  MAIN MENU
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default App;
