import * as THREE from 'three';
import { createEnvironmentMap } from './game/textures';

interface SourceModel { verts: number[][]; faces: number[][] }

const renderer = new THREE.WebGLRenderer({ antialias: true, preserveDrawingBuffer: true });
renderer.setPixelRatio(1);
renderer.setSize(1120, 720);
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 1.08;
renderer.shadowMap.enabled = true;
document.body.appendChild(renderer.domElement);

const scene = new THREE.Scene();
scene.background = new THREE.Color(0x485462);
scene.environment = createEnvironmentMap(renderer);
scene.add(new THREE.HemisphereLight(0xe2efff, 0x303039, 1));
const key = new THREE.DirectionalLight(0xffefd8, 3.2);
key.position.set(3, 5, 4);
scene.add(key);
const rim = new THREE.DirectionalLight(0xafcaff, 1.2);
rim.position.set(-4, 2, -3);
scene.add(rim);
const floor = new THREE.Mesh(new THREE.PlaneGeometry(8, 8), new THREE.MeshStandardMaterial({ color: 0x424d57, roughness: 0.92 }));
floor.rotation.x = -Math.PI / 2;
floor.position.y = -0.15;
scene.add(floor);

const cam = new THREE.PerspectiveCamera(40, 1120 / 720, 0.01, 12);
cam.position.set(1.3, 0.36, 0.82);
cam.lookAt(0, 0, 0);

const gun = new THREE.Group();
scene.add(gun);

fetch('/test-assets/ar-mesh-preview.json').then(r => r.json()).then((data: SourceModel) => {
  const pos = new Float32Array(data.verts.length * 3);
  data.verts.forEach(([x, y, z], i) => {
    pos[i * 3] = z * 0.5;
    pos[i * 3 + 1] = y * 0.5;
    pos[i * 3 + 2] = -x * 0.5;
  });
  const ix: number[] = [];
  for (const f of data.faces) {
    for (let i = 1; i < f.length - 1; i++) ix.push(f[0], f[i], f[i + 1]);
  }
  const geo = new THREE.BufferGeometry();
  geo.setAttribute('position', new THREE.BufferAttribute(pos, 3));
  geo.setIndex(ix);
  geo.computeVertexNormals();
  const mat = new THREE.MeshPhysicalMaterial({
    color: 0x484c51,
    roughness: 0.43,
    metalness: 0.48,
    clearcoat: 0.25,
    side: THREE.DoubleSide,
    envMapIntensity: 1.3,
  });
  const mesh = new THREE.Mesh(geo, mat);
  mesh.castShadow = true;
  gun.add(mesh);
  // Preview geometry convention: verify silhouette, scale and part separation.
  const b = new THREE.Box3().setFromObject(gun);
  const size = b.getSize(new THREE.Vector3());
  window.__meshInfo = { vertices: data.verts.length, faces: data.faces.length, size: size.toArray() };
  renderer.render(scene, cam);
  window.__done = true;
});

declare global { interface Window { __done?: boolean; __meshInfo?: Record<string, unknown> } }