import * as THREE from 'three';
import {
  AR_RELOAD_TIMING,
  createFirstPersonWeapons,
  updateWeaponAnimation,
  type WeaponRig,
} from './weapons';
import { HandGripPose, WeaponId } from './types';
import { XBOT_ANIMS, XBOT_BONES, XBOT_GZ_B64, XBOT_MESHES } from './xbotModelData';

export interface OperatorInputState {
  dt: number;
  time: number;
  speed: number; // m/s horizontal
  maxSprintSpeed: number;
  forwardMove: number; // -1..1 local Z
  strafeMove: number; // -1..1 local X
  isSprinting: boolean;
  crouchAmount: number; // 0..1
  grounded: boolean;
  verticalVel: number;
  landImpact: number; // 0..1 shock absorption
  aimPitch: number; // radians (-down, +up)
  adsAmount: number; // 0..1
  recoilKick: number; // 0..1
  isReloading: boolean;
  reloadProgress: number; // 0..1
  activeWeapon: WeaponId;
  firstPersonHideUpper: boolean;
  /** Exact T-Pose from the Mixamo Xbot reference screenshot (used by the menu) */
  showcasePose?: boolean;
  // Synchronized parameters from the engine
  isDryReload?: boolean;
  ammoInMag?: number;
  boltCycle?: number;
  muzzleFlashTimer?: number;
}

export interface DecodedXbotPayload {
  ibmFloats: Float32Array;
  meshes: Array<{
    pos: Float32Array;
    norm: Float32Array;
    skinIndex: Uint16Array;
    skinWeight: Float32Array;
    indices: Uint16Array;
    lowerIndexCount: number;
    upperIndexCount: number;
  }>;
  clips: Record<string, THREE.AnimationClip>;
}

let decodedPromise: Promise<DecodedXbotPayload> | null = null;

export async function decodeXbotPayload(): Promise<DecodedXbotPayload> {
  if (decodedPromise) return decodedPromise;

  decodedPromise = (async () => {
    const binStr = atob(XBOT_GZ_B64);
    const gzBytes = new Uint8Array(binStr.length);
    for (let i = 0; i < binStr.length; i++) {
      gzBytes[i] = binStr.charCodeAt(i);
    }

    const ds = new DecompressionStream('gzip');
    const writer = ds.writable.getWriter();
    writer.write(gzBytes);
    writer.close();

    const rawBuf = await new Response(ds.readable).arrayBuffer();
    let byteOffset = 0;

    // 1. Inverse bind matrices (67 * 16 floats)
    const numBones = XBOT_BONES.length;
    const ibmFloats = new Float32Array(rawBuf, byteOffset, numBones * 16);
    byteOffset += numBones * 16 * 4;

    // 2. Decode both skinned meshes (0 = Beta_Joints, 1 = Beta_Surface)
    const meshes: DecodedXbotPayload['meshes'] = [];
    for (let m = 0; m < XBOT_MESHES.length; m++) {
      const meta = XBOT_MESHES[m];
      const V = meta.verts;
      const I = meta.lowerIndexCount + meta.upperIndexCount;

      const px = new Int16Array(rawBuf, byteOffset, V);
      byteOffset += V * 2;
      const py = new Int16Array(rawBuf, byteOffset, V);
      byteOffset += V * 2;
      const pz = new Int16Array(rawBuf, byteOffset, V);
      byteOffset += V * 2;

      const nx = new Int8Array(rawBuf, byteOffset, V);
      byteOffset += V;
      const ny = new Int8Array(rawBuf, byteOffset, V);
      byteOffset += V;
      const nz = new Int8Array(rawBuf, byteOffset, V);
      byteOffset += V;

      const j0 = new Uint8Array(rawBuf, byteOffset, V * 4);
      byteOffset += V * 4;
      const w0 = new Uint8Array(rawBuf, byteOffset, V * 4);
      byteOffset += V * 4;

      const dInd = new Int16Array(rawBuf, byteOffset, I);
      byteOffset += I * 2;

      const pos = new Float32Array(V * 3);
      const norm = new Float32Array(V * 3);
      let lx = 0;
      let ly = 0;
      let lz = 0;
      for (let k = 0; k < V; k++) {
        lx += px[k];
        ly += py[k];
        lz += pz[k];
        pos[k * 3] = lx / 16384;
        pos[k * 3 + 1] = ly / 16384;
        pos[k * 3 + 2] = lz / 16384;

        let fnx = nx[k] / 127;
        let fny = ny[k] / 127;
        let fnz = nz[k] / 127;
        const len = Math.hypot(fnx, fny, fnz) || 1;
        norm[k * 3] = fnx / len;
        norm[k * 3 + 1] = fny / len;
        norm[k * 3 + 2] = fnz / len;
      }

      const skinIndex = new Uint16Array(V * 4);
      const skinWeight = new Float32Array(V * 4);
      for (let k = 0; k < V; k++) {
        const base = k * 4;
        skinIndex[base] = j0[base];
        skinIndex[base + 1] = j0[base + 1];
        skinIndex[base + 2] = j0[base + 2];
        skinIndex[base + 3] = j0[base + 3];

        const wSum = (w0[base] + w0[base + 1] + w0[base + 2] + w0[base + 3]) || 255;
        skinWeight[base] = w0[base] / wSum;
        skinWeight[base + 1] = w0[base + 1] / wSum;
        skinWeight[base + 2] = w0[base + 2] / wSum;
        skinWeight[base + 3] = w0[base + 3] / wSum;
      }

      const indices = new Uint16Array(I);
      let lInd = 0;
      for (let i = 0; i < I; i++) {
        lInd += dInd[i];
        indices[i] = lInd;
      }

      meshes.push({
        pos,
        norm,
        skinIndex,
        skinWeight,
        indices,
        lowerIndexCount: meta.lowerIndexCount,
        upperIndexCount: meta.upperIndexCount,
      });
    }

    // 3. Decode Mixamo AnimationClips (idle, walk, run, sneak_pose)
    const clips: Record<string, THREE.AnimationClip> = {};
    for (const a of XBOT_ANIMS) {
      const kfTracks: THREE.KeyframeTrack[] = [];
      for (const tr of a.tracks) {
        const comps = tr.p === 'r' ? 4 : 3;
        const scale = tr.p === 'r' ? 32767 : 100;
        const qArr = new Int16Array(rawBuf, byteOffset, tr.f * comps);
        byteOffset += tr.f * comps * 2;

        const times = new Float32Array(tr.f);
        for (let f = 0; f < tr.f; f++) {
          times[f] = tr.f === 1 ? 0 : (f / (tr.f - 1)) * a.duration;
        }
        const values = new Float32Array(tr.f * comps);
        for (let i = 0; i < values.length; i++) {
          values[i] = qArr[i] / scale;
        }

        const boneKey = `xb_${tr.j}`;
        if (tr.p === 'r') {
          kfTracks.push(new THREE.QuaternionKeyframeTrack(`${boneKey}.quaternion`, times, values));
        } else {
          kfTracks.push(new THREE.VectorKeyframeTrack(`${boneKey}.position`, times, values));
        }
      }
      clips[a.name] = new THREE.AnimationClip(a.name, a.duration, kfTracks);
    }

    return { ibmFloats, meshes, clips };
  })();

  return decodedPromise;
}

type Side = 'Left' | 'Right';
type FingerName = 'Index' | 'Middle' | 'Ring' | 'Pinky';

interface JointChain {
  bones: THREE.Bone[];
  axes: THREE.Vector3[];
}

interface ArmRigData {
  arm: THREE.Bone;
  fore: THREE.Bone;
  hand: THREE.Bone;
  upperLen: number; // in cm
  foreLen: number;  // in cm
  lenAxis: THREE.Vector3;
  handBindBasisT: THREE.Matrix4;
  fingers: Record<FingerName, JointChain>;
  thumb: JointChain;
}

const FINGERS: FingerName[] = ['Index', 'Middle', 'Ring', 'Pinky'];
const PALM_BIND = new THREE.Vector3(0, -1, 0);
const THUMB_OPPOSITION_AXIS = new THREE.Vector3(1, 0, 0);

// Scratch variables for analytical two-bone IK (zero allocations in frame loop)
const _armInv = new THREE.Matrix4();
const _qArmInv = new THREE.Quaternion();
const _qTarget = new THREE.Quaternion();
const _qHand = new THREE.Quaternion();
const _qFore = new THREE.Quaternion();
const _qUpper = new THREE.Quaternion();
const _qParentArm = new THREE.Quaternion();
const _qTmp = new THREE.Quaternion();
const _W = new THREE.Vector3();
const _H = new THREE.Vector3();
const _S = new THREE.Vector3();
const _E = new THREE.Vector3();
const _dir = new THREE.Vector3();
const _pole = new THREE.Vector3();
const _e1 = new THREE.Vector3();
const _e2 = new THREE.Vector3();
const _hinge = new THREE.Vector3();
const _hingeLocal = new THREE.Vector3();
const _fwdT = new THREE.Vector3();
const _palmT = new THREE.Vector3();
const _sideT = new THREE.Vector3();
const _palmPerp = new THREE.Vector3();
const _a3 = new THREE.Vector3();
const _b3 = new THREE.Vector3();
const _mA = new THREE.Matrix4();
const _mB = new THREE.Matrix4();
const _stockPoint = new THREE.Vector3();
const _shoulderPocket = new THREE.Vector3();
const _stockCorrection = new THREE.Vector3();
const _mountInverse = new THREE.Quaternion();
const _padInverse = new THREE.Matrix4();
const _padForward = new THREE.Vector3();
const _padScale = new THREE.Vector3();
const _surfaceVertex = new THREE.Vector3();
const SHOULDER_BIND_POINT = new THREE.Vector3(-0.1183, 1.4209, 0.0728);

function basisRotation(
  a1: THREE.Vector3,
  a2: THREE.Vector3,
  b1: THREE.Vector3,
  b2: THREE.Vector3,
  out: THREE.Quaternion
): THREE.Quaternion {
  _a3.crossVectors(a1, a2);
  _b3.crossVectors(b1, b2);
  _mA.makeBasis(a1, a2, _a3).transpose();
  _mB.makeBasis(b1, b2, _b3).multiply(_mA);
  return out.setFromRotationMatrix(_mB);
}

/**
 * Official Three.js / Mixamo `Xbot.glb` Player Character:
 * - `Beta_Joints` (`Beta_Joints_MAT`: dark burgundy [0.333, 0.125, 0.101])
 * - `Beta_Surface` (`asdf1:Beta_HighLimbsGeoSG2`: terracotta crimson red [0.837, 0.302, 0.264])
 * - Full 67-bone `mixamorig` skeleton with embedded Mixamo `idle`, `walk`, `run`, and `sneak_pose` clips
 * - Analytical Two-Bone IK for Right and Left arms + dynamic 20-finger curling matching the FPV weapon animations!
 * - Super-realistic third-person weapons (AR-15 Carbine and Glock 17) with moving magazines and bolts!
 */
export class TacticalOperator {
  public readonly root = new THREE.Group();

  // Wrapper rotated by Math.PI so Xbot's +Z forward aligns with our game's -Z forward
  private readonly modelWrap = new THREE.Group();
  private readonly armature = new THREE.Group();

  private skeleton: THREE.Skeleton | null = null;
  private bonesByName = new Map<string, THREE.Bone>();
  private bonesList: THREE.Bone[] = [];
  private mixer: THREE.AnimationMixer | null = null;
  private actions: Record<string, THREE.AnimationAction> = {};

  // Third-person weapons and arm IK rigs
  private readonly tpWeaponMount = new THREE.Group();
  private tpWeapons: Record<WeaponId, WeaponRig>;
  private armRigs: Partial<Record<Side, ArmRigData>> = {};
  private shoulderSurface: THREE.SkinnedMesh | null = null;
  private shoulderContactVertex = -1;
  private shoulderCollisionSamples: Array<{ mesh: THREE.SkinnedMesh; indices: number[]; worldPositions: Float32Array }> = [];

  private readonly upperBodyMaterials: THREE.Material[] = [];
  private isCurrentlyHidingUpper = false;
  private ready = false;

  constructor() {
    this.modelWrap.rotation.y = Math.PI;
    this.root.add(this.modelWrap);

    this.armature.name = 'Armature';
    this.armature.scale.setScalar(0.01);
    this.modelWrap.add(this.armature);

    // Build the super-realistic third-person weapon models
    this.tpWeapons = createFirstPersonWeapons();
    this.root.add(this.tpWeaponMount);
    this.tpWeaponMount.add(this.tpWeapons.ar.root);
    this.tpWeaponMount.add(this.tpWeapons.pistol.root);

    // These are full-body offsets from the sternum, not first-person camera offsets.
    // The stock is collapsed so its pad meets the right shoulder instead of the torso.
    this.tpWeapons.ar.stockAssembly!.scale.z = 0.7;
    this.tpWeapons.ar.stockPad!.geometry.computeBoundingBox();
    this.tpWeapons.ar.hipPos.set(0.13, 0.03, -0.35);
    this.tpWeapons.ar.hipRot.set(0.02, 0.08, 0);
    this.tpWeapons.ar.adsPos.set(0.09, 0.17, -0.36);
    this.tpWeapons.ar.adsRot = new THREE.Euler(0, 0.1, 0);

    // The pistol is presented in front of the body; the original position
    // kept the slide against the chest and made the wrists fold inward.
    this.tpWeapons.pistol.hipPos.set(0.105, 0.04, -0.43);
    this.tpWeapons.pistol.hipRot.set(0.01, 0.04, 0);
    this.tpWeapons.pistol.adsPos.set(0.055, 0.19, -0.47);
    this.tpWeapons.pistol.adsRot = new THREE.Euler(0, 0.04, 0);

    this.tpWeapons.ar.root.visible = false;
    this.tpWeapons.pistol.root.visible = false;

    // Decode and mount the genuine Xbot.glb meshes + skeleton + animations
    decodeXbotPayload().then((payload) => {
      this.initFromPayload(payload);
    });
  }

  private initFromPayload(payload: DecodedXbotPayload) {
    // 1. Exact materials from Xbot.glb
    const jointsLowerMat = new THREE.MeshStandardMaterial({
      color: new THREE.Color().setRGB(0.33333334, 0.12452888, 0.10101473, THREE.SRGBColorSpace),
      metalness: 0.5,
      roughness: 0.8585786,
      side: THREE.DoubleSide,
    });
    const jointsUpperMat = jointsLowerMat.clone();
    this.upperBodyMaterials.push(jointsUpperMat);

    const surfaceLowerMat = new THREE.MeshStandardMaterial({
      color: new THREE.Color().setRGB(0.837, 0.302308, 0.263655, THREE.SRGBColorSpace),
      metalness: 0.0,
      roughness: 0.80829155,
      side: THREE.DoubleSide,
    });
    const surfaceUpperMat = surfaceLowerMat.clone();
    this.upperBodyMaterials.push(surfaceUpperMat);

    // Apply current FPV upper-body hide state if already set
    for (const mat of this.upperBodyMaterials) {
      mat.colorWrite = !this.isCurrentlyHidingUpper;
      mat.depthWrite = !this.isCurrentlyHidingUpper;
    }

    // 2. Construct all 67 mixamorig bones
    this.bonesList = XBOT_BONES.map((b, idx) => {
      const bone = new THREE.Bone();
      bone.name = `xb_${idx}`;
      bone.userData.mixamoName = b.name;
      bone.position.fromArray(b.t);
      bone.quaternion.fromArray(b.r);
      bone.scale.fromArray(b.s);
      this.bonesByName.set(b.name, bone);
      return bone;
    });

    XBOT_BONES.forEach((b, idx) => {
      if (b.parent === -1) {
        this.armature.add(this.bonesList[idx]);
      } else {
        this.bonesList[b.parent].add(this.bonesList[idx]);
      }
    });

    const boneInverses = this.bonesList.map((_, i) =>
      new THREE.Matrix4().fromArray(payload.ibmFloats, i * 16)
    );
    this.skeleton = new THREE.Skeleton(this.bonesList, boneInverses);

    // 3. Build Beta_Joints (m=0) and Beta_Surface (m=1) SkinnedMeshes
    const matPairs = [
      [jointsLowerMat, jointsUpperMat],
      [surfaceLowerMat, surfaceUpperMat],
    ];

    this.modelWrap.updateMatrixWorld(true);

    payload.meshes.forEach((mData, mIdx) => {
      const geo = new THREE.BufferGeometry();
      geo.setAttribute('position', new THREE.BufferAttribute(mData.pos, 3));
      geo.setAttribute('normal', new THREE.BufferAttribute(mData.norm, 3));
      geo.setAttribute('skinIndex', new THREE.BufferAttribute(mData.skinIndex, 4));
      geo.setAttribute('skinWeight', new THREE.BufferAttribute(mData.skinWeight, 4));
      geo.setIndex(new THREE.BufferAttribute(mData.indices, 1));

      geo.clearGroups();
      geo.addGroup(0, mData.lowerIndexCount, 0);
      geo.addGroup(mData.lowerIndexCount, mData.upperIndexCount, 1);

      const skinnedMesh = new THREE.SkinnedMesh(geo, matPairs[mIdx]);
      skinnedMesh.name = mIdx === 0 ? 'Beta_Joints' : 'Beta_Surface';
      skinnedMesh.castShadow = true;
      skinnedMesh.receiveShadow = true;
      skinnedMesh.frustumCulled = false;

      this.modelWrap.add(skinnedMesh);
      skinnedMesh.bind(this.skeleton!, new THREE.Matrix4());

      // Only the small portion of the torso near the right shoulder can meet
      // the stock. Cache these vertices so clearance stays cheap each frame.
      const shoulderIndices: number[] = [];
      for (let i = 0; i < mData.pos.length / 3; i++) {
        const x = mData.pos[i * 3];
        const y = mData.pos[i * 3 + 1];
        const z = mData.pos[i * 3 + 2];
        if (x < -0.23 || x > -0.03 || y < 1.25 || y > 1.7 || z < -0.02) continue;
        let dominant = 0;
        for (let c = 1; c < 4; c++) {
          if (mData.skinWeight[i * 4 + c] > mData.skinWeight[i * 4 + dominant]) dominant = c;
        }
        const boneName = XBOT_BONES[mData.skinIndex[i * 4 + dominant]].name;
        if (/Spine|Neck|Head|RightShoulder/.test(boneName)) shoulderIndices.push(i);
      }
      this.shoulderCollisionSamples.push({
        mesh: skinnedMesh,
        indices: shoulderIndices,
        worldPositions: new Float32Array(shoulderIndices.length * 3),
      });

      if (mIdx === 1) {
        // Track an actual point on the front of the right shoulder instead of
        // guessing from a bone center buried inside the character mesh.
        this.shoulderSurface = skinnedMesh;
        let closest = Infinity;
        for (let i = 0; i < mData.pos.length; i += 3) {
          const dx = mData.pos[i] - SHOULDER_BIND_POINT.x;
          const dy = mData.pos[i + 1] - SHOULDER_BIND_POINT.y;
          const dz = mData.pos[i + 2] - SHOULDER_BIND_POINT.z;
          const distance = dx * dx + dy * dy + dz * dz;
          if (distance < closest) {
            closest = distance;
            this.shoulderContactVertex = i / 3;
          }
        }
      }
    });

    // 4. Set up AnimationMixer with Mixamo clips (idle, walk, run, sneak_pose)
    this.mixer = new THREE.AnimationMixer(this.armature);
    for (const [name, clip] of Object.entries(payload.clips)) {
      const action = this.mixer.clipAction(clip);
      action.enabled = true;
      action.setEffectiveWeight(0);
      action.play();
      this.actions[name] = action;
    }

    // 5. Build Analytical Arm and Finger IK rigs for the full-body Xbot skeleton
    const byName = (n: string) => this.bonesByName.get(`mixamorig:${n}`)!;
    const chain = (side: Side, finger: string): JointChain => {
      const jointBones = [1, 2, 3].map((k) => byName(`${side}Hand${finger}${k}`));
      const axes = [2, 3, 4].map((k) => {
        const segDir = byName(`${side}Hand${finger}${k}`).position.clone().normalize();
        return new THREE.Vector3().crossVectors(segDir, PALM_BIND).normalize();
      });
      return { bones: jointBones, axes };
    };

    for (const side of ['Left', 'Right'] as Side[]) {
      const arm = byName(`${side}Arm`);
      const fore = byName(`${side}ForeArm`);
      const hand = byName(`${side}Hand`);
      const fwdBind = byName(`${side}HandMiddle1`).position.clone().normalize();
      const sideBind = new THREE.Vector3().crossVectors(fwdBind, PALM_BIND);
      this.armRigs[side] = {
        arm,
        fore,
        hand,
        upperLen: fore.position.length(),
        foreLen: hand.position.length(),
        lenAxis: fore.position.clone().normalize(),
        handBindBasisT: new THREE.Matrix4().makeBasis(fwdBind, PALM_BIND, sideBind).transpose(),
        fingers: {
          Index: chain(side, 'Index'),
          Middle: chain(side, 'Middle'),
          Ring: chain(side, 'Ring'),
          Pinky: chain(side, 'Pinky'),
        },
        thumb: chain(side, 'Thumb'),
      };
    }

    this.ready = true;
  }

  public setFirstPersonUpperHidden(hideUpper: boolean) {
    if (this.isCurrentlyHidingUpper === hideUpper) return;
    this.isCurrentlyHidingUpper = hideUpper;

    for (const mat of this.upperBodyMaterials) {
      mat.colorWrite = !hideUpper;
      mat.depthWrite = !hideUpper;
    }
  }

  /**
   * Temporarily unhides the upper body and 3rd-person weapon while rendering
   * the scene from an external camera (like the [H] Recording Camera) even in FPV.
   */
  public setExternalCameraPass(active: boolean) {
    const showUpper = active ? true : !this.isCurrentlyHidingUpper;
    for (const mat of this.upperBodyMaterials) {
      mat.colorWrite = showUpper;
      mat.depthWrite = showUpper;
    }
    this.tpWeaponMount.visible = showUpper;
  }

  private resetToBindTPose() {
    for (let i = 0; i < this.bonesList.length; i++) {
      const meta = XBOT_BONES[i];
      const bone = this.bonesList[i];
      bone.position.fromArray(meta.t);
      bone.quaternion.fromArray(meta.r);
      bone.scale.fromArray(meta.s);
    }
  }

  private solveArm(rig: ArmRigData, target: THREE.Object3D, hint: THREE.Object3D, grip: HandGripPose, isLeft: boolean) {
    // 1. Target wrist and elbow hint in armature space (cm)
    target.updateWorldMatrix(true, false);
    hint.updateWorldMatrix(true, false);
    _W.setFromMatrixPosition(target.matrixWorld).applyMatrix4(_armInv);
    _H.setFromMatrixPosition(hint.matrixWorld).applyMatrix4(_armInv);

    target.getWorldQuaternion(_qTarget).premultiply(_qArmInv);
    _fwdT.set(0, 0, -1).applyQuaternion(_qTarget);
    _palmT.set(0, -1, 0).applyQuaternion(_qTarget);

    // 2. Shoulder socket in armature space (cm) from the parent shoulder joint
    // Recompute the socket itself after Mixamo moves the spine this frame.
    // Updating only its parent used last frame's shoulder matrix for IK.
    rig.arm.updateWorldMatrix(true, false);
    _S.setFromMatrixPosition(rig.arm.matrixWorld).applyMatrix4(_armInv);

    const a = rig.upperLen;
    const b = rig.foreLen;
    _dir.subVectors(_W, _S);
    let d = _dir.length();
    if (d < 1e-4) {
      _dir.set(0, 0, 1);
      d = 1e-4;
    } else {
      _dir.divideScalar(d);
    }

    const maxD = (a + b) * 0.95;
    const minD = (a + b) * 0.25;
    d = THREE.MathUtils.clamp(d, minD, maxD);

    // 3. Elbow bend plane toward the hint
    _pole.subVectors(_H, _S);
    _pole.addScaledVector(_dir, -_pole.dot(_dir));
    if (_pole.lengthSq() < 1e-4) {
      if (isLeft) _pole.set(1, -0.6, -0.8).addScaledVector(_dir, -_dir.x).normalize();
      else _pole.set(-1, -0.6, -0.8).addScaledVector(_dir, _dir.x).normalize();
    } else {
      _pole.normalize();
    }

    // 4. Two-bone law of cosines
    const cosA = THREE.MathUtils.clamp((a * a + d * d - b * b) / (2 * a * d), -1, 1);
    const sinA = Math.sqrt(Math.max(0, 1 - cosA * cosA));
    _e1.copy(_dir).multiplyScalar(cosA).addScaledVector(_pole, sinA);
    _E.copy(_S).addScaledVector(_e1, a);
    _e2.subVectors(_W, _E).normalize();
    _hinge.crossVectors(_dir, _pole).normalize();

    // 5. Hand orientation
    _palmT.addScaledVector(_fwdT, -_palmT.dot(_fwdT)).normalize();
    _sideT.crossVectors(_fwdT, _palmT);
    _mB.makeBasis(_fwdT, _palmT, _sideT).multiply(rig.handBindBasisT);
    _qHand.setFromRotationMatrix(_mB);

    // 6. Forearm orientation
    _palmPerp.copy(_palmT).addScaledVector(_e2, -_palmT.dot(_e2));
    if (_palmPerp.lengthSq() < 1e-4) _palmPerp.crossVectors(_hinge, _e2);
    _palmPerp.normalize();
    basisRotation(rig.lenAxis, PALM_BIND, _e2, _palmPerp, _qFore);

    // 7. Upper arm orientation
    _hingeLocal.copy(_hinge).applyQuaternion(_qTmp.copy(_qFore).invert());
    _hingeLocal.addScaledVector(rig.lenAxis, -_hingeLocal.dot(rig.lenAxis)).normalize();
    basisRotation(rig.lenAxis, _hingeLocal, _e1, _hinge, _qUpper);

    // 8. Convert to bone local spaces
    rig.arm.parent!.getWorldQuaternion(_qParentArm).premultiply(_qArmInv).invert();
    rig.arm.quaternion.copy(_qUpper).premultiply(_qParentArm);
    rig.fore.quaternion.copy(_qFore).premultiply(_qUpper.clone().invert());
    rig.hand.quaternion.copy(_qHand).premultiply(_qFore.clone().invert());

    // 9. Dynamic finger curling from weapon grip pose
    const curls: Record<FingerName, [number, number, number]> = {
      Index: grip.index,
      Middle: grip.middle,
      Ring: grip.ring,
      Pinky: grip.pinky,
    };
    for (const f of FINGERS) {
      const c = rig.fingers[f];
      const ang = curls[f];
      for (let k = 0; k < 3; k++) c.bones[k].quaternion.setFromAxisAngle(c.axes[k], ang[k]);
    }
    const th = rig.thumb;
    th.bones[0].quaternion
      .setFromAxisAngle(THUMB_OPPOSITION_AXIS, grip.thumbOpp)
      .multiply(_qTmp.setFromAxisAngle(th.axes[0], grip.thumb[0]));
    th.bones[1].quaternion.setFromAxisAngle(th.axes[1], grip.thumb[1]);
    th.bones[2].quaternion.setFromAxisAngle(th.axes[2], grip.thumb[2]);
  }

  public update(s: OperatorInputState) {
    this.setFirstPersonUpperHidden(s.firstPersonHideUpper);
    if (!this.ready || !this.skeleton || !this.mixer) return;

    const showcase = !!s.showcasePose;

    // -------------------------------------------------------------------
    // 1. MENU SHOWCASE POSE: Exact T-Pose from the user's Xbot screenshot
    // -------------------------------------------------------------------
    if (showcase) {
      this.tpWeaponMount.visible = false;
      this.resetToBindTPose();
      return;
    }

    // Hide 3rd-person weapons during FPV so they never clip the 1st-person camera
    this.tpWeaponMount.visible = !s.firstPersonHideUpper;
    this.tpWeapons.ar.root.visible = s.activeWeapon === 'ar';
    this.tpWeapons.pistol.root.visible = s.activeWeapon === 'pistol';

    // -------------------------------------------------------------------
    // 2. IN-GAME MIXAMO LOCOMOTION BLENDING (idle / walk / run / sneak_pose)
    // -------------------------------------------------------------------
    const isMoving = s.speed > 0.15;
    const walkRatio = THREE.MathUtils.clamp(s.speed / 4.7, 0, 1);
    const sprintBlend = s.isSprinting && s.grounded && s.speed > 5.0 ? 1 : 0;

    let wIdle = 0;
    let wWalk = 0;
    let wRun = 0;
    let wSneak = 0;

    if (!isMoving) {
      wIdle = 1 - s.crouchAmount * 0.85;
      wSneak = s.crouchAmount * 0.85;
    } else if (s.crouchAmount > 0.35) {
      wWalk = 0.65;
      wSneak = 0.35;
    } else if (sprintBlend > 0.5) {
      wRun = 1.0;
    } else {
      wIdle = 1 - walkRatio;
      wWalk = walkRatio;
    }

    const dirSign = s.forwardMove < -0.15 ? -1 : 1;

    if (this.actions.idle) {
      this.actions.idle.setEffectiveWeight(
        THREE.MathUtils.lerp(this.actions.idle.getEffectiveWeight(), wIdle, Math.min(1, s.dt * 10))
      );
    }
    if (this.actions.walk) {
      this.actions.walk.setEffectiveWeight(
        THREE.MathUtils.lerp(this.actions.walk.getEffectiveWeight(), wWalk, Math.min(1, s.dt * 10))
      );
      this.actions.walk.setEffectiveTimeScale(
        dirSign * THREE.MathUtils.clamp(s.speed / 3.8, 0.55, 1.45)
      );
    }
    if (this.actions.run) {
      this.actions.run.setEffectiveWeight(
        THREE.MathUtils.lerp(this.actions.run.getEffectiveWeight(), wRun, Math.min(1, s.dt * 10))
      );
      this.actions.run.setEffectiveTimeScale(
        dirSign * THREE.MathUtils.clamp(s.speed / 6.6, 0.75, 1.35)
      );
    }
    if (this.actions.sneak_pose) {
      this.actions.sneak_pose.setEffectiveWeight(
        THREE.MathUtils.lerp(this.actions.sneak_pose.getEffectiveWeight(), wSneak, Math.min(1, s.dt * 10))
      );
    }

    this.mixer.update(s.dt);

    // -------------------------------------------------------------------
    // 3. PROCEDURAL CROUCH, MID-AIR JUMP TUCK & LANDING SHOCK ON LEGS/HIPS
    // -------------------------------------------------------------------
    const hips = this.bonesByName.get('mixamorig:Hips');
    const lUpLeg = this.bonesByName.get('mixamorig:LeftUpLeg');
    const rUpLeg = this.bonesByName.get('mixamorig:RightUpLeg');
    const lLeg = this.bonesByName.get('mixamorig:LeftLeg');
    const rLeg = this.bonesByName.get('mixamorig:RightLeg');

    if (hips) {
      // Lower Hips in cm (Armature is scaled by 0.01, so 30 units = 0.30m)
      hips.position.y -= s.crouchAmount * 30 + s.landImpact * 14;
      if (isMoving && s.grounded) {
        hips.rotateY(THREE.MathUtils.clamp(s.strafeMove * 0.25, -0.3, 0.3));
      }
    }

    if (!s.grounded && lUpLeg && rUpLeg && lLeg && rLeg) {
      const airTuck = THREE.MathUtils.clamp(0.45 + s.verticalVel * 0.035, 0.2, 0.8);
      lUpLeg.quaternion.slerp(new THREE.Quaternion().setFromEuler(new THREE.Euler(-0.65 * airTuck, 0, 0)), 0.75);
      rUpLeg.quaternion.slerp(new THREE.Quaternion().setFromEuler(new THREE.Euler(-0.42 * airTuck, 0, 0)), 0.75);
      lLeg.quaternion.slerp(new THREE.Quaternion().setFromEuler(new THREE.Euler(1.05 * airTuck, 0, 0)), 0.75);
      rLeg.quaternion.slerp(new THREE.Quaternion().setFromEuler(new THREE.Euler(0.78 * airTuck, 0, 0)), 0.75);
    } else if (s.crouchAmount > 0.05 && lUpLeg && rUpLeg && lLeg && rLeg) {
      lUpLeg.rotateX(-s.crouchAmount * 0.55);
      rUpLeg.rotateX(-s.crouchAmount * 0.55);
      lLeg.rotateX(s.crouchAmount * 0.95);
      rLeg.rotateX(s.crouchAmount * 0.95);
    }

    // -------------------------------------------------------------------
    // 4. UPPER-BODY TORSO AIM PITCH & HEAD CHEEK WELD
    // -------------------------------------------------------------------
    const spine1 = this.bonesByName.get('mixamorig:Spine1');
    const spine2 = this.bonesByName.get('mixamorig:Spine2');
    const neck = this.bonesByName.get('mixamorig:Neck');
    const head = this.bonesByName.get('mixamorig:Head');

    const clampedPitch = THREE.MathUtils.clamp(s.aimPitch, -1.15, 1.15);
    const recoilKick = s.boltCycle ?? s.recoilKick;
    const recoilPitch = recoilKick * 0.08;

    if (spine1) spine1.rotateX(-clampedPitch * 0.25 - recoilPitch * 0.3);
    if (spine2) spine2.rotateX(-clampedPitch * 0.32 - recoilPitch * 0.5);
    if (neck) neck.rotateX(-clampedPitch * 0.2);
    if (head) {
      head.rotateX(-clampedPitch * 0.18);
      head.rotateZ(s.adsAmount * 0.16); // Tactical cheek weld onto rifle stock
    }

    // -------------------------------------------------------------------
    // 5. THIRD-PERSON WEAPON ANIMATION (1-TO-1 SYNC WITH FPV!)
    // -------------------------------------------------------------------
    const activeTpRig = this.tpWeapons[s.activeWeapon];

    // Anchor to the animated sternum, so Mixamo breathing, walking and crouching
    // move the weapon with the shoulders rather than leaving it in world space.
    if (spine2) {
      spine2.getWorldPosition(_S);
      this.tpWeaponMount.position.copy(this.root.worldToLocal(_S));
    }
    // The game camera faces -Z: positive X pitch aims UP. Xbot's bones face
    // +Z before the 180-degree wrapper, so their -X lean above is correct,
    // but negating the root-space weapon pitch aimed the barrel DOWN instead.
    this.tpWeaponMount.rotation.x = clampedPitch;

    // Run identical weapon animation update (moving mag, bolt/slide cycle, sprint pose, hand targets)
    updateWeaponAnimation(activeTpRig, {
      dt: s.dt,
      time: s.time,
      adsAmount: s.adsAmount,
      isSprinting: s.isSprinting,
      moveSpeedNorm: Math.min(1, s.speed / 4.7),
      grounded: s.grounded,
      verticalVel: s.verticalVel,
      landDip: s.landImpact,
      mouseSwayX: 0,
      mouseSwayY: 0,
      recoilPosZ: recoilKick * 0.038,
      recoilPitch: recoilKick * 0.052,
      recoilRoll: 0,
      boltCycle: recoilKick,
      ammoInMag: s.ammoInMag ?? 30,
      isReloading: s.isReloading,
      reloadProgress: s.reloadProgress,
      isDryReload: !!s.isDryReload,
      reloadReachScale: 0.5,
      equipAlpha: 1.0,
      muzzleFlashTimer: s.muzzleFlashTimer ?? 0,
    });

    if (s.activeWeapon === 'ar' && activeTpRig.stockPad && this.shoulderSurface && this.shoulderContactVertex >= 0) {
      // Refresh the skinned shoulder before sampling it, including crouch and
      // pitch. The extra clearance accounts for the tilted buttpad corners.
      this.armature.updateWorldMatrix(true, true);
      this.shoulderSurface.updateWorldMatrix(true, false);
      this.shoulderSurface.updateMatrixWorld(true);
      this.shoulderSurface.getVertexPosition(this.shoulderContactVertex, _shoulderPocket)
        .applyMatrix4(this.shoulderSurface.matrixWorld);
      this.root.worldToLocal(_shoulderPocket);
      _shoulderPocket.x += 0.008;
      _shoulderPocket.z -= 0.012 + 0.02 * Math.abs(Math.sin(clampedPitch));

      const padDepth = activeTpRig.stockPad.geometry.boundingBox!.max.z + 0.001;
      _stockPoint.set(0, 0, padDepth);
      activeTpRig.stockPad.localToWorld(_stockPoint);
      this.root.worldToLocal(_stockPoint);
      _stockCorrection.subVectors(_shoulderPocket, _stockPoint);
      // The mount itself pitches: a root-space correction must be rotated
      // back into mount-local space before adding it to the weapon position.
      _mountInverse.copy(this.tpWeaponMount.quaternion).invert();
      activeTpRig.root.position.add(_stockCorrection.applyQuaternion(_mountInverse));

      // A tilted pad can still cut into the shoulder at its corners. Test the
      // nearby skinned torso vertices against the pad in its own coordinates,
      // then move only as far forward as needed to clear the surface.
      const pad = activeTpRig.stockPad;
      const bounds = pad.geometry.boundingBox!;
      for (const sample of this.shoulderCollisionSamples) {
        sample.mesh.updateWorldMatrix(true, false);
        sample.mesh.updateMatrixWorld(true);
        // Skin once per frame; each clearance pass reuses these world points.
        for (let i = 0; i < sample.indices.length; i++) {
          sample.mesh.getVertexPosition(sample.indices[i], _surfaceVertex).applyMatrix4(sample.mesh.matrixWorld);
          _surfaceVertex.toArray(sample.worldPositions, i * 3);
        }
      }
      let totalRetraction = 0;
      for (let pass = 0; pass < 4; pass++) {
        pad.updateWorldMatrix(true, false);
        _padInverse.copy(pad.matrixWorld).invert();
        let clearance = 0;
        for (const sample of this.shoulderCollisionSamples) {
          for (let i = 0; i < sample.worldPositions.length; i += 3) {
            _surfaceVertex.fromArray(sample.worldPositions, i).applyMatrix4(_padInverse);
            if (_surfaceVertex.x < bounds.min.x - 0.001 || _surfaceVertex.x > bounds.max.x + 0.001 ||
                _surfaceVertex.y < bounds.min.y - 0.001 || _surfaceVertex.y > bounds.max.y + 0.001 ||
                _surfaceVertex.z < bounds.min.z - 0.025 || _surfaceVertex.z > bounds.max.z + 0.0015) continue;
            clearance = Math.max(clearance, bounds.max.z + 0.0015 - _surfaceVertex.z);
          }
        }
        if (clearance <= 0 || totalRetraction >= 0.06) break;
        pad.getWorldQuaternion(_mountInverse);
        _padForward.set(0, 0, -1).applyQuaternion(_mountInverse);
        this.tpWeaponMount.getWorldQuaternion(_mountInverse).invert();
        _padForward.applyQuaternion(_mountInverse).normalize();
        pad.getWorldScale(_padScale);
        const movement = Math.min(0.06 - totalRetraction, clearance * _padScale.z);
        totalRetraction += movement;
        activeTpRig.root.position.addScaledVector(_padForward, movement);
      }
    }

    if (s.activeWeapon === 'ar') {
      // Full-body reach differs from the off-screen viewmodel. Grip the rear
      // of the handguard without pulling the wrist beyond the left shoulder.
      // Ease in/out of that grip so the reload does not snap the left hand.
      const t = s.reloadProgress;
      const returnStart = AR_RELOAD_TIMING.handleReleased;
      const supportBlend = s.isReloading
        ? Math.max(
            1 - THREE.MathUtils.smoothstep(t, 0, 0.15),
            THREE.MathUtils.smoothstep(t, returnStart, 1)
          )
        : 1;
      activeTpRig.leftHandTarget.position.x -= 0.04 * supportBlend;
      activeTpRig.leftHandTarget.position.z += 0.11 * supportBlend;
    }

    // -------------------------------------------------------------------
    // 6. TWO-BONE ANALYTICAL IK ON MIXAMORIG ARMS & 20-FINGER GRIP CURLS
    // -------------------------------------------------------------------
    this.armature.updateWorldMatrix(true, false);
    _armInv.copy(this.armature.matrixWorld).invert();
    this.armature.getWorldQuaternion(_qArmInv).invert();

    if (this.armRigs.Right) {
      this.solveArm(
        this.armRigs.Right,
        activeTpRig.rightHandTarget,
        activeTpRig.rightElbowHint,
        activeTpRig.rightGrip,
        false
      );
    }
    if (this.armRigs.Left) {
      this.solveArm(
        this.armRigs.Left,
        activeTpRig.leftHandTarget,
        activeTpRig.leftElbowHint,
        activeTpRig.leftGrip,
        true
      );
    }
  }
}
