export type WeaponId = 'ar' | 'pistol';

export interface WeaponSpec {
  id: WeaponId;
  code: string;
  name: string;
  caliber: string;
  fireMode: 'AUTO' | 'SEMI';
  rpm: number;
  magSize: number;
  startReserve: number;
  maxReserve: number;
  damage: number;
  tacticalReloadTime: number; // seconds when round in chamber
  dryReloadTime: number; // seconds when empty (includes bolt release / slide rack)
  adsFov: number;
  hipSpread: number;
  adsSpread: number;
  recoilKickZ: number;
  recoilPitch: number;
  recoilRoll: number;
  cameraPitchKick: number;
  cameraYawJitter: number;
}

export const WEAPON_SPECS: Record<WeaponId, WeaponSpec> = {
  ar: {
    id: 'ar',
    code: 'AR-15 CARBINE',
    name: 'AR-15 SEMI/AUTO RIFLE',
    caliber: '5.56x45MM NATO',
    fireMode: 'AUTO',
    rpm: 740,
    magSize: 30,
    startReserve: 150,
    maxReserve: 210,
    damage: 34,
    tacticalReloadTime: 2.05,
    dryReloadTime: 2.55,
    adsFov: 52,
    hipSpread: 0.026,
    adsSpread: 0.0022,
    recoilKickZ: 0.046,
    recoilPitch: 0.058,
    recoilRoll: 0.032,
    cameraPitchKick: 0.017,
    cameraYawJitter: 0.0065,
  },
  pistol: {
    id: 'pistol',
    code: 'GLOCK 17 GEN4',
    name: '9MM TACTICAL SIDEARM',
    caliber: '9x19MM PARABELLUM',
    fireMode: 'SEMI',
    rpm: 440,
    magSize: 17,
    startReserve: 85,
    maxReserve: 120,
    damage: 42,
    tacticalReloadTime: 1.65,
    dryReloadTime: 2.1,
    adsFov: 63,
    hipSpread: 0.018,
    adsSpread: 0.0018,
    recoilKickZ: 0.056,
    recoilPitch: 0.115,
    recoilRoll: 0.045,
    cameraPitchKick: 0.024,
    cameraYawJitter: 0.005,
  },
};

export interface BoxObstacle {
  id: string;
  x: number; // center X
  y: number; // base Y (usually 0, or stacked)
  z: number; // center Z
  w: number; // width X
  h: number; // height Y
  d: number; // depth Z
  variant: 'height1' | 'height1Plus' | 'wall' | 'platform';
  label?: string;
}

/** Finger curl angles (radians) for a first-person Xbot hand — [knuckle, middle, tip] joint per finger */
export interface HandGripPose {
  thumbOpp: number; // thumb swing toward (+) / away from (-) the palm
  thumb: [number, number, number];
  index: [number, number, number];
  middle: [number, number, number];
  ring: [number, number, number];
  pinky: [number, number, number];
}

export interface HudState {
  activeWeapon: WeaponId;
  ammoInMag: Record<WeaponId, number>;
  ammoReserve: Record<WeaponId, number>;
  isReloading: boolean;
  reloadProgress: number;
  adsAmount: number; // 0..1
  crosshairSpread: number; // pixels
  stance: 'STAND' | 'CROUCH' | 'SPRINT' | 'AIR';
  elevationY: number; // player feet height in meters
  cameraPerspective: 'FPV' | 'TPV';
  hitmarkerTime: number;
  isHeadshotHit: boolean;
  targetsHit: number;
  pointerLocked: boolean;
  cameraPlaced: boolean;
  recordedFramesCount: number;
  recordedDurationSec: number;
  isViewingClip: boolean;
  cameraNotice: string | null;
}
