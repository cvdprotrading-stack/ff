import * as THREE from 'three';
import { createAR15Model, createGlock17Model } from './weaponModels';
import { createGunMaterials, type GunMaterials } from './weaponMaterials';
import { HandGripPose, WeaponId } from './types';

export interface WeaponRig {
  id: WeaponId;
  root: THREE.Group;
  gunBody: THREE.Group;
  magGroup: THREE.Group;
  boltOrSlide: THREE.Group;
  chargingOrHammer: THREE.Group;
  trigger: THREE.Mesh;
  muzzleFlash: THREE.Group;
  muzzleAnchor: THREE.Object3D;
  ejectionAnchor: THREE.Object3D;
  /** First-person Xbot arm IK targets: wrist position + hand frame (local -Z = fingers, local -Y = palm) */
  rightHandTarget: THREE.Object3D;
  leftHandTarget: THREE.Object3D;
  rightElbowHint: THREE.Object3D;
  leftElbowHint: THREE.Object3D;
  rightGrip: HandGripPose;
  leftGrip: HandGripPose;
  reticleMat?: THREE.MeshBasicMaterial;
  stockAssembly?: THREE.Group;
  stockPad?: THREE.Mesh;
  hipPos: THREE.Vector3;
  hipRot: THREE.Euler;
  adsPos: THREE.Vector3;
  adsRot?: THREE.Euler;
  magRestPos: THREE.Vector3;
  magazineSocket: THREE.Object3D;
  magazineGrip: THREE.Object3D;
  magazineBody: THREE.Mesh;
}

// ---------------------------------------------------------------------------
// HAND POSES & FINGER GRIPS
// ---------------------------------------------------------------------------
type V3 = [number, number, number];

interface HandPose {
  pos: THREE.Vector3;
  quat: THREE.Quaternion;
}

/** Wrist position + hand frame in weapon-root space: `fwd` = wrist→knuckles, `palm` = palm normal */
function handPose(pos: V3, fwd: V3, palm: V3): HandPose {
  const f = new THREE.Vector3(...fwd).normalize();
  const p = new THREE.Vector3(...palm);
  p.addScaledVector(f, -p.dot(f)).normalize();
  const z = f.clone().negate();
  const y = p.clone().negate();
  const x = new THREE.Vector3().crossVectors(y, z).normalize();
  return {
    pos: new THREE.Vector3(...pos),
    quat: new THREE.Quaternion().setFromRotationMatrix(new THREE.Matrix4().makeBasis(x, y, z)),
  };
}

function grip(thumbOpp: number, thumb: V3, index: V3, middle: V3, ring: V3, pinky: V3): HandGripPose {
  return { thumbOpp, thumb, index, middle, ring, pinky };
}

function cloneGrip(g: HandGripPose): HandGripPose {
  return {
    thumbOpp: g.thumbOpp,
    thumb: [...g.thumb],
    index: [...g.index],
    middle: [...g.middle],
    ring: [...g.ring],
    pinky: [...g.pinky],
  };
}

const GRIP_KEYS = ['thumb', 'index', 'middle', 'ring', 'pinky'] as const;

function lerpGrip(out: HandGripPose, a: HandGripPose, b: HandGripPose, k: number) {
  out.thumbOpp = a.thumbOpp + (b.thumbOpp - a.thumbOpp) * k;
  for (const key of GRIP_KEYS) {
    for (let i = 0; i < 3; i++) out[key][i] = a[key][i] + (b[key][i] - a[key][i]) * k;
  }
}

function copyGrip(out: HandGripPose, a: HandGripPose) {
  lerpGrip(out, a, a, 0);
}

function setHand(target: THREE.Object3D, pose: HandPose, dx = 0, dy = 0, dz = 0) {
  target.position.set(pose.pos.x + dx, pose.pos.y + dy, pose.pos.z + dz);
  target.quaternion.copy(pose.quat);
}

function followMagazine(rig: WeaponRig, pose: HandPose) {
  rig.leftHandTarget.position.copy(rig.magazineGrip.position)
    .applyQuaternion(rig.magGroup.quaternion).add(rig.magGroup.position);
  rig.leftHandTarget.quaternion.copy(pose.quat);
}

function blendHand(target: THREE.Object3D, a: HandPose, b: HandPose, k: number, aOff?: V3, bOff?: V3) {
  target.position.set(
    THREE.MathUtils.lerp(a.pos.x + (aOff?.[0] ?? 0), b.pos.x + (bOff?.[0] ?? 0), k),
    THREE.MathUtils.lerp(a.pos.y + (aOff?.[1] ?? 0), b.pos.y + (bOff?.[1] ?? 0), k),
    THREE.MathUtils.lerp(a.pos.z + (aOff?.[2] ?? 0), b.pos.z + (bOff?.[2] ?? 0), k)
  );
  target.quaternion.slerpQuaternions(a.quat, b.quat, k);
}

const GRIPS = {
  rifleTrigger: grip(0.3, [0.2, 0.35, 0.3], [0.2, 0.6, 0.35], [1.3, 1.25, 0.75], [1.35, 1.25, 0.75], [1.4, 1.2, 0.7]),
  rifleSupport: grip(-0.1, [0.05, 0.12, 0.1], [0.8, 0.8, 0.45], [0.9, 0.9, 0.5], [0.95, 0.9, 0.5], [1.0, 0.85, 0.45]),
  magGrab: grip(0.35, [0.25, 0.3, 0.25], [0.9, 0.95, 0.55], [1.0, 1.05, 0.6], [1.05, 1.05, 0.6], [1.1, 1.0, 0.55]),
  chargingHandle: grip(0.2, [0.18, 0.3, 0.2], [0.65, 0.8, 0.45], [0.7, 0.8, 0.45], [0.75, 0.8, 0.45], [0.8, 0.75, 0.4]),
  flat: grip(-0.15, [0.0, 0.05, 0.05], [0.12, 0.15, 0.1], [0.12, 0.15, 0.1], [0.15, 0.15, 0.1], [0.18, 0.15, 0.1]),
  pistolTrigger: grip(0.3, [0.05, 0.15, 0.1], [0.25, 0.75, 0.4], [1.35, 1.3, 0.8], [1.4, 1.3, 0.8], [1.45, 1.25, 0.75]),
  pistolSupport: grip(-0.6, [0.0, 0.08, 0.05], [1.0, 1.0, 0.6], [1.05, 1.05, 0.6], [1.1, 1.05, 0.6], [1.15, 1.0, 0.55]),
  slideRack: grip(0.25, [0.3, 0.35, 0.25], [1.05, 1.1, 0.7], [1.1, 1.15, 0.7], [1.15, 1.1, 0.7], [1.2, 1.05, 0.65]),
};

const AR_HANDS = {
  rightGrip: GRIPS.rifleTrigger,
  leftGrip: GRIPS.rifleSupport,
  right: handPose([0.036, -0.05, 0.15], [-0.12, -0.36, -0.92], [-1, 0, 0]),
  leftRest: handPose([-0.047, -0.058, -0.19], [0.55, 0.0, -0.83], [0.4, 0.9, 0.0]),
  leftMag: handPose([-0.042, -0.11, -0.01], [0.1, -0.45, -0.89], [1, 0, 0]),
  // Wrist sits outside the left side of the receiver while the fingers reach
  // the rear charging-handle latch. The whole pose follows the moving handle.
  leftCharging: handPose([-0.158, 0.054, 0.154], [0.7, -0.2, -0.68], [1, -0.18, 0]),
  rightElbow: [0.3, -0.32, 0.22] as V3,
  leftElbow: [-0.34, -0.36, 0.0] as V3,
};

// Normalized times shared by animation, third-person IK and reload audio.
export const AR_RELOAD_TIMING = {
  magSeated: 0.67,
  handleReached: 0.77,
  handlePulled: 0.83,
  handleReleased: 0.87,
} as const;

const AR_CHARGE_TRAVEL = 0.042;

const PISTOL_HANDS = {
  rightGrip: GRIPS.pistolTrigger,
  leftGrip: GRIPS.pistolSupport,
  right: handPose([0.031, -0.025, 0.128], [-0.1, -0.25, -0.96], [-1, 0, 0]),
  leftRest: handPose([-0.05, -0.02, 0.085], [0.3, -0.65, -0.7], [1, 0, 0]),
  leftMag: handPose([-0.014, -0.155, 0.104], [0.3, 0.2, -0.93], [0.2, 0.95, -0.25]),
  leftRack: handPose([-0.066, 0.046, 0.045], [1, -0.25, 0], [0, -1, 0]),
  rightElbow: [0.28, -0.32, 0.25] as V3,
  leftElbow: [-0.3, -0.38, 0.18] as V3,
};

function createHandRig(
  root: THREE.Group,
  hands: typeof AR_HANDS | typeof PISTOL_HANDS
): Pick<WeaponRig, 'rightHandTarget' | 'leftHandTarget' | 'rightElbowHint' | 'leftElbowHint' | 'rightGrip' | 'leftGrip'> {
  const rightHandTarget = new THREE.Object3D();
  setHand(rightHandTarget, hands.right);
  const leftHandTarget = new THREE.Object3D();
  setHand(leftHandTarget, hands.leftRest);
  const rightElbowHint = new THREE.Object3D();
  rightElbowHint.position.set(...hands.rightElbow);
  const leftElbowHint = new THREE.Object3D();
  leftElbowHint.position.set(...hands.leftElbow);
  root.add(rightHandTarget, leftHandTarget, rightElbowHint, leftElbowHint);
  return {
    rightHandTarget,
    leftHandTarget,
    rightElbowHint,
    leftElbowHint,
    rightGrip: cloneGrip(hands.rightGrip),
    leftGrip: cloneGrip(hands.leftGrip),
  };
}

// Model geometry and animation share one coordinate frame in both perspectives.
export function buildAssaultRifleRig(mats: GunMaterials): WeaponRig {
  const model = createAR15Model(mats);
  const hands = createHandRig(model.root, AR_HANDS);
  const hipPos = new THREE.Vector3(0.15, -0.13, -0.5);
  const hipRot = new THREE.Euler(0, 0.07, 0);
  const adsPos = new THREE.Vector3(0, -0.08, -0.205);
  model.root.position.copy(hipPos);
  model.root.rotation.copy(hipRot);
  return { ...model, ...hands, id: 'ar', hipPos, hipRot, adsPos };
}

export function buildPistolRig(mats: GunMaterials): WeaponRig {
  const model = createGlock17Model(mats);
  const hands = createHandRig(model.root, PISTOL_HANDS);
  const hipPos = new THREE.Vector3(0.12, -0.1, -0.44);
  const hipRot = new THREE.Euler(0, 0.018, 0);
  const adsPos = new THREE.Vector3(0, -0.0365, -0.48);
  model.root.position.copy(hipPos);
  model.root.rotation.copy(hipRot);
  return { ...model, ...hands, id: 'pistol', hipPos, hipRot, adsPos };
}

export interface ViewmodelAnimParams {
  dt: number;
  time: number;
  adsAmount: number; // 0..1
  isSprinting: boolean;
  moveSpeedNorm: number; // 0..1
  grounded: boolean;
  verticalVel: number;
  landDip: number;
  mouseSwayX: number;
  mouseSwayY: number;
  recoilPosZ: number;
  recoilPitch: number;
  recoilRoll: number;
  boltCycle: number; // 0..1 instantaneous shot cycle
  ammoInMag: number;
  isReloading: boolean;
  reloadProgress: number; // 0..1
  isDryReload: boolean;
  /** Reduce the off-screen first-person reload travel to stay within a full-body arm's reach. */
  reloadReachScale?: number;
  firstPerson?: boolean;
  equipAlpha: number; // 0..1 weapon draw
  muzzleFlashTimer: number;
}

export function createFirstPersonWeapons(): Record<WeaponId, WeaponRig> {
  const mats = createGunMaterials();
  return {
    ar: buildAssaultRifleRig(mats),
    pistol: buildPistolRig(mats),
  };
}

export function updateWeaponAnimation(rig: WeaponRig, p: ViewmodelAnimParams) {
  const { adsAmount } = p;

  // 1. Hip <-> ADS interpolation
  const adsSmooth = adsAmount * adsAmount * (3 - 2 * adsAmount);
  const targetPos = new THREE.Vector3().lerpVectors(rig.hipPos, rig.adsPos, adsSmooth);

  let targetRotX = THREE.MathUtils.lerp(rig.hipRot.x, rig.adsRot?.x ?? 0, adsSmooth);
  let targetRotY = THREE.MathUtils.lerp(rig.hipRot.y, rig.adsRot?.y ?? 0, adsSmooth);
  let targetRotZ = THREE.MathUtils.lerp(rig.hipRot.z, rig.adsRot?.z ?? 0, adsSmooth);

  // 2. Equip / weapon switch raise
  const drawEase = 1 - Math.pow(1 - Math.min(1, Math.max(0, p.equipAlpha)), 3);
  targetPos.y -= (1 - drawEase) * 0.24;
  targetRotX -= (1 - drawEase) * 0.55;
  targetRotZ += (1 - drawEase) * 0.22;

  // 3. Idle breathing & locomotion bob (damped in ADS)
  const swayScale = THREE.MathUtils.lerp(1.0, 0.12, adsSmooth);
  const breathX = Math.sin(p.time * 1.6) * 0.0018 * swayScale;
  const breathY = Math.cos(p.time * 3.2) * 0.0022 * swayScale;

  const walkFreq = p.isSprinting ? 11.5 : 8.4;
  const bobAmp = p.grounded ? p.moveSpeedNorm * (p.isSprinting ? 0.016 : 0.0085) * swayScale : 0;
  const bobX = Math.cos(p.time * walkFreq) * bobAmp;
  const bobY = Math.abs(Math.sin(p.time * walkFreq)) * bobAmp * 1.15 - bobAmp * 0.5;
  const bobRoll = Math.cos(p.time * walkFreq) * bobAmp * 1.6;

  targetPos.x += breathX + bobX;
  targetPos.y += breathY + bobY;
  targetRotZ += bobRoll;

  // 4. Tactical sprint pose
  const sprintFactor = p.isSprinting && !p.isReloading && adsSmooth < 0.15 ? 1 : 0;
  const curSprint = THREE.MathUtils.lerp(rig.root.userData.sprintBlend ?? 0, sprintFactor, Math.min(1, p.dt * 11));
  rig.root.userData.sprintBlend = curSprint;

  if (curSprint > 0.001) {
    if (rig.id === 'ar') {
      targetPos.x -= curSprint * 0.065;
      targetPos.y -= curSprint * 0.035;
      targetPos.z += curSprint * 0.04;
      targetRotX -= curSprint * 0.24;
      targetRotY += curSprint * 0.58;
      targetRotZ += curSprint * 0.26;
    } else {
      targetPos.x -= curSprint * 0.035;
      targetPos.y += curSprint * 0.045;
      targetPos.z += curSprint * 0.05;
      targetRotX += curSprint * 0.42;
      targetRotY += curSprint * 0.22;
      targetRotZ += curSprint * 0.18;
    }
  }

  // 5. Mouse sway & airborne / landing inertia
  const mouseFactor = THREE.MathUtils.lerp(1.0, 0.28, adsSmooth);
  targetPos.x -= p.mouseSwayX * 0.028 * mouseFactor;
  targetPos.y -= p.mouseSwayY * 0.028 * mouseFactor;
  targetRotY -= p.mouseSwayX * 0.65 * mouseFactor;
  targetRotX -= p.mouseSwayY * 0.55 * mouseFactor;
  targetRotZ -= p.mouseSwayX * 0.55 * mouseFactor;

  const airLagY = THREE.MathUtils.clamp(-p.verticalVel * 0.0045, -0.028, 0.028) * mouseFactor;
  targetPos.y += airLagY - p.landDip * 0.035 * mouseFactor;
  targetRotX -= p.landDip * 0.16 * mouseFactor;

  // 6. Recoil kick & trigger pull
  const adsRecoilDamp = THREE.MathUtils.lerp(1.0, 0.68, adsSmooth);
  targetPos.z += p.recoilPosZ * adsRecoilDamp;
  targetPos.y += p.recoilPosZ * 0.15 * adsRecoilDamp;
  targetRotX += p.recoilPitch * adsRecoilDamp;
  targetRotZ += p.recoilRoll * adsRecoilDamp;

  rig.trigger.rotation.x = 0.24 - Math.min(1, p.boltCycle * 1.4) * 0.35;

  // 7. Bolt carrier (AR) / slide (pistol) — both lock open on an empty magazine
  let boltBackOffset = 0;
  if (rig.id === 'ar') {
    const emptyLock = p.ammoInMag === 0 && (!p.isReloading || p.reloadProgress < AR_RELOAD_TIMING.handleReleased) ? 0.05 : 0;
    boltBackOffset = Math.max(emptyLock, p.boltCycle * 0.055);
    rig.chargingOrHammer.position.z = 0;
  } else {
    const emptyLock = p.ammoInMag === 0 && (!p.isReloading || p.reloadProgress < 0.78) ? 0.042 : 0;
    boltBackOffset = Math.max(emptyLock, p.boltCycle * 0.046);
    rig.chargingOrHammer.rotation.x = p.boltCycle > 0.5 ? 0.35 : 0;
  }

  // 8. Hands: rest grip every frame, then the multi-stage reload choreography
  rig.magGroup.position.copy(rig.magazineSocket.position);
  rig.magGroup.quaternion.copy(rig.magazineSocket.quaternion);
  rig.magGroup.visible = true;

  const left = rig.leftHandTarget;
  if (rig.id === 'ar') {
    setHand(left, AR_HANDS.leftRest);
    copyGrip(rig.leftGrip, AR_HANDS.leftGrip);
    copyGrip(rig.rightGrip, AR_HANDS.rightGrip);
  } else {
    setHand(left, PISTOL_HANDS.leftRest);
    copyGrip(rig.leftGrip, PISTOL_HANDS.leftGrip);
    copyGrip(rig.rightGrip, PISTOL_HANDS.rightGrip);
  }
  // Trigger finger squeezes with every shot
  const squeeze = Math.min(1, p.boltCycle * 1.4);
  rig.rightGrip.index[0] += squeeze * 0.06;
  rig.rightGrip.index[1] += squeeze * 0.28;
  rig.rightGrip.index[2] += squeeze * 0.12;

  if (p.isReloading) {
    const t = p.reloadProgress;
    const reach = p.reloadReachScale ?? 1;
    const workspaceEnvelope = t < 0.12 ? smoothstep(0, 0.12, t) : t > 0.88 ? 1 - smoothstep(0.88, 1.0, t) : 1.0;

    if (rig.id === 'ar') {
      const H = AR_HANDS;
      // Lift the rifle into view and roll it so the magwell faces the camera
      targetPos.x -= workspaceEnvelope * 0.05;
      targetPos.y += workspaceEnvelope * 0.075;
      targetPos.z += workspaceEnvelope * 0.06;
      targetRotZ -= workspaceEnvelope * 0.62;
      targetRotX += workspaceEnvelope * 0.1;
      targetRotY += workspaceEnvelope * 0.3;

      if (p.firstPerson) {
        // Give the support arm room to reach the rear without sweeping across
        // the entire camera or hiding the charging handle behind the forearm.
        const rearReach = smoothstep(0.68, AR_RELOAD_TIMING.handleReached, t) *
          (1 - smoothstep(AR_RELOAD_TIMING.handleReleased, 0.98, t));
        targetPos.x -= rearReach * 0.08;
        targetPos.y -= rearReach * 0.085;
        targetPos.z -= rearReach * 0.22;
      }

      if (t < 0.15) {
        // Support hand leaves the handguard and grabs the magazine
        const k = smoothstep(0, 0.15, t);
        blendHand(left, H.leftRest, H.leftMag, k);
        lerpGrip(rig.leftGrip, GRIPS.rifleSupport, GRIPS.magGrab, k);
      } else if (t < 0.36) {
        // Strip the spent magazine down out of the magwell
        const k = smoothstep(0.15, 0.36, t);
        const dropY = -k * 0.26 * reach;
        const dropZ = k * 0.035;
        rig.magGroup.position.set(rig.magRestPos.x, rig.magRestPos.y + dropY, rig.magRestPos.z + dropZ);
        followMagazine(rig, H.leftMag);
        copyGrip(rig.leftGrip, GRIPS.magGrab);
        targetPos.y -= Math.sin(k * Math.PI) * 0.014;
      } else if (t < 0.45) {
        // Stow it and pull a fresh magazine from the chest pouch (off-screen)
        rig.magGroup.visible = false;
        const away = Math.sin(((t - 0.36) / 0.09) * Math.PI);
        setHand(left, H.leftMag, -away * 0.05, -reach * (0.26 + away * 0.16), 0.035 + away * 0.04);
        copyGrip(rig.leftGrip, GRIPS.magGrab);
      } else if (t < AR_RELOAD_TIMING.magSeated) {
        // Guide the fresh magazine up and seat it
        const k = smoothstep(0.45, AR_RELOAD_TIMING.magSeated, t);
        const liftY = (1 - k) * -0.26 * reach;
        const liftZ = (1 - k) * 0.03;
        rig.magGroup.position.set(rig.magRestPos.x, rig.magRestPos.y + liftY, rig.magRestPos.z + liftZ);
        followMagazine(rig, H.leftMag);
        copyGrip(rig.leftGrip, GRIPS.magGrab);
        if (k > 0.8) {
          const slam = Math.sin(((k - 0.8) / 0.2) * Math.PI);
          targetPos.y += slam * 0.018;
          targetRotX += slam * 0.07;
        }
      } else if (t < AR_RELOAD_TIMING.handleReached) {
        // After seating the magazine the support hand reaches the rear latch.
        const k = smoothstep(AR_RELOAD_TIMING.magSeated, AR_RELOAD_TIMING.handleReached, t);
        blendHand(left, H.leftMag, H.leftCharging, k);
        lerpGrip(rig.leftGrip, GRIPS.magGrab, GRIPS.chargingHandle, k);
      } else if (t < AR_RELOAD_TIMING.handleReleased) {
        // Pull the rear charging handle and let it spring forward with the bolt.
        const pull = smoothstep(AR_RELOAD_TIMING.handleReached, AR_RELOAD_TIMING.handlePulled, t);
        const release = smoothstep(AR_RELOAD_TIMING.handlePulled, AR_RELOAD_TIMING.handleReleased, t);
        const travel = AR_CHARGE_TRAVEL * pull * (1 - release);
        rig.chargingOrHammer.position.z = travel;
        setHand(left, H.leftCharging, 0, 0, travel);
        copyGrip(rig.leftGrip, GRIPS.chargingHandle);
        boltBackOffset = p.isDryReload ? 0.05 * (1 - release) : 0.05 * pull * (1 - release);
        targetPos.z += 0.008 * pull * (1 - release);
      } else {
        // Return the support hand to the handguard
        const k = smoothstep(AR_RELOAD_TIMING.handleReleased, 1.0, t);
        blendHand(left, H.leftCharging, H.leftRest, k);
        lerpGrip(rig.leftGrip, GRIPS.chargingHandle, GRIPS.rifleSupport, k);
      }
    } else {
      const H = PISTOL_HANDS;
      // Bring the pistol up and in, tilting the grip toward the support hand
      targetPos.x -= workspaceEnvelope * 0.05;
      targetPos.y += workspaceEnvelope * 0.06;
      targetPos.z += workspaceEnvelope * 0.05;
      targetRotZ -= workspaceEnvelope * 0.55;
      targetRotX += workspaceEnvelope * 0.2;
      targetRotY += workspaceEnvelope * 0.3;

      const dropDist = 0.2 * reach;
      // The support hand grips the base of the magazine and follows it wherever
      // the magazine is, so the hand never leaves the magazine during the reload.
      const magBase = () =>
        new THREE.Vector3(
          rig.magGroup.position.x,
          rig.magGroup.position.y - 0.048,
          rig.magGroup.position.z + 0.006
        );

      if (t < 0.3) {
        // Stage 1 — grab the magazine base, then pull it out along the grip.
        const kGrab = smoothstep(0.0, 0.1, t);   // hand moves from support grip to the mag base
        const kMag = smoothstep(0.1, 0.3, t);    // then the magazine slides out
        rig.magGroup.visible = true;
        rig.magGroup.position.set(
          rig.magRestPos.x,
          rig.magRestPos.y - kMag * dropDist,
          rig.magRestPos.z + kMag * 0.03
        );
        // Hand grips the base of the (descending) magazine and follows it
        left.position.lerpVectors(H.leftRest.pos, magBase(), kGrab);
        left.quaternion.slerpQuaternions(H.leftRest.quat, rig.magGroup.quaternion, kGrab);
        copyGrip(rig.leftGrip, GRIPS.magGrab);
      } else if (t < 0.42) {
        // Stage 2 — stow the spent mag, reach for a fresh one (mag hidden during the handoff)
        rig.magGroup.visible = false;
        const k = smoothstep(0.3, 0.42, t);
        const fromMag = new THREE.Vector3(rig.magRestPos.x, rig.magRestPos.y - dropDist - 0.048, rig.magRestPos.z + 0.036);
        const toBelt = new THREE.Vector3(rig.magRestPos.x - 0.05, rig.magRestPos.y - dropDist - 0.075, rig.magRestPos.z + 0.1);
        left.position.lerpVectors(fromMag, toBelt, smoothstep(0, 1, k * 2 - 1) * 0.5);
        if (k >= 0.5) left.position.lerpVectors(toBelt, magBase(), (k - 0.5) * 2);
        left.quaternion.slerpQuaternions(rig.magGroup.quaternion, rig.magGroup.quaternion, 1);
        copyGrip(rig.leftGrip, GRIPS.magGrab);
      } else if (t < 0.66) {
        // Stage 3 — bring the fresh magazine up and seat it; the hand follows it up
        const k = smoothstep(0.42, 0.66, t);
        const offset = 1 - k;
        rig.magGroup.visible = true;
        rig.magGroup.position.set(
          rig.magRestPos.x,
          rig.magRestPos.y - offset * dropDist,
          rig.magRestPos.z + offset * 0.03
        );
        left.position.copy(magBase());
        left.quaternion.copy(rig.magGroup.quaternion);
        copyGrip(rig.leftGrip, GRIPS.magGrab);
        if (k > 0.82) {
          const slam = Math.sin(((k - 0.82) / 0.18) * Math.PI);
          targetPos.y += slam * 0.016;
          targetRotX += slam * 0.07;
        }
      } else if (p.isDryReload && t < 0.87) {
        // Stage 4 (empty mag) — overhand slide rack
        const k = smoothstep(0.66, 0.87, t);
        if (k < 0.55) {
          const sub = smoothstep(0, 1, k / 0.55);
          left.position.lerpVectors(H.leftRest.pos, H.leftRack.pos, sub);
          left.quaternion.slerpQuaternions(H.leftRest.quat, H.leftRack.quat, sub);
          lerpGrip(rig.leftGrip, GRIPS.magGrab, GRIPS.slideRack, sub);
          boltBackOffset = 0.042 + sub * 0.01;
        } else {
          const sub = (k - 0.55) / 0.45;
          boltBackOffset = (1 - Math.min(1, sub * 3)) * 0.052; // slide snaps forward on release
          left.position.lerpVectors(H.leftRack.pos, H.leftRest.pos, Math.min(1, sub * 2));
          lerpGrip(rig.leftGrip, GRIPS.slideRack, GRIPS.flat, Math.min(1, sub * 2));
        }
      } else {
        // Stage 5 — return the support hand to the thumb-forward support grip
        const startT = p.isDryReload ? 0.87 : 0.66;
        const k = smoothstep(startT, 1.0, t);
        const fromPos = p.isDryReload ? H.leftRack.pos : magBase();
        left.position.lerpVectors(fromPos, H.leftRest.pos, k);
        left.quaternion.slerpQuaternions(p.isDryReload ? H.leftRack.quat : rig.magGroup.quaternion, H.leftRest.quat, k);
        lerpGrip(rig.leftGrip, p.isDryReload ? GRIPS.slideRack : GRIPS.magGrab, GRIPS.pistolSupport, k);
      }
    }
  }

  rig.boltOrSlide.position.z = boltBackOffset;

  // Holographic reticle crispness in ADS
  if (rig.reticleMat) {
    rig.reticleMat.opacity = THREE.MathUtils.lerp(0.45, 0.98, adsSmooth);
  }

  // Muzzle flash
  if (p.muzzleFlashTimer > 0) {
    rig.muzzleFlash.visible = true;
    rig.muzzleFlash.rotation.z = (p.time * 97) % (Math.PI * 2);
    const s = (rig.id === 'ar' ? 1.0 : 0.72) * (0.85 + Math.random() * 0.35);
    rig.muzzleFlash.scale.setScalar(s);
  } else {
    rig.muzzleFlash.visible = false;
  }

  rig.root.position.copy(targetPos);
  rig.root.rotation.set(targetRotX, targetRotY, targetRotZ);
}

function smoothstep(edge0: number, edge1: number, x: number): number {
  const t = Math.max(0, Math.min(1, (x - edge0) / (edge1 - edge0)));
  return t * t * (3 - 2 * t);
}
