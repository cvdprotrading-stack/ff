import * as THREE from 'three';

function surfaceMaps(polymer: boolean) {
  const size = 512;
  const heightCanvas = document.createElement('canvas');
  const roughCanvas = document.createElement('canvas');
  const colorCanvas = document.createElement('canvas');
  heightCanvas.width = roughCanvas.width = colorCanvas.width = size;
  heightCanvas.height = roughCanvas.height = colorCanvas.height = size;
  const heightCtx = heightCanvas.getContext('2d')!;
  const roughCtx = roughCanvas.getContext('2d')!;
  const colorCtx = colorCanvas.getContext('2d')!;
  const h = heightCtx.createImageData(size, size);
  const r = roughCtx.createImageData(size, size);
  const albedo = colorCtx.createImageData(size, size);
  let seed = polymer ? 29 : 7;
  const random = () => {
    seed = (Math.imul(1664525, seed) + 1013904223) >>> 0;
    return seed / 4294967296;
  };
  for (let i = 0; i < size * size; i++) {
    const noise = random();
    const hv = 128;
    const rv = polymer ? 228 + noise * 20 : 218 + noise * 27;
    for (let c = 0; c < 3; c++) {
      h.data[i * 4 + c] = hv;
      r.data[i * 4 + c] = rv;
      // Neutral albedo lets the part's physically-based base colour drive its finish.
      albedo.data[i * 4 + c] = 250;
    }
    h.data[i * 4 + 3] = r.data[i * 4 + 3] = 255;
    albedo.data[i * 4 + 3] = 255;
  }
  heightCtx.putImageData(h, 0, 0);
  roughCtx.putImageData(r, 0, 0);
  colorCtx.putImageData(albedo, 0, 0);
  if (polymer) {
    // Fine molded stipple with restrained relief; no high-contrast pebbling.
    for (let y = 3; y < size; y += 5) {
      for (let x = 3 + ((y / 5) % 2) * 2; x < size; x += 5) {
        heightCtx.fillStyle = '#696969';
        heightCtx.beginPath();
        heightCtx.arc(x, y, 0.9, 0, Math.PI * 2);
        heightCtx.fill();
      }
    }
  } else {
    // Directional bead-blast texture and sparse machining hairlines. Relief is
    // visible in grazing highlights but remains subtle on the broad surfaces.
    for (let y = 1; y < size; y += 2) {
      heightCtx.strokeStyle = y % 6 === 0 ? 'rgba(172,172,172,0.45)' : 'rgba(78,78,78,0.34)';
      heightCtx.lineWidth = 0.45;
      heightCtx.beginPath();
      heightCtx.moveTo(0, y);
      heightCtx.lineTo(size, y);
      heightCtx.stroke();
    }
    for (let i = 0; i < 58; i++) {
      const x = random() * size;
      const y = random() * size;
      const length = 4 + random() * 25;
      heightCtx.strokeStyle = random() > 0.5 ? 'rgba(190,190,190,0.3)' : 'rgba(64,64,64,0.25)';
      heightCtx.lineWidth = 0.5;
      heightCtx.beginPath(); heightCtx.moveTo(x, y); heightCtx.lineTo(x + length, y + (random() - 0.5)); heightCtx.stroke();
    }
  }
  const bump = new THREE.CanvasTexture(heightCanvas);
  const roughness = new THREE.CanvasTexture(roughCanvas);
  const color = new THREE.CanvasTexture(colorCanvas);
  color.colorSpace = THREE.SRGBColorSpace;
  for (const map of [bump, roughness, color]) {
    map.wrapS = map.wrapT = THREE.RepeatWrapping;
    map.anisotropy = 8;
  }
  return { bumpMap: bump, roughnessMap: roughness, map: color };
}

export function createGunMaterials() {
  const metalMaps = surfaceMaps(false);
  const polymerMaps = surfaceMaps(true);
  const metal = (color: number, roughness: number, metalness = 0.5) => new THREE.MeshPhysicalMaterial({
    color, roughness, metalness, ...metalMaps, bumpScale: 0.0001, envMapIntensity: 1.35,
    clearcoat: 0.32, clearcoatRoughness: 0.34,
  });
  const plastic = (color: number, roughness: number, stipple = 0.00007) => new THREE.MeshPhysicalMaterial({
    color, roughness, metalness: 0.02, ...polymerMaps, bumpScale: stipple, envMapIntensity: 0.95,
    clearcoat: 0.13, clearcoatRoughness: 0.62,
  });
  return {
    receiver: metal(0x6b7075, 0.44),
    darkMetal: metal(0x45494e, 0.46),
    steel: metal(0xa4a8aa, 0.3, 0.72),
    barrel: metal(0x545960, 0.37, 0.7),
    slide: metal(0x70757a, 0.36, 0.56),
    magazine: metal(0x565b60, 0.44, 0.45),
    polymer: plastic(0x3a3d40, 0.75),
    stipple: plastic(0x303336, 0.9, 0.0001),
    rubber: plastic(0x2a2d30, 0.92, 0.00006),
    inset: new THREE.MeshStandardMaterial({ color: 0x080a0c, roughness: 0.88, metalness: 0.15 }),
    brass: new THREE.MeshStandardMaterial({ color: 0xcda14a, roughness: 0.27, metalness: 0.86 }),
    copper: new THREE.MeshStandardMaterial({ color: 0xb67651, roughness: 0.3, metalness: 0.8 }),
    sightPaint: new THREE.MeshBasicMaterial({ color: 0xe3e8dc, toneMapped: false }),
    glass: new THREE.MeshPhysicalMaterial({ color: 0x86b5c1, roughness: 0.06, metalness: 0.2, transparent: true, opacity: 0.12, depthWrite: false, side: THREE.DoubleSide }),
  };
}

export type GunMaterials = ReturnType<typeof createGunMaterials>;