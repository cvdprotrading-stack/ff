import * as THREE from 'three';

export function createEnvironmentMap(renderer: THREE.WebGLRenderer): THREE.Texture {
  const pmrem = new THREE.PMREMGenerator(renderer);
  pmrem.compileEquirectangularShader();

  const canvas = document.createElement('canvas');
  canvas.width = 1024;
  canvas.height = 512;
  const ctx = canvas.getContext('2d')!;

  // Sky to horizon to ground gradient
  const grad = ctx.createLinearGradient(0, 0, 0, 512);
  grad.addColorStop(0.0, '#1f3b5c');
  grad.addColorStop(0.32, '#5c82a8');
  grad.addColorStop(0.48, '#cbd9e6');
  grad.addColorStop(0.51, '#d8cfc2');
  grad.addColorStop(0.55, '#525861');
  grad.addColorStop(1.0, '#23272d');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, 1024, 512);

  // Bright sun glow for crisp metallic speculars on gun barrels & slides
  const sunGrad = ctx.createRadialGradient(740, 145, 4, 740, 145, 150);
  sunGrad.addColorStop(0, 'rgba(255, 252, 240, 1.0)');
  sunGrad.addColorStop(0.18, 'rgba(255, 236, 198, 0.85)');
  sunGrad.addColorStop(0.5, 'rgba(220, 210, 195, 0.22)');
  sunGrad.addColorStop(1, 'rgba(220, 210, 195, 0.0)');
  ctx.fillStyle = sunGrad;
  ctx.fillRect(560, 0, 380, 320);

  // Secondary cool sky fill highlight
  const fillGrad = ctx.createRadialGradient(240, 170, 10, 240, 170, 220);
  fillGrad.addColorStop(0, 'rgba(185, 218, 255, 0.45)');
  fillGrad.addColorStop(1, 'rgba(185, 218, 255, 0.0)');
  ctx.fillStyle = fillGrad;
  ctx.fillRect(0, 0, 480, 380);

  const equirect = new THREE.CanvasTexture(canvas);
  equirect.mapping = THREE.EquirectangularReflectionMapping;
  equirect.colorSpace = THREE.SRGBColorSpace;

  const envRT = pmrem.fromEquirectangular(equirect);
  equirect.dispose();
  pmrem.dispose();
  return envRT.texture;
}

export function createGroundGridTexture(): THREE.CanvasTexture {
  const size = 512;
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d')!;

  // Smooth architectural concrete graybox base
  ctx.fillStyle = '#3a4048';
  ctx.fillRect(0, 0, size, size);

  // Subtle micro-grain for crisp depth perception while sprinting
  for (let i = 0; i < 6500; i++) {
    const x = Math.random() * size;
    const y = Math.random() * size;
    const v = 50 + Math.floor(Math.random() * 24);
    ctx.fillStyle = `rgba(${v}, ${v + 4}, ${v + 9}, 0.18)`;
    ctx.fillRect(x, y, 2, 2);
  }

  // Minor 0.25m subdivisions (4 per tile = 1m tile)
  ctx.strokeStyle = 'rgba(255, 255, 255, 0.055)';
  ctx.lineWidth = 1;
  const step = size / 4;
  for (let i = 1; i < 4; i++) {
    ctx.beginPath();
    ctx.moveTo(i * step, 0);
    ctx.lineTo(i * step, size);
    ctx.stroke();

    ctx.beginPath();
    ctx.moveTo(0, i * step);
    ctx.lineTo(size, i * step);
    ctx.stroke();
  }

  // Major 1.0m border lines
  ctx.strokeStyle = 'rgba(220, 232, 245, 0.17)';
  ctx.lineWidth = 2.5;
  ctx.strokeRect(1, 1, size - 2, size - 2);

  // Corner CAD cross ticks
  ctx.strokeStyle = 'rgba(245, 158, 11, 0.35)';
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(0, 14);
  ctx.lineTo(0, 0);
  ctx.lineTo(14, 0);
  ctx.stroke();

  const tex = new THREE.CanvasTexture(canvas);
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  tex.repeat.set(60, 60);
  tex.anisotropy = 8;
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

export function createBoxFaceTexture(
  variant: 'height1' | 'height1Plus' | 'wall' | 'platform',
  labelText: string,
  isTopFace = false
): THREE.CanvasTexture {
  const size = 512;
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d')!;

  const palette = {
    height1: {
      bg: isTopFace ? '#596169' : '#4d545d',
      border: '#d97706',
      accent: '#f59e0b',
      badgeBg: 'rgba(15, 20, 26, 0.78)',
      sub: 'HEIGHT 1 // JUMPABLE',
    },
    height1Plus: {
      bg: isTopFace ? '#48505a' : '#3e4650',
      border: '#64748b',
      accent: '#ef4444',
      badgeBg: 'rgba(15, 20, 26, 0.82)',
      sub: '1+ HEIGHT // NO JUMP',
    },
    platform: {
      bg: '#4b535e',
      border: '#94a3b8',
      accent: '#38bdf8',
      badgeBg: 'rgba(15, 20, 26, 0.72)',
      sub: 'BLOCKOUT STRUCTURE',
    },
    wall: {
      bg: '#343b43',
      border: '#4b5563',
      accent: '#94a3b8',
      badgeBg: 'rgba(15, 20, 26, 0.65)',
      sub: 'PERIMETER BOUNDARY',
    },
  }[variant];

  ctx.fillStyle = palette.bg;
  ctx.fillRect(0, 0, size, size);

  // Subtle graybox noise
  for (let i = 0; i < 3200; i++) {
    const x = Math.random() * size;
    const y = Math.random() * size;
    ctx.fillStyle = Math.random() > 0.5 ? 'rgba(255,255,255,0.025)' : 'rgba(0,0,0,0.035)';
    ctx.fillRect(x, y, 2, 2);
  }

  // Architectural inner grid lines
  ctx.strokeStyle = 'rgba(255, 255, 255, 0.08)';
  ctx.lineWidth = 1.5;
  for (let i = 1; i < 4; i++) {
    const p = (size / 4) * i;
    ctx.beginPath();
    ctx.moveTo(p, 0);
    ctx.lineTo(p, size);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(0, p);
    ctx.lineTo(size, p);
    ctx.stroke();
  }

  // Diagonal faint blockout X
  ctx.strokeStyle = 'rgba(255, 255, 255, 0.04)';
  ctx.lineWidth = 1.5;
  ctx.beginPath();
  ctx.moveTo(18, 18);
  ctx.lineTo(size - 18, size - 18);
  ctx.moveTo(size - 18, 18);
  ctx.lineTo(18, size - 18);
  ctx.stroke();

  // Outer chamfer frame
  ctx.strokeStyle = 'rgba(15, 23, 32, 0.55)';
  ctx.lineWidth = 12;
  ctx.strokeRect(6, 6, size - 12, size - 12);

  ctx.strokeStyle = palette.border;
  ctx.lineWidth = 4;
  ctx.strokeRect(14, 14, size - 28, size - 28);

  if (!isTopFace && variant !== 'wall') {
    // Top tactical stripe band
    ctx.fillStyle = palette.accent;
    ctx.fillRect(16, 16, size - 32, 12);

    // Stenciled height label plate
    ctx.fillStyle = palette.badgeBg;
    ctx.fillRect(54, size / 2 - 54, size - 108, 108);
    ctx.strokeStyle = palette.accent;
    ctx.lineWidth = 2.5;
    ctx.strokeRect(54, size / 2 - 54, size - 108, 108);

    ctx.fillStyle = '#f8fafc';
    ctx.font = '800 44px "Barlow Condensed", sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(labelText, size / 2, size / 2 - 12);

    ctx.fillStyle = palette.accent;
    ctx.font = '700 18px "JetBrains Mono", monospace';
    ctx.fillText(palette.sub, size / 2, size / 2 + 28);
  } else if (isTopFace && variant === 'height1') {
    // Subtle corner brackets on top of Height 1 boxes
    ctx.strokeStyle = 'rgba(245, 158, 11, 0.55)';
    ctx.lineWidth = 5;
    const b = 46;
    [
      [24, 24, 1, 1],
      [size - 24, 24, -1, 1],
      [24, size - 24, 1, -1],
      [size - 24, size - 24, -1, -1],
    ].forEach(([cx, cy, dx, dy]) => {
      ctx.beginPath();
      ctx.moveTo(cx, cy + dy * b);
      ctx.lineTo(cx, cy);
      ctx.lineTo(cx + dx * b, cy);
      ctx.stroke();
    });
  }

  const tex = new THREE.CanvasTexture(canvas);
  tex.anisotropy = 8;
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

export function createBrushedMetalBump(): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 256;
  canvas.height = 256;
  const ctx = canvas.getContext('2d')!;
  ctx.fillStyle = '#808080';
  ctx.fillRect(0, 0, 256, 256);

  // Horizontal fine CNC machining brush lines
  for (let y = 0; y < 256; y++) {
    const shade = 112 + Math.floor(Math.random() * 34);
    ctx.fillStyle = `rgb(${shade},${shade},${shade})`;
    ctx.fillRect(0, y, 256, 1);
  }
  for (let i = 0; i < 900; i++) {
    const x = Math.random() * 256;
    const y = Math.random() * 256;
    const w = 12 + Math.random() * 50;
    const shade = 95 + Math.floor(Math.random() * 65);
    ctx.fillStyle = `rgba(${shade},${shade},${shade},0.35)`;
    ctx.fillRect(x, y, w, 1);
  }

  const tex = new THREE.CanvasTexture(canvas);
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  tex.repeat.set(3, 3);
  return tex;
}

export function createPolymerStippleBump(): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 128;
  canvas.height = 128;
  const ctx = canvas.getContext('2d')!;
  ctx.fillStyle = '#7c7c7c';
  ctx.fillRect(0, 0, 128, 128);

  for (let y = 0; y < 128; y += 3) {
    for (let x = 0; x < 128; x += 3) {
      const v = 65 + Math.floor(Math.random() * 125);
      ctx.fillStyle = `rgb(${v},${v},${v})`;
      ctx.fillRect(x, y, 2, 2);
    }
  }

  const tex = new THREE.CanvasTexture(canvas);
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  tex.repeat.set(6, 6);
  return tex;
}

export function createTacticalTargetTexture(): THREE.CanvasTexture {
  const w = 256;
  const h = 384;
  const canvas = document.createElement('canvas');
  canvas.width = w;
  canvas.height = h;
  const ctx = canvas.getContext('2d')!;

  ctx.fillStyle = '#1e242c';
  ctx.fillRect(0, 0, w, h);

  ctx.strokeStyle = '#94a3b8';
  ctx.lineWidth = 6;
  ctx.strokeRect(8, 8, w - 16, h - 16);

  // Tactical IPSC silhouette
  ctx.fillStyle = '#cbd5e1';
  ctx.beginPath();
  // Head
  ctx.roundRect(w / 2 - 34, 34, 68, 72, 12);
  // Torso
  ctx.roundRect(w / 2 - 78, 114, 156, 224, 22);
  ctx.fill();

  // Scoring rings
  ctx.strokeStyle = '#334155';
  ctx.lineWidth = 3;
  [62, 40].forEach((r) => {
    ctx.beginPath();
    ctx.arc(w / 2, 212, r, 0, Math.PI * 2);
    ctx.stroke();
  });

  // High-vis bullseyes (Head & Center Mass)
  ctx.fillStyle = '#ef4444';
  ctx.beginPath();
  ctx.arc(w / 2, 70, 15, 0, Math.PI * 2);
  ctx.fill();

  ctx.beginPath();
  ctx.arc(w / 2, 212, 20, 0, Math.PI * 2);
  ctx.fill();

  const tex = new THREE.CanvasTexture(canvas);
  tex.anisotropy = 4;
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

// ---------------------------------------------------------------------------
// OPERATOR TEXTURES (Black Multicam, Union Jack patch, Skull patch, Tattoos)
// ---------------------------------------------------------------------------
let camoCache: THREE.CanvasTexture | null = null;

export function getBlackCamoTexture(): THREE.CanvasTexture {
  if (camoCache) return camoCache;
  const size = 512;
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d')!;

  ctx.fillStyle = '#17191c';
  ctx.fillRect(0, 0, size, size);

  const palette = ['#25282c', '#2f3338', '#0c0d0f', '#363a3d', '#3d4139', '#1c1f23', '#4a4d46'];
  let seed = 1337;
  const rnd = () => {
    seed = (seed * 16807) % 2147483647;
    return (seed - 1) / 2147483646;
  };

  for (let i = 0; i < 230; i++) {
    const cx = rnd() * size;
    const cy = rnd() * size;
    const col = palette[Math.floor(rnd() * palette.length)];
    const alpha = col === '#4a4d46' || col === '#3d4139' ? 0.55 : 0.9;
    ctx.fillStyle = col;
    ctx.globalAlpha = alpha;
    const blobs = 3 + Math.floor(rnd() * 3);
    for (let b = 0; b < blobs; b++) {
      const ox = (rnd() - 0.5) * 46;
      const oy = (rnd() - 0.5) * 30;
      const rx = 10 + rnd() * 30;
      const ry = 6 + rnd() * 16;
      const rot = rnd() * Math.PI;
      for (const wrapX of [-size, 0, size]) {
        for (const wrapY of [-size, 0, size]) {
          const px = cx + ox + wrapX;
          const py = cy + oy + wrapY;
          if (px < -80 || px > size + 80 || py < -80 || py > size + 80) continue;
          ctx.beginPath();
          ctx.ellipse(px, py, rx, ry, rot, 0, Math.PI * 2);
          ctx.fill();
        }
      }
    }
  }
  ctx.globalAlpha = 1;

  // Fabric weave noise
  for (let i = 0; i < 9000; i++) {
    ctx.fillStyle = Math.random() > 0.5 ? 'rgba(255,255,255,0.03)' : 'rgba(0,0,0,0.08)';
    ctx.fillRect(Math.random() * size, Math.random() * size, 2, 2);
  }

  const tex = new THREE.CanvasTexture(canvas);
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  tex.repeat.set(1.6, 1.6);
  tex.anisotropy = 8;
  tex.colorSpace = THREE.SRGBColorSpace;
  camoCache = tex;
  return tex;
}

export function createFlagPatchTexture(): THREE.CanvasTexture {
  const w = 256;
  const h = 160;
  const canvas = document.createElement('canvas');
  canvas.width = w;
  canvas.height = h;
  const ctx = canvas.getContext('2d')!;

  ctx.fillStyle = '#0d0e10';
  ctx.fillRect(0, 0, w, h);

  const m = 10;
  ctx.save();
  ctx.beginPath();
  ctx.rect(m, m, w - m * 2, h - m * 2);
  ctx.clip();

  ctx.fillStyle = '#23262a';
  ctx.fillRect(0, 0, w, h);

  // White saltire
  ctx.strokeStyle = '#9a9ea3';
  ctx.lineWidth = 26;
  ctx.beginPath();
  ctx.moveTo(0, 0);
  ctx.lineTo(w, h);
  ctx.moveTo(w, 0);
  ctx.lineTo(0, h);
  ctx.stroke();

  // Red saltire (dark grey in subdued variant)
  ctx.strokeStyle = '#4a4e53';
  ctx.lineWidth = 9;
  ctx.beginPath();
  ctx.moveTo(0, 0);
  ctx.lineTo(w, h);
  ctx.moveTo(w, 0);
  ctx.lineTo(0, h);
  ctx.stroke();

  // White cross
  ctx.fillStyle = '#b3b7bb';
  ctx.fillRect(w / 2 - 22, 0, 44, h);
  ctx.fillRect(0, h / 2 - 22, w, 44);

  // Red cross
  ctx.fillStyle = '#505459';
  ctx.fillRect(w / 2 - 12, 0, 24, h);
  ctx.fillRect(0, h / 2 - 12, w, 24);
  ctx.restore();

  // Stitched border
  ctx.strokeStyle = 'rgba(160,164,168,0.6)';
  ctx.setLineDash([6, 5]);
  ctx.lineWidth = 2;
  ctx.strokeRect(m + 3, m + 3, w - m * 2 - 6, h - m * 2 - 6);

  const tex = new THREE.CanvasTexture(canvas);
  tex.anisotropy = 8;
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

export function createSkullPatchTexture(): THREE.CanvasTexture {
  const s = 128;
  const canvas = document.createElement('canvas');
  canvas.width = s;
  canvas.height = s;
  const ctx = canvas.getContext('2d')!;

  ctx.fillStyle = '#0d0e10';
  ctx.beginPath();
  ctx.arc(64, 64, 62, 0, Math.PI * 2);
  ctx.fill();
  ctx.strokeStyle = '#8a8e92';
  ctx.lineWidth = 4;
  ctx.beginPath();
  ctx.arc(64, 64, 55, 0, Math.PI * 2);
  ctx.stroke();

  ctx.fillStyle = '#cfd1d3';
  ctx.beginPath();
  ctx.ellipse(64, 54, 29, 30, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillRect(48, 70, 32, 22);

  ctx.fillStyle = '#0d0e10';
  ctx.beginPath();
  ctx.ellipse(52, 56, 8, 10, 0, 0, Math.PI * 2);
  ctx.ellipse(76, 56, 8, 10, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.beginPath();
  ctx.moveTo(64, 66);
  ctx.lineTo(59, 77);
  ctx.lineTo(69, 77);
  ctx.closePath();
  ctx.fill();
  for (let i = 0; i < 4; i++) {
    ctx.fillRect(53 + i * 7, 82, 2, 10);
  }

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

export function createTattooSkinTexture(): THREE.CanvasTexture {
  const size = 256;
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d')!;

  ctx.fillStyle = '#b48a6d';
  ctx.fillRect(0, 0, size, size);

  // Skin tone variation + fine hair/pores
  for (let i = 0; i < 2600; i++) {
    ctx.fillStyle = Math.random() > 0.5 ? 'rgba(120,70,50,0.07)' : 'rgba(255,220,190,0.05)';
    ctx.fillRect(Math.random() * size, Math.random() * size, 2, 2);
  }
  for (let i = 0; i < 700; i++) {
    ctx.fillStyle = 'rgba(40,28,22,0.28)';
    ctx.fillRect(Math.random() * size, Math.random() * size, 1, 3);
  }

  // Tactical sleeve-tattoo ink: tribal bands, linework & shaded blotches
  ctx.strokeStyle = 'rgba(38,40,48,0.82)';
  ctx.fillStyle = 'rgba(38,40,48,0.7)';
  ctx.lineWidth = 3;
  for (let i = 0; i < 9; i++) {
    ctx.beginPath();
    const y = 20 + i * 26;
    ctx.moveTo(0, y);
    for (let x = 0; x <= size; x += 16) {
      ctx.lineTo(x, y + Math.sin(x * 0.12 + i) * 9);
    }
    ctx.stroke();
  }
  for (let i = 0; i < 26; i++) {
    ctx.beginPath();
    ctx.ellipse(Math.random() * size, Math.random() * size, 4 + Math.random() * 14, 3 + Math.random() * 9, Math.random() * 3, 0, Math.PI * 2);
    ctx.fill();
  }
  for (let i = 0; i < 12; i++) {
    const x = Math.random() * size;
    const y = Math.random() * size;
    ctx.beginPath();
    ctx.moveTo(x, y);
    ctx.lineTo(x + 20, y + 12);
    ctx.lineTo(x + 6, y + 28);
    ctx.closePath();
    ctx.stroke();
  }

  const tex = new THREE.CanvasTexture(canvas);
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  tex.anisotropy = 8;
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

// ---------------------------------------------------------------------------
// PROCEDURAL NORMAL MAPS (fabric wrinkles, cloth weave, skin pores, hair)
// ---------------------------------------------------------------------------
interface NoiseOctave {
  fx: number; // integer frequency X (tiles seamlessly)
  fy: number; // integer frequency Y
  amp: number;
  phase: number;
}

function generateTileableHeightField(size: number, octaves: NoiseOctave[], verticalStreak = 0): Float32Array {
  const h = new Float32Array(size * size);
  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      let v = 0;
      for (let o = 0; o < octaves.length; o++) {
        const oc = octaves[o];
        const px = (Math.PI * 2 * oc.fx * x) / size;
        const py = (Math.PI * 2 * oc.fy * y) / size;
        v += oc.amp * Math.sin(px + oc.phase) * Math.cos(py + oc.phase * 1.7) +
             oc.amp * 0.6 * Math.sin(px * 2 + py + oc.phase * 2.3);
      }
      if (verticalStreak > 0) {
        // Directional streaks (hair / fabric grain)
        v += verticalStreak * Math.sin((Math.PI * 2 * 90 * y) / size + Math.sin((Math.PI * 2 * 3 * x) / size) * 2.0);
      }
      h[y * size + x] = v;
    }
  }
  return h;
}

function heightFieldToNormalCanvas(size: number, h: Float32Array, strength: number): HTMLCanvasElement {
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d')!;
  const img = ctx.createImageData(size, size);

  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      const xl = h[y * size + ((x - 1 + size) % size)];
      const xr = h[y * size + ((x + 1) % size)];
      const yu = h[((y - 1 + size) % size) * size + x];
      const yd = h[((y + 1) % size) * size + x];

      let nx = (xl - xr) * strength;
      let ny = (yu - yd) * strength;
      const nz = 1.0;
      const len = Math.sqrt(nx * nx + ny * ny + nz * nz);
      nx /= len;
      ny /= len;

      const i = (y * size + x) * 4;
      img.data[i] = Math.round((nx * 0.5 + 0.5) * 255);
      img.data[i + 1] = Math.round((ny * 0.5 + 0.5) * 255);
      img.data[i + 2] = Math.round((nz / len) * 255);
      img.data[i + 3] = 255;
    }
  }
  ctx.putImageData(img, 0, 0);
  return canvas;
}

function makeTiledNormalTexture(size: number, octaves: NoiseOctave[], strength: number, repeat: number, verticalStreak = 0): THREE.CanvasTexture {
  const canvas = heightFieldToNormalCanvas(size, generateTileableHeightField(size, octaves, verticalStreak), strength);
  const tex = new THREE.CanvasTexture(canvas);
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  tex.repeat.set(repeat, repeat);
  return tex;
}

let wrinkleNormalCache: THREE.CanvasTexture | null = null;
let weaveNormalCache: THREE.CanvasTexture | null = null;
let poreNormalCache: THREE.CanvasTexture | null = null;
let hairNormalCache: THREE.CanvasTexture | null = null;

/** Broad soft cloth creases */
export function getClothWrinkleNormal(): THREE.CanvasTexture {
  if (wrinkleNormalCache) return wrinkleNormalCache;
  wrinkleNormalCache = makeTiledNormalTexture(
    256,
    [
      { fx: 1, fy: 1, amp: 1.0, phase: 0.6 },
      { fx: 2, fy: 3, amp: 0.7, phase: 2.1 },
      { fx: 3, fy: 2, amp: 0.6, phase: 4.2 },
      { fx: 4, fy: 5, amp: 0.35, phase: 1.3 },
      { fx: 6, fy: 4, amp: 0.25, phase: 5.0 },
    ],
    1.4,
    2
  );
  return wrinkleNormalCache;
}

/** Fine cotton ripstop weave */
export function getClothWeaveNormal(): THREE.CanvasTexture {
  if (weaveNormalCache) return weaveNormalCache;
  weaveNormalCache = makeTiledNormalTexture(
    128,
    [
      { fx: 40, fy: 2, amp: 1.0, phase: 0 },
      { fx: 2, fy: 40, amp: 1.0, phase: 1.5 },
      { fx: 60, fy: 60, amp: 0.4, phase: 3.1 },
    ],
    0.9,
    10
  );
  return weaveNormalCache;
}

/** Human skin: pores + micro blemishes */
export function getSkinPoreNormal(): THREE.CanvasTexture {
  if (poreNormalCache) return poreNormalCache;
  poreNormalCache = makeTiledNormalTexture(
    128,
    [
      { fx: 18, fy: 22, amp: 1.0, phase: 0.4 },
      { fx: 34, fy: 28, amp: 0.8, phase: 2.8 },
      { fx: 44, fy: 38, amp: 0.5, phase: 5.2 },
      { fx: 24, fy: 44, amp: 0.6, phase: 1.9 },
    ],
    0.55,
    3
  );
  return poreNormalCache;
}

/** Coarse directional beard hair strands */
export function getBeardHairNormal(): THREE.CanvasTexture {
  if (hairNormalCache) return hairNormalCache;
  hairNormalCache = makeTiledNormalTexture(128, [{ fx: 8, fy: 30, amp: 0.8, phase: 0.8 }], 0.9, 4, 1.6);
  return hairNormalCache;
}
