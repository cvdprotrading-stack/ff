import * as THREE from 'three';
import { ARENA_HALF_SIZE, MAP_BOXES, MAP_TARGETS, PLAYER_SPAWN } from './mapData';
import { TacticalOperator } from './playerModel';
import { soundEngine } from './sound';
import {
  createBoxFaceTexture,
  createEnvironmentMap,
  createGroundGridTexture,
  createTacticalTargetTexture,
} from './textures';
import { BoxObstacle, HudState, WEAPON_SPECS, WeaponId } from './types';
import { AR_RELOAD_TIMING, createFirstPersonWeapons, updateWeaponAnimation, WeaponRig } from './weapons';
import { FirstPersonArms } from './fpArms';
import { TacticalRecordingCamera } from './recordingCamera';

export const REC_WIDTH = 480;
export const REC_HEIGHT = 270;
export const REC_FPS = 20;
const MAX_REC_FRAMES = 300; // 15 seconds rolling buffer at 20 FPS

interface ShellCasing {
  mesh: THREE.Mesh;
  vel: THREE.Vector3;
  rotVel: THREE.Vector3;
  life: number;
  bounced: boolean;
}

interface ImpactParticle {
  mesh: THREE.Mesh;
  vel: THREE.Vector3;
  life: number;
  maxLife: number;
  isSmoke: boolean;
}

interface ReactiveTargetObj {
  id: string;
  pivot: THREE.Group;
  boardMesh: THREE.Mesh;
  headCenterWorld: THREE.Vector3;
  flinchAngle: number;
  flinchVel: number;
}

// Strict Jump Physics Calibration:
// GRAVITY = 26.0 m/s^2, JUMP_VELOCITY = 7.46 m/s
// Peak jump height = v^2 / (2*g) = 55.65 / 52.0 = 1.070 meters!
// - Height 1.0m boxes: Player reaches 1.07m (> 1.00m) -> cleanly jumps onto ALL Height 1 boxes!
// - Height 1+ boxes (1.35m, 1.4m, 1.5m, 1.8m, 2.0m, 2.5m): Player peaks at 1.07m -> strictly blocked!
const GRAVITY = 26.0;
const JUMP_VELOCITY = 7.46;
const MAX_CLIMBABLE_DELTA = 1.08;
const PLAYER_RADIUS = 0.36;
const EYE_HEIGHT_STAND = 1.64;
const EYE_HEIGHT_CROUCH = 1.12;
const WALK_SPEED = 4.7;
const SPRINT_SPEED = 7.2;
const CROUCH_SPEED = 2.65;
const ADS_WALK_SPEED = 3.1;

export class WarzoneEngine {
  private container: HTMLElement;
  private renderer: THREE.WebGLRenderer;

  // Main World Scene & Camera
  private worldScene: THREE.Scene;
  private worldCamera: THREE.PerspectiveCamera;

  // Dedicated First-Person Viewmodel Scene & Camera (prevents barrel clipping into boxes!)
  private viewScene: THREE.Scene;
  private viewCamera: THREE.PerspectiveCamera;
  private viewMuzzleLight: THREE.PointLight;
  private worldMuzzleLight: THREE.PointLight;
  private sunLight: THREE.DirectionalLight;

  // Weapons & Operator
  private fpWeapons: Record<WeaponId, WeaponRig>;
  private operator: TacticalOperator;
  private fpArms: FirstPersonArms;

  // Map Meshes & Targets
  private shootableMeshes: THREE.Object3D[] = [];
  private targets: ReactiveTargetObj[] = [];

  // Pooled VFX (Brass Shells, Bullet Decals, Sparks/Smoke)
  private shells: ShellCasing[] = [];
  private particles: ImpactParticle[] = [];
  private decals: THREE.Mesh[] = [];
  private decalIndex = 0;
  private shellGeo556 = new THREE.CylinderGeometry(0.0045, 0.0048, 0.036, 8);
  private shellGeo9mm = new THREE.CylinderGeometry(0.0046, 0.0046, 0.019, 8);
  private shellMat = new THREE.MeshStandardMaterial({ color: 0xdca94a, metalness: 0.94, roughness: 0.18 });
  private sparkMat = new THREE.MeshBasicMaterial({ color: 0xfbbf24 });
  private smokeMat = new THREE.MeshBasicMaterial({
    color: 0xcbd5e1,
    transparent: true,
    opacity: 0.25,
    depthWrite: false,
  });
  private decalGeo = new THREE.PlaneGeometry(0.065, 0.065);
  private decalMat: THREE.MeshBasicMaterial;

  // Gameplay & Input State
  private isMenuMode = true;
  private cameraPerspective: 'FPV' | 'TPV' = 'FPV';
  private keys = new Set<string>();
  private mouseLeftDown = false;
  private semiTriggerConsumed = false;
  private mouseRightDown = false;
  private pointerLocked = false;

  // Player Kinematics
  private playerPos = new THREE.Vector3(PLAYER_SPAWN.x, PLAYER_SPAWN.y, PLAYER_SPAWN.z);
  private playerVel = new THREE.Vector3();
  private grounded = true;
  private jumpLaunchY = 0;
  private yaw = 0; // 0 looks toward -Z
  private pitch = 0;
  private crouchAmount = 0;
  private currentEyeHeight = EYE_HEIGHT_STAND;
  private landImpact = 0;
  private footstepAccum = 0;

  // Weapon & Combat State
  private activeWeapon: WeaponId = 'ar';
  private ammoInMag: Record<WeaponId, number> = {
    ar: WEAPON_SPECS.ar.magSize,
    pistol: WEAPON_SPECS.pistol.magSize,
  };
  private ammoReserve: Record<WeaponId, number> = {
    ar: WEAPON_SPECS.ar.startReserve,
    pistol: WEAPON_SPECS.pistol.startReserve,
  };
  private adsAmount = 0;
  private fireCooldown = 0;
  private boltCycle = 0;
  private muzzleFlashTimer = 0;
  private equipAlpha = 1;

  // Multi-Stage Reload State
  private isReloading = false;
  private isDryReload = false;
  private reloadElapsed = 0;
  private reloadDuration = 2.0;
  private reloadSoundStage = 0;

  // Recoil & Mouse Sway Springs
  private recoilPosZ = 0;
  private recoilPitch = 0;
  private recoilRoll = 0;
  private camRecoilPitch = 0;
  private camRecoilYaw = 0;
  private mouseSwayX = 0;
  private mouseSwayY = 0;
  private dynamicSpread = 0;

  // Tactical Field Recording Camera ([H] to place, [I] to view recorded clip)
  private recordingCamera: TacticalRecordingCamera;
  private recordedFrames: HTMLCanvasElement[] = [];
  private framePool: HTMLCanvasElement[] = [];
  private recordAccum = 0;
  private shouldCaptureRecFrame = false;
  private isViewingClip = false;
  private cameraNotice: string | null = null;
  private cameraNoticeTimer = 0;
  private livePipCanvas: HTMLCanvasElement | null = null;

  // Telemetry & Loop
  private hitmarkerTime = 0;
  private isHeadshotHit = false;
  private targetsHit = 0;
  private animFrameId = 0;
  private lastTime = performance.now();
  private totalTime = 0;
  private hudEmitAccum = 0;
  private onHudUpdate: (hud: HudState) => void;

  constructor(container: HTMLElement, onHudUpdate: (hud: HudState) => void) {
    this.container = container;
    this.onHudUpdate = onHudUpdate;

    // 1. High-Graphics WebGL Renderer
    this.renderer = new THREE.WebGLRenderer({
      antialias: true,
      powerPreference: 'high-performance',
    });
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    this.renderer.setSize(container.clientWidth, container.clientHeight);
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.08;
    this.renderer.autoClear = false;
    container.appendChild(this.renderer.domElement);

    const envMap = createEnvironmentMap(this.renderer);

    // 2. World Scene & Lighting
    this.worldScene = new THREE.Scene();
    this.worldScene.environment = envMap;
    this.worldScene.background = new THREE.Color(0x9ab2c9);
    this.worldScene.fog = new THREE.FogExp2(0x9bb2c7, 0.0085);

    const aspect = container.clientWidth / Math.max(1, container.clientHeight);
    this.worldCamera = new THREE.PerspectiveCamera(76, aspect, 0.08, 180);

    const hemiLight = new THREE.HemisphereLight(0xdbeafe, 0x3b424c, 0.78);
    this.worldScene.add(hemiLight);

    this.sunLight = new THREE.DirectionalLight(0xfff5e4, 2.35);
    this.sunLight.position.set(22, 36, 18);
    this.sunLight.castShadow = true;
    this.sunLight.shadow.mapSize.width = 2048;
    this.sunLight.shadow.mapSize.height = 2048;
    this.sunLight.shadow.camera.near = 2;
    this.sunLight.shadow.camera.far = 95;
    const d = 34;
    this.sunLight.shadow.camera.left = -d;
    this.sunLight.shadow.camera.right = d;
    this.sunLight.shadow.camera.top = d;
    this.sunLight.shadow.camera.bottom = -d;
    this.sunLight.shadow.bias = -0.00045;
    this.worldScene.add(this.sunLight);

    this.worldMuzzleLight = new THREE.PointLight(0xffa94d, 0, 7.5);
    this.worldScene.add(this.worldMuzzleLight);

    // 3. Dedicated First-Person Viewmodel Scene & Lighting
    this.viewScene = new THREE.Scene();
    this.viewScene.environment = envMap;
    this.viewCamera = new THREE.PerspectiveCamera(50, aspect, 0.015, 6);
    this.viewScene.add(this.viewCamera);

    const viewHemi = new THREE.HemisphereLight(0xe2f0ff, 0x2c323b, 0.85);
    this.viewScene.add(viewHemi);

    const viewSun = new THREE.DirectionalLight(0xfff4e0, 2.1);
    viewSun.position.set(4, 7, 3);
    this.viewScene.add(viewSun);

    const viewRim = new THREE.DirectionalLight(0x93c5fd, 0.75);
    viewRim.position.set(-4, 3, -3);
    this.viewScene.add(viewRim);

    // Broad camera-side fill brings out receiver contours and surface finish
    // while keeping the dark anodized/polymer silhouette intact.
    const viewFill = new THREE.DirectionalLight(0xdce7f3, 1.15);
    viewFill.position.set(-1.5, 1.2, 4);
    this.viewScene.add(viewFill);

    this.viewMuzzleLight = new THREE.PointLight(0xffae42, 0, 2.4);
    this.viewMuzzleLight.position.set(0.08, 0.04, -0.75);
    this.viewCamera.add(this.viewMuzzleLight);

    // 4. Build Bullet Decal Texture & Material
    this.decalMat = this.createBulletDecalMaterial();

    // 5. Build Sky Dome, Clean Blockout Map, Reactive Targets, Weapons & Operator
    this.buildSkyDome();
    this.buildBlockoutArena();
    this.buildReactiveTargets();

    this.fpWeapons = createFirstPersonWeapons();
    this.viewCamera.add(this.fpWeapons.ar.root);
    this.viewCamera.add(this.fpWeapons.pistol.root);
    this.fpWeapons.pistol.root.visible = false;

    // First-person arms = the real Xbot arm mesh, IK-posed onto the active weapon's grips
    this.fpArms = new FirstPersonArms();
    this.viewCamera.add(this.fpArms.root);

    this.operator = new TacticalOperator();
    this.worldScene.add(this.operator.root);

    this.recordingCamera = new TacticalRecordingCamera();
    this.worldScene.add(this.recordingCamera.root);

    // 6. Bind Browser Events & Start Render Loop
    this.bindEvents();
    this.emitHudState();
    this.animate();
  }

  private createBulletDecalMaterial(): THREE.MeshBasicMaterial {
    const c = document.createElement('canvas');
    c.width = 64;
    c.height = 64;
    const ctx = c.getContext('2d')!;
    const g = ctx.createRadialGradient(32, 32, 3, 32, 32, 28);
    g.addColorStop(0.0, 'rgba(10, 12, 15, 0.96)');
    g.addColorStop(0.32, 'rgba(24, 28, 34, 0.85)');
    g.addColorStop(0.65, 'rgba(65, 72, 82, 0.35)');
    g.addColorStop(1.0, 'rgba(65, 72, 82, 0.0)');
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, 64, 64);

    const tex = new THREE.CanvasTexture(c);
    return new THREE.MeshBasicMaterial({
      map: tex,
      transparent: true,
      depthWrite: false,
      polygonOffset: true,
      polygonOffsetFactor: -2,
    });
  }

  private buildSkyDome() {
    const skyCanvas = document.createElement('canvas');
    skyCanvas.width = 512;
    skyCanvas.height = 256;
    const ctx = skyCanvas.getContext('2d')!;
    const grad = ctx.createLinearGradient(0, 0, 0, 256);
    grad.addColorStop(0.0, '#1e3a5f');
    grad.addColorStop(0.45, '#5982ab');
    grad.addColorStop(0.82, '#adc3d6');
    grad.addColorStop(1.0, '#d0dce6');
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, 512, 256);

    const skyTex = new THREE.CanvasTexture(skyCanvas);
    skyTex.colorSpace = THREE.SRGBColorSpace;
    const skyMesh = new THREE.Mesh(
      new THREE.SphereGeometry(130, 24, 16),
      new THREE.MeshBasicMaterial({ map: skyTex, side: THREE.BackSide, fog: false })
    );
    this.worldScene.add(skyMesh);
  }

  private buildBlockoutArena() {
    // Architectural Graybox Floor (60m x 60m)
    const groundTex = createGroundGridTexture();
    const floorMat = new THREE.MeshStandardMaterial({
      map: groundTex,
      roughness: 0.82,
      metalness: 0.08,
    });
    const floorMesh = new THREE.Mesh(new THREE.PlaneGeometry(60, 60), floorMat);
    floorMesh.rotation.x = -Math.PI / 2;
    floorMesh.receiveShadow = true;
    this.worldScene.add(floorMesh);
    this.shootableMeshes.push(floorMesh);

    // Texture cache per label so identical height boxes share GPU textures
    const matCache = new Map<string, THREE.MeshStandardMaterial[]>();

    const getBoxMaterials = (box: BoxObstacle): THREE.MeshStandardMaterial[] => {
      const key = `${box.variant}-${box.label ?? ''}`;
      if (matCache.has(key)) return matCache.get(key)!;

      const sideTex = createBoxFaceTexture(box.variant, box.label ?? `H: ${box.h}M`, false);
      const topTex = createBoxFaceTexture(box.variant, box.label ?? `H: ${box.h}M`, true);

      const sideMat = new THREE.MeshStandardMaterial({
        map: sideTex,
        roughness: 0.68,
        metalness: 0.14,
      });
      const topMat = new THREE.MeshStandardMaterial({
        map: topTex,
        roughness: 0.72,
        metalness: 0.12,
      });

      const mats = [sideMat, sideMat, topMat, topMat, sideMat, sideMat];
      matCache.set(key, mats);
      return mats;
    };

    for (const box of MAP_BOXES) {
      const geo = new THREE.BoxGeometry(box.w, box.h, box.d);
      const mesh = new THREE.Mesh(geo, getBoxMaterials(box));
      mesh.position.set(box.x, box.y + box.h / 2, box.z);
      mesh.castShadow = true;
      mesh.receiveShadow = true;
      this.worldScene.add(mesh);
      this.shootableMeshes.push(mesh);
    }
  }

  private buildReactiveTargets() {
    const targetTex = createTacticalTargetTexture();
    const boardMat = new THREE.MeshStandardMaterial({
      map: targetTex,
      roughness: 0.45,
      metalness: 0.35,
    });
    const standMat = new THREE.MeshStandardMaterial({
      color: 0x262c34,
      roughness: 0.5,
      metalness: 0.75,
    });

    for (const tp of MAP_TARGETS) {
      const baseGroup = new THREE.Group();
      baseGroup.position.set(tp.x, tp.y, tp.z);
      baseGroup.rotation.y = tp.facingYaw;
      this.worldScene.add(baseGroup);

      const basePlate = new THREE.Mesh(new THREE.BoxGeometry(0.65, 0.06, 0.55), standMat);
      basePlate.position.y = 0.03;
      basePlate.castShadow = true;
      basePlate.receiveShadow = true;
      baseGroup.add(basePlate);

      const pivot = new THREE.Group();
      pivot.position.set(0, 0.06, 0);
      baseGroup.add(pivot);

      const post = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.62, 0.08), standMat);
      post.position.y = 0.31;
      post.castShadow = true;
      pivot.add(post);

      const boardMesh = new THREE.Mesh(new THREE.BoxGeometry(0.66, 1.04, 0.045), boardMat);
      boardMesh.position.y = 1.12;
      boardMesh.castShadow = true;
      boardMesh.receiveShadow = true;
      boardMesh.userData.targetId = tp.id;
      pivot.add(boardMesh);
      this.shootableMeshes.push(boardMesh);

      const headCenterWorld = new THREE.Vector3(tp.x, tp.y + 1.48, tp.z);

      this.targets.push({
        id: tp.id,
        pivot,
        boardMesh,
        headCenterWorld,
        flinchAngle: 0,
        flinchVel: 0,
      });
    }
  }

  // --- PUBLIC CONTROLS FOR REACT MENU & HUD ---
  public deploy(selectedWeapon: WeaponId) {
    soundEngine.unlock();
    this.isMenuMode = false;
    this.resetPosition();
    this.switchWeapon(selectedWeapon, true);
    this.equipAlpha = 0; // Play crisp weapon draw animation upon deploying!
    this.requestPointerLock();
    this.emitHudState();
  }

  public setMenuPreviewWeapon(weapon: WeaponId) {
    this.activeWeapon = weapon;
    this.fpWeapons.ar.root.visible = weapon === 'ar';
    this.fpWeapons.pistol.root.visible = weapon === 'pistol';
    this.emitHudState();
  }

  public returnToMenu() {
    this.isMenuMode = true;
    this.mouseLeftDown = false;
    this.mouseRightDown = false;
    this.keys.clear();
    if (document.pointerLockElement === this.renderer.domElement) {
      document.exitPointerLock();
    }
    this.emitHudState();
  }

  public requestPointerLock() {
    if (!this.isMenuMode && document.pointerLockElement !== this.renderer.domElement) {
      this.renderer.domElement.requestPointerLock?.();
    }
  }

  public togglePerspective() {
    this.cameraPerspective = this.cameraPerspective === 'FPV' ? 'TPV' : 'FPV';
    this.emitHudState();
  }

  public resetPosition() {
    this.playerPos.set(PLAYER_SPAWN.x, PLAYER_SPAWN.y, PLAYER_SPAWN.z);
    this.playerVel.set(0, 0, 0);
    this.yaw = 0;
    this.pitch = 0;
    this.grounded = true;
    this.jumpLaunchY = 0;
  }

  // --- TACTICAL RECORDING CAMERA ([H] PLACE, [I] VIEW CLIP) ---
  public placeRecordingCamera() {
    if (this.isMenuMode) return;
    if (this.isViewingClip) {
      this.isViewingClip = false;
    }

    // Find a valid surface spot in front of the player
    const sinY = Math.sin(this.yaw);
    const cosY = Math.cos(this.yaw);
    const limit = ARENA_HALF_SIZE - 1.3;

    let chosenX = THREE.MathUtils.clamp(this.playerPos.x - sinY * 2.5, -limit, limit);
    let chosenZ = THREE.MathUtils.clamp(this.playerPos.z - cosY * 2.5, -limit, limit);
    let chosenY = this.playerPos.y;

    for (const dist of [2.8, 2.2, 1.7, 1.3]) {
      const tx = THREE.MathUtils.clamp(this.playerPos.x - sinY * dist, -limit, limit);
      const tz = THREE.MathUtils.clamp(this.playerPos.z - cosY * dist, -limit, limit);
      let blockedByTall = false;
      let topY = 0;

      for (const box of MAP_BOXES) {
        const halfW = box.w / 2 + 0.32;
        const halfD = box.d / 2 + 0.32;
        if (Math.abs(tx - box.x) < halfW && Math.abs(tz - box.z) < halfD) {
          if (box.h <= MAX_CLIMBABLE_DELTA) {
            topY = Math.max(topY, box.y + box.h);
          } else {
            blockedByTall = true;
            break;
          }
        }
      }

      if (!blockedByTall) {
        chosenX = tx;
        chosenZ = tz;
        chosenY = topY;
        break;
      }
    }

    const lookAtPos = new THREE.Vector3(
      this.playerPos.x,
      this.playerPos.y + 1.22,
      this.playerPos.z
    );
    this.recordingCamera.placeAt(new THREE.Vector3(chosenX, chosenY, chosenZ), lookAtPos);

    // Recycle any previous frames into the pool and start a fresh recording clip
    while (this.recordedFrames.length > 0) {
      this.framePool.push(this.recordedFrames.pop()!);
    }
    this.recordAccum = 0;
    this.shouldCaptureRecFrame = true;

    this.cameraNotice = 'CAMERA PLACED & RECORDING ● PRESS [I] TO WATCH CLIP';
    this.cameraNoticeTimer = 4.0;
    soundEngine.playCameraPlace();
    this.emitHudState();
  }

  public toggleClipViewer() {
    if (this.isMenuMode) return;

    if (!this.recordingCamera.isPlaced) {
      this.cameraNotice = 'PRESS [H] FIRST TO PLACE RECORDING CAMERA IN ARENA';
      this.cameraNoticeTimer = 3.5;
      soundEngine.playDryClick();
      this.emitHudState();
      return;
    }

    this.isViewingClip = !this.isViewingClip;
    soundEngine.playClipToggle(this.isViewingClip);

    if (this.isViewingClip) {
      this.mouseLeftDown = false;
      this.mouseRightDown = false;
      this.keys.clear();
      if (document.pointerLockElement === this.renderer.domElement) {
        document.exitPointerLock();
      }
    } else {
      this.requestPointerLock();
    }
    this.emitHudState();
  }

  public closeClipViewer() {
    if (!this.isViewingClip) return;
    this.isViewingClip = false;
    soundEngine.playClipToggle(false);
    this.requestPointerLock();
    this.emitHudState();
  }

  public getRecordedFrames(): HTMLCanvasElement[] {
    return this.recordedFrames;
  }

  public setLivePipCanvas(canvas: HTMLCanvasElement | null) {
    this.livePipCanvas = canvas;
  }

  // --- EVENT BINDINGS ---
  private handleKeyDown = (e: KeyboardEvent) => {
    if (this.isMenuMode) return;
    const code = e.code;

    if (code === 'KeyH') {
      e.preventDefault();
      this.placeRecordingCamera();
      return;
    }
    if (code === 'KeyI') {
      e.preventDefault();
      this.toggleClipViewer();
      return;
    }
    if (this.isViewingClip) {
      if (code === 'Escape') {
        e.preventDefault();
        this.closeClipViewer();
      }
      return;
    }

    this.keys.add(code);

    if (code === 'Digit1') {
      this.switchWeapon('ar');
    } else if (code === 'Digit2') {
      this.switchWeapon('pistol');
    } else if (code === 'KeyQ') {
      this.switchWeapon(this.activeWeapon === 'ar' ? 'pistol' : 'ar');
    } else if (code === 'KeyR') {
      this.tryStartReload();
    } else if (code === 'KeyV') {
      this.togglePerspective();
    } else if (code === 'Space') {
      e.preventDefault();
      this.tryJump();
    }
  };

  private handleKeyUp = (e: KeyboardEvent) => {
    this.keys.delete(e.code);
  };

  private handleMouseDown = (e: MouseEvent) => {
    if (this.isMenuMode) return;
    soundEngine.unlock();

    if (!this.pointerLocked) {
      this.requestPointerLock();
      return;
    }

    if (e.button === 0) {
      this.mouseLeftDown = true;
      this.semiTriggerConsumed = false;
    } else if (e.button === 2) {
      if (!this.mouseRightDown) {
        soundEngine.playAdsToggle(true);
      }
      this.mouseRightDown = true;
    }
  };

  private handleMouseUp = (e: MouseEvent) => {
    if (e.button === 0) {
      this.mouseLeftDown = false;
      this.semiTriggerConsumed = false;
    } else if (e.button === 2) {
      if (this.mouseRightDown && !this.isMenuMode) {
        soundEngine.playAdsToggle(false);
      }
      this.mouseRightDown = false;
    }
  };

  private handleMouseMove = (e: MouseEvent) => {
    if (this.isMenuMode || !this.pointerLocked) return;
    const baseSens = 0.0021;
    const adsSensMult = THREE.MathUtils.lerp(1.0, 0.58, this.adsAmount);
    const dx = e.movementX * baseSens * adsSensMult;
    const dy = e.movementY * baseSens * adsSensMult;

    this.yaw -= dx;
    this.pitch = THREE.MathUtils.clamp(this.pitch - dy, -1.46, 1.46);

    this.mouseSwayX = THREE.MathUtils.clamp(this.mouseSwayX + dx * 1.45, -0.09, 0.09);
    this.mouseSwayY = THREE.MathUtils.clamp(this.mouseSwayY - dy * 1.45, -0.09, 0.09);
  };

  private handleWheel = (e: WheelEvent) => {
    if (this.isMenuMode || !this.pointerLocked) return;
    if (Math.abs(e.deltaY) > 8) {
      this.switchWeapon(this.activeWeapon === 'ar' ? 'pistol' : 'ar');
    }
  };

  private handleContextMenu = (e: MouseEvent) => {
    e.preventDefault();
  };

  private handlePointerLockChange = () => {
    this.pointerLocked = document.pointerLockElement === this.renderer.domElement;
    if (!this.pointerLocked) {
      this.mouseLeftDown = false;
      this.mouseRightDown = false;
      this.keys.clear();
    }
    this.emitHudState();
  };

  private handleResize = () => {
    const w = this.container.clientWidth;
    const h = Math.max(1, this.container.clientHeight);
    this.renderer.setSize(w, h);
    this.worldCamera.aspect = w / h;
    this.worldCamera.updateProjectionMatrix();
    this.viewCamera.aspect = w / h;
    this.viewCamera.updateProjectionMatrix();
  };

  private bindEvents() {
    window.addEventListener('keydown', this.handleKeyDown);
    window.addEventListener('keyup', this.handleKeyUp);
    window.addEventListener('mousedown', this.handleMouseDown);
    window.addEventListener('mouseup', this.handleMouseUp);
    window.addEventListener('mousemove', this.handleMouseMove);
    window.addEventListener('wheel', this.handleWheel, { passive: true });
    window.addEventListener('contextmenu', this.handleContextMenu);
    document.addEventListener('pointerlockchange', this.handlePointerLockChange);
    window.addEventListener('resize', this.handleResize);
  }

  public dispose() {
    cancelAnimationFrame(this.animFrameId);
    window.removeEventListener('keydown', this.handleKeyDown);
    window.removeEventListener('keyup', this.handleKeyUp);
    window.removeEventListener('mousedown', this.handleMouseDown);
    window.removeEventListener('mouseup', this.handleMouseUp);
    window.removeEventListener('mousemove', this.handleMouseMove);
    window.removeEventListener('wheel', this.handleWheel);
    window.removeEventListener('contextmenu', this.handleContextMenu);
    document.removeEventListener('pointerlockchange', this.handlePointerLockChange);
    window.removeEventListener('resize', this.handleResize);
    if (document.pointerLockElement === this.renderer.domElement) {
      document.exitPointerLock();
    }
    this.renderer.dispose();
    if (this.renderer.domElement.parentNode === this.container) {
      this.container.removeChild(this.renderer.domElement);
    }
  }

  // --- WEAPON SWITCH, JUMP & RELOAD ---
  private switchWeapon(next: WeaponId, force = false) {
    if (!force && next === this.activeWeapon) return;
    this.activeWeapon = next;
    this.isReloading = false;
    this.reloadElapsed = 0;
    this.adsAmount = 0;
    this.equipAlpha = 0;
    this.fireCooldown = 0.22;

    this.fpWeapons.ar.root.visible = next === 'ar';
    this.fpWeapons.pistol.root.visible = next === 'pistol';
    if (!force) {
      soundEngine.playWeaponSwitch();
    }
    this.emitHudState();
  }

  private tryJump() {
    if (!this.grounded) return;
    this.grounded = false;
    this.jumpLaunchY = this.playerPos.y;
    this.playerVel.y = JUMP_VELOCITY;
    soundEngine.playJump();
  }

  private tryStartReload() {
    if (this.isReloading) return;
    const spec = WEAPON_SPECS[this.activeWeapon];
    const curMag = this.ammoInMag[this.activeWeapon];
    const curRes = this.ammoReserve[this.activeWeapon];
    if (curMag >= spec.magSize || curRes <= 0) return;

    this.isReloading = true;
    this.isDryReload = curMag === 0;
    this.reloadDuration = this.isDryReload ? spec.dryReloadTime : spec.tacticalReloadTime;
    this.reloadElapsed = 0;
    this.reloadSoundStage = 0;
    this.emitHudState();
  }

  // --- BALLISTICS, MUZZLE FLASH, SHELL EJECTION & DECALS ---
  private fireShot() {
    const spec = WEAPON_SPECS[this.activeWeapon];
    const curAmmo = this.ammoInMag[this.activeWeapon];

    if (curAmmo <= 0) {
      soundEngine.playDryClick();
      this.fireCooldown = 0.22;
      this.semiTriggerConsumed = true;
      if (this.ammoReserve[this.activeWeapon] > 0) {
        this.tryStartReload();
      }
      return;
    }

    this.ammoInMag[this.activeWeapon] = curAmmo - 1;
    this.fireCooldown = 60 / spec.rpm;
    this.boltCycle = 1.0;
    this.muzzleFlashTimer = 0.046;

    // Weapon mechanical recoil & camera kick
    this.recoilPosZ = Math.min(0.095, this.recoilPosZ + spec.recoilKickZ);
    this.recoilPitch = Math.min(0.22, this.recoilPitch + spec.recoilPitch);
    this.recoilRoll += (Math.random() - 0.42) * spec.recoilRoll * 2;

    const adsCamScale = THREE.MathUtils.lerp(1.0, 0.72, this.adsAmount);
    this.camRecoilPitch += spec.cameraPitchKick * adsCamScale;
    this.camRecoilYaw += (Math.random() - 0.5) * 2 * spec.cameraYawJitter * adsCamScale;
    this.dynamicSpread = Math.min(0.045, this.dynamicSpread + (this.activeWeapon === 'ar' ? 0.0045 : 0.006));

    soundEngine.playGunshot(this.activeWeapon);
    this.spawnShellCasing();
    this.spawnMuzzleSmoke();
    this.performBallisticRaycast(spec);
    this.emitHudState();
  }

  private spawnShellCasing() {
    const rig = this.fpWeapons[this.activeWeapon];
    const spawnPos = new THREE.Vector3();

    if (this.cameraPerspective === 'FPV') {
      // Map ejection anchor from viewmodel camera space into world camera space!
      this.viewCamera.updateMatrixWorld(true);
      rig.ejectionAnchor.getWorldPosition(spawnPos); // in viewScene coords (where viewCamera is at origin)
      spawnPos.applyMatrix4(this.worldCamera.matrixWorld);
    } else {
      spawnPos.copy(this.playerPos).add(new THREE.Vector3(0.2, 1.38, 0));
    }

    const geo = this.activeWeapon === 'ar' ? this.shellGeo556 : this.shellGeo9mm;
    const mesh = new THREE.Mesh(geo, this.shellMat);
    mesh.position.copy(spawnPos);
    mesh.rotation.set(Math.random() * Math.PI, Math.random() * Math.PI, Math.random() * Math.PI);
    this.worldScene.add(mesh);

    // Eject upward & to the right relative to player look orientation
    const rightDir = new THREE.Vector3(1, 0, 0).applyQuaternion(this.worldCamera.quaternion);
    const upDir = new THREE.Vector3(0, 1, 0);
    const backDir = new THREE.Vector3(0, 0, 1).applyQuaternion(this.worldCamera.quaternion);

    const vel = new THREE.Vector3()
      .addScaledVector(rightDir, 2.3 + Math.random() * 0.9)
      .addScaledVector(upDir, 1.8 + Math.random() * 0.8)
      .addScaledVector(backDir, 0.4 + Math.random() * 0.5)
      .add(this.playerVel);

    this.shells.push({
      mesh,
      vel,
      rotVel: new THREE.Vector3(
        (Math.random() - 0.5) * 32,
        (Math.random() - 0.5) * 32,
        (Math.random() - 0.5) * 32
      ),
      life: 2.2,
      bounced: false,
    });

    if (this.shells.length > 36) {
      const oldest = this.shells.shift()!;
      this.worldScene.remove(oldest.mesh);
    }
  }

  private spawnMuzzleSmoke() {
    const rig = this.fpWeapons[this.activeWeapon];
    const pos = new THREE.Vector3();
    this.viewCamera.updateMatrixWorld(true);
    rig.muzzleAnchor.getWorldPosition(pos);
    pos.applyMatrix4(this.worldCamera.matrixWorld);

    const puff = new THREE.Mesh(new THREE.PlaneGeometry(0.11, 0.11), this.smokeMat.clone());
    puff.position.copy(pos);
    this.worldScene.add(puff);

    const forward = new THREE.Vector3(0, 0, -1).applyQuaternion(this.worldCamera.quaternion);
    this.particles.push({
      mesh: puff,
      vel: forward.multiplyScalar(1.4).add(new THREE.Vector3(0, 0.45, 0)),
      life: 0.36,
      maxLife: 0.36,
      isSmoke: true,
    });
  }

  private performBallisticRaycast(spec: (typeof WEAPON_SPECS)['ar']) {
    const spread =
      THREE.MathUtils.lerp(spec.hipSpread, spec.adsSpread, this.adsAmount) +
      this.dynamicSpread * THREE.MathUtils.lerp(1.0, 0.25, this.adsAmount);

    const ndcX = (Math.random() - 0.5) * 2 * spread;
    const ndcY = (Math.random() - 0.5) * 2 * spread;

    const raycaster = new THREE.Raycaster();
    raycaster.setFromCamera(new THREE.Vector2(ndcX, ndcY), this.worldCamera);

    const hits = raycaster.intersectObjects(this.shootableMeshes, false);
    if (hits.length === 0) return;

    const hit = hits[0];
    const hitPoint = hit.point;
    const hitNormal = hit.face
      ? hit.face.normal.clone().transformDirection(hit.object.matrixWorld).normalize()
      : new THREE.Vector3(0, 1, 0);

    // Check if we hit a Reactive Steel Tactical Target!
    const targetId = hit.object.userData.targetId as string | undefined;
    if (targetId) {
      const target = this.targets.find((t) => t.id === targetId);
      if (target) {
        const isHeadshot = hitPoint.y - (target.headCenterWorld.y - 1.48) > 1.36;
        target.flinchVel = isHeadshot ? 8.5 : 5.6;
        this.hitmarkerTime = 0.16;
        this.isHeadshotHit = isHeadshot;
        this.targetsHit += 1;
        soundEngine.playHitmarker(isHeadshot);
      }
    } else {
      // Spawn Bullet Hole Decal on static graybox obstacle / floor
      this.spawnBulletDecal(hitPoint, hitNormal);
    }

    // Spawn Impact Sparks & Dust Chips
    for (let i = 0; i < 6; i++) {
      const spark = new THREE.Mesh(new THREE.BoxGeometry(0.018, 0.018, 0.018), this.sparkMat);
      spark.position.copy(hitPoint).addScaledVector(hitNormal, 0.02);
      this.worldScene.add(spark);

      const bounceVel = hitNormal
        .clone()
        .multiplyScalar(1.8 + Math.random() * 2.6)
        .add(
          new THREE.Vector3(
            (Math.random() - 0.5) * 3.2,
            Math.random() * 2.2,
            (Math.random() - 0.5) * 3.2
          )
        );

      this.particles.push({
        mesh: spark,
        vel: bounceVel,
        life: 0.22 + Math.random() * 0.14,
        maxLife: 0.36,
        isSmoke: false,
      });
    }
  }

  private spawnBulletDecal(point: THREE.Vector3, normal: THREE.Vector3) {
    let decal: THREE.Mesh;
    if (this.decals.length < 75) {
      decal = new THREE.Mesh(this.decalGeo, this.decalMat);
      this.worldScene.add(decal);
      this.decals.push(decal);
    } else {
      decal = this.decals[this.decalIndex];
      this.decalIndex = (this.decalIndex + 1) % this.decals.length;
    }

    decal.position.copy(point).addScaledVector(normal, 0.005);
    const lookTarget = point.clone().add(normal);
    decal.lookAt(lookTarget);
    decal.rotateZ(Math.random() * Math.PI * 2);
  }

  // --- PLAYER MOVEMENT & STRICT HEIGHT-1 VS HEIGHT-1+ COLLISION ---
  private updatePlayerPhysics(dt: number) {
    const forwardInput = (this.keys.has('KeyW') ? 1 : 0) - (this.keys.has('KeyS') ? 1 : 0);
    const strafeInput = (this.keys.has('KeyD') ? 1 : 0) - (this.keys.has('KeyA') ? 1 : 0);
    const wantsCrouch = this.keys.has('KeyC') || this.keys.has('ControlLeft');
    const wantsSprint =
      this.keys.has('ShiftLeft') &&
      forwardInput > 0 &&
      !wantsCrouch &&
      !this.mouseRightDown &&
      !this.mouseLeftDown;

    // Smooth Crouch Interpolation (lowers eye height & posture, NEVER lifts playerPos.y feet!)
    this.crouchAmount = THREE.MathUtils.lerp(this.crouchAmount, wantsCrouch ? 1 : 0, Math.min(1, dt * 13));
    this.currentEyeHeight = THREE.MathUtils.lerp(EYE_HEIGHT_STAND, EYE_HEIGHT_CROUCH, this.crouchAmount);

    let targetSpeed = WALK_SPEED;
    if (wantsCrouch) targetSpeed = CROUCH_SPEED;
    else if (this.adsAmount > 0.35) targetSpeed = ADS_WALK_SPEED;
    else if (wantsSprint) targetSpeed = SPRINT_SPEED;

    // Compute world-space wish direction from yaw
    const sinY = Math.sin(this.yaw);
    const cosY = Math.cos(this.yaw);
    // yaw = 0 faces -Z: forward = (-sinY, 0, -cosY), right = (cosY, 0, -sinY)
    const wishX = -sinY * forwardInput + cosY * strafeInput;
    const wishZ = -cosY * forwardInput - sinY * strafeInput;
    const wishLen = Math.hypot(wishX, wishZ);

    const normX = wishLen > 0.001 ? wishX / wishLen : 0;
    const normZ = wishLen > 0.001 ? wishZ / wishLen : 0;

    const accel = this.grounded ? 16.0 : 5.5;
    this.playerVel.x = THREE.MathUtils.lerp(this.playerVel.x, normX * targetSpeed, Math.min(1, dt * accel));
    this.playerVel.z = THREE.MathUtils.lerp(this.playerVel.z, normZ * targetSpeed, Math.min(1, dt * accel));

    // Apply Gravity
    const prevY = this.playerPos.y;
    this.playerVel.y -= GRAVITY * dt;
    this.playerPos.y += this.playerVel.y * dt;

    // Clamp peak jump height strictly so delta above jumpLaunchY can never exceed 1.075m
    // (guarantees frame-rate independence for Height 1.0m jumpable vs Height 1+ non-jumpable!)
    if (!this.grounded && this.playerPos.y > this.jumpLaunchY + 1.075) {
      this.playerPos.y = this.jumpLaunchY + 1.075;
      if (this.playerVel.y > 0) this.playerVel.y = 0;
    }

    // Move X then resolve horizontal box walls
    this.playerPos.x += this.playerVel.x * dt;
    this.resolveHorizontalCollisions('x');

    // Move Z then resolve horizontal box walls
    this.playerPos.z += this.playerVel.z * dt;
    this.resolveHorizontalCollisions('z');

    // Clamp inside outer arena safety bounds
    const limit = ARENA_HALF_SIZE - 0.9;
    this.playerPos.x = THREE.MathUtils.clamp(this.playerPos.x, -limit, limit);
    this.playerPos.z = THREE.MathUtils.clamp(this.playerPos.z, -limit, limit);

    // Resolve Vertical Support (Floor y = 0 or Top of Height 1.0m boxes!)
    let supportY = 0;
    for (const box of MAP_BOXES) {
      const boxTop = box.y + box.h;
      const halfW = box.w / 2 + PLAYER_RADIUS * 0.82;
      const halfD = box.d / 2 + PLAYER_RADIUS * 0.82;

      const overBoxXZ =
        Math.abs(this.playerPos.x - box.x) < halfW &&
        Math.abs(this.playerPos.z - box.z) < halfD;

      if (!overBoxXZ) continue;

      // Can ONLY land on top of a box if:
      // 1) Box height relative to jumpLaunchY is <= MAX_CLIMBABLE_DELTA (1.08m => Height 1 boxes!)
      // 2) Player's feet reached at least boxTop - 0.06m
      const climbDelta = boxTop - this.jumpLaunchY;
      if (climbDelta <= MAX_CLIMBABLE_DELTA && (prevY >= boxTop - 0.06 || this.playerPos.y >= boxTop - 0.05)) {
        if (boxTop > supportY) {
          supportY = boxTop;
        }
      }
    }

    const wasGrounded = this.grounded;
    if (this.playerPos.y <= supportY + 0.001 && this.playerVel.y <= 0.05) {
      if (!wasGrounded && this.playerVel.y < -2.2) {
        const impactStrength = Math.min(1.0, Math.abs(this.playerVel.y) / 9.0);
        this.landImpact = Math.max(this.landImpact, impactStrength);
        soundEngine.playLand(impactStrength);
      }
      this.playerPos.y = supportY;
      this.playerVel.y = 0;
      this.grounded = true;
      this.jumpLaunchY = supportY;
    } else {
      this.grounded = false;
    }

    // Footstep Audio Cadence
    const horizSpeed = Math.hypot(this.playerVel.x, this.playerVel.z);
    if (this.grounded && horizSpeed > 0.6) {
      this.footstepAccum += horizSpeed * dt;
      const stepDist = wantsSprint ? 2.15 : 1.75;
      if (this.footstepAccum >= stepDist) {
        this.footstepAccum = 0;
        soundEngine.playFootstep(wantsSprint);
      }
    } else {
      this.footstepAccum = 0.8;
    }
  }

  private resolveHorizontalCollisions(axis: 'x' | 'z') {
    for (const box of MAP_BOXES) {
      const boxTop = box.y + box.h;
      const climbDelta = boxTop - this.jumpLaunchY;

      // If this is a Height 1 box (climbDelta <= 1.08m) AND the player has jumped up to its top rim,
      // allow horizontal movement smoothly onto the top face!
      // For ANY 1+ Height box (climbDelta > 1.08m), this condition is NEVER true -> strictly blocked!
      if (climbDelta <= MAX_CLIMBABLE_DELTA && this.playerPos.y >= boxTop - 0.055) {
        continue;
      }

      // If player is entirely above the box, no side collision
      if (this.playerPos.y >= boxTop) continue;

      const minX = box.x - box.w / 2 - PLAYER_RADIUS;
      const maxX = box.x + box.w / 2 + PLAYER_RADIUS;
      const minZ = box.z - box.d / 2 - PLAYER_RADIUS;
      const maxZ = box.z + box.d / 2 + PLAYER_RADIUS;

      if (
        this.playerPos.x > minX &&
        this.playerPos.x < maxX &&
        this.playerPos.z > minZ &&
        this.playerPos.z < maxZ
      ) {
        if (axis === 'x') {
          const penLeft = Math.abs(this.playerPos.x - minX);
          const penRight = Math.abs(maxX - this.playerPos.x);
          this.playerPos.x = penLeft < penRight ? minX : maxX;
          this.playerVel.x = 0;
        } else {
          const penFront = Math.abs(this.playerPos.z - minZ);
          const penBack = Math.abs(maxZ - this.playerPos.z);
          this.playerPos.z = penFront < penBack ? minZ : maxZ;
          this.playerVel.z = 0;
        }
      }
    }
  }

  // --- MAIN FRAME UPDATE & RENDER ---
  private animate = () => {
    this.animFrameId = requestAnimationFrame(this.animate);

    const now = performance.now();
    const dt = Math.min(0.05, Math.max(0.001, (now - this.lastTime) / 1000));
    this.lastTime = now;
    this.totalTime += dt;

    if (this.isMenuMode) {
      this.updateMenuStaging(dt);
    } else {
      this.updateGameplay(dt);
    }

    this.updateVfxAndTargets(dt);
    this.renderFrame();
  };

  private updateMenuStaging(dt: number) {
    // Showcase the official Mixamo Xbot.glb in its iconic T-pose facing the camera on the right!
    this.operator.root.position.set(0.72, 0, 17.2);
    this.operator.root.rotation.y = Math.PI + Math.sin(this.totalTime * 0.5) * 0.22;

    this.operator.update({
      dt,
      time: this.totalTime,
      speed: 0,
      maxSprintSpeed: SPRINT_SPEED,
      forwardMove: 0,
      strafeMove: 0,
      isSprinting: false,
      crouchAmount: 0,
      grounded: true,
      verticalVel: 0,
      landImpact: 0,
      aimPitch: 0,
      adsAmount: 0,
      recoilKick: 0,
      isReloading: false,
      reloadProgress: 0,
      activeWeapon: this.activeWeapon,
      firstPersonHideUpper: false,
      showcasePose: true,
    });

    this.worldCamera.fov = 40;
    this.worldCamera.updateProjectionMatrix();
    this.worldCamera.position.set(0.0, 1.05, 21.4);
    this.worldCamera.lookAt(0.0, 0.92, 17.2);
  }

  private updateGameplay(dt: number) {
    this.updatePlayerPhysics(dt);

    const spec = WEAPON_SPECS[this.activeWeapon];
    const forwardInput = (this.keys.has('KeyW') ? 1 : 0) - (this.keys.has('KeyS') ? 1 : 0);
    const strafeInput = (this.keys.has('KeyD') ? 1 : 0) - (this.keys.has('KeyA') ? 1 : 0);
    const horizSpeed = Math.hypot(this.playerVel.x, this.playerVel.z);
    const isSprinting =
      this.keys.has('ShiftLeft') &&
      forwardInput > 0 &&
      this.crouchAmount < 0.25 &&
      !this.mouseRightDown &&
      !this.mouseLeftDown &&
      horizSpeed > 3.5;

    // 1. ADS / Scope Smooth Transition
    const wantsAds = this.mouseRightDown && !this.isReloading && this.equipAlpha > 0.75;
    const adsSpeed = this.activeWeapon === 'pistol' ? 11.5 : 9.2;
    this.adsAmount = THREE.MathUtils.lerp(this.adsAmount, wantsAds ? 1 : 0, Math.min(1, dt * adsSpeed));

    // Camera Optical Zoom FOV during Scope/ADS
    const targetWorldFov = THREE.MathUtils.lerp(76, spec.adsFov, this.adsAmount);
    if (Math.abs(this.worldCamera.fov - targetWorldFov) > 0.02) {
      this.worldCamera.fov = targetWorldFov;
      this.worldCamera.updateProjectionMatrix();
    }
    const targetViewFov = THREE.MathUtils.lerp(50, 42, this.adsAmount);
    if (Math.abs(this.viewCamera.fov - targetViewFov) > 0.02) {
      this.viewCamera.fov = targetViewFov;
      this.viewCamera.updateProjectionMatrix();
    }

    // 2. Equip & Reload Progress + Keyframed Reload Foley Sounds
    this.equipAlpha = Math.min(1, this.equipAlpha + dt * 3.2);

    let reloadProgress = 0;
    if (this.isReloading) {
      this.reloadElapsed += dt;
      reloadProgress = Math.min(1, this.reloadElapsed / this.reloadDuration);

      if (reloadProgress >= 0.14 && this.reloadSoundStage < 1) {
        this.reloadSoundStage = 1;
        soundEngine.playReloadStep('magOut');
      }
      if (reloadProgress >= 0.56 && this.reloadSoundStage < 2) {
        this.reloadSoundStage = 2;
        soundEngine.playReloadStep('magIn');
      }
      if (this.activeWeapon === 'ar' && reloadProgress >= AR_RELOAD_TIMING.handleReached && this.reloadSoundStage < 3) {
        this.reloadSoundStage = 3;
        soundEngine.playReloadStep('chargingPull');
      } else if (this.activeWeapon === 'pistol' && this.isDryReload && reloadProgress >= 0.77 && this.reloadSoundStage < 3) {
        this.reloadSoundStage = 3;
        soundEngine.playReloadStep('boltSlap');
      }
      if (this.activeWeapon === 'ar' && reloadProgress >= AR_RELOAD_TIMING.handlePulled && this.reloadSoundStage < 4) {
        this.reloadSoundStage = 4;
        soundEngine.playReloadStep('boltSlap');
      }

      if (reloadProgress >= 1) {
        // Complete Reload & Transfer Rounds
        const needed = spec.magSize - this.ammoInMag[this.activeWeapon];
        const transfer = Math.min(needed, this.ammoReserve[this.activeWeapon]);
        this.ammoInMag[this.activeWeapon] += transfer;
        this.ammoReserve[this.activeWeapon] -= transfer;
        this.isReloading = false;
        reloadProgress = 0;
        this.emitHudState();
      }
    }

    // 3. Weapon Firing Loop (Full-Auto AR vs Crisp Semi-Auto Pistol)
    this.fireCooldown = Math.max(0, this.fireCooldown - dt);
    if (this.mouseLeftDown && !this.isReloading && this.equipAlpha > 0.85 && this.fireCooldown <= 0) {
      if (spec.fireMode === 'AUTO') {
        this.fireShot();
      } else if (!this.semiTriggerConsumed) {
        this.semiTriggerConsumed = true;
        this.fireShot();
      }
    }

    // 4. Decay Springs (Recoil, Bolt Cycle, Muzzle Light, Mouse Sway, Landing Shock)
    this.recoilPosZ = THREE.MathUtils.lerp(this.recoilPosZ, 0, Math.min(1, dt * 18));
    this.recoilPitch = THREE.MathUtils.lerp(this.recoilPitch, 0, Math.min(1, dt * 15));
    this.recoilRoll = THREE.MathUtils.lerp(this.recoilRoll, 0, Math.min(1, dt * 16));
    this.camRecoilPitch = THREE.MathUtils.lerp(this.camRecoilPitch, 0, Math.min(1, dt * 14));
    this.camRecoilYaw = THREE.MathUtils.lerp(this.camRecoilYaw, 0, Math.min(1, dt * 14));
    this.boltCycle = Math.max(0, this.boltCycle - dt * 16);
    this.muzzleFlashTimer = Math.max(0, this.muzzleFlashTimer - dt);
    this.mouseSwayX = THREE.MathUtils.lerp(this.mouseSwayX, 0, Math.min(1, dt * 12));
    this.mouseSwayY = THREE.MathUtils.lerp(this.mouseSwayY, 0, Math.min(1, dt * 12));
    this.landImpact = THREE.MathUtils.lerp(this.landImpact, 0, Math.min(1, dt * 9));
    this.dynamicSpread = THREE.MathUtils.lerp(this.dynamicSpread, 0, Math.min(1, dt * 9));
    this.hitmarkerTime = Math.max(0, this.hitmarkerTime - dt);

    const flashIntensity = this.muzzleFlashTimer > 0 ? 5.2 : 0;
    this.viewMuzzleLight.intensity = flashIntensity;
    this.worldMuzzleLight.intensity = flashIntensity * 1.4;

    // 5. Update World Camera (FPV or Over-The-Shoulder Tactical TPV)
    const effectiveYaw = this.yaw + this.camRecoilYaw;
    const effectivePitch = THREE.MathUtils.clamp(this.pitch + this.camRecoilPitch, -1.47, 1.47);

    // Subtle head-bob in FPV
    const headBobY =
      this.grounded && horizSpeed > 0.3
        ? Math.sin(this.totalTime * (isSprinting ? 14 : 10)) *
          (isSprinting ? 0.022 : 0.011) *
          THREE.MathUtils.lerp(1, 0.2, this.adsAmount)
        : 0;

    const eyeWorldPos = new THREE.Vector3(
      this.playerPos.x,
      this.playerPos.y + this.currentEyeHeight + headBobY - this.landImpact * 0.08,
      this.playerPos.z
    );

    const camEuler = new THREE.Euler(effectivePitch, effectiveYaw, 0, 'YXZ');
    this.worldCamera.quaternion.setFromEuler(camEuler);

    if (this.cameraPerspective === 'FPV') {
      // Slightly forward of spine center so looking down reveals chest belt, cargo thighs, knee pads & combat boots!
      const fwdOffset = new THREE.Vector3(0, 0, -0.10).applyAxisAngle(new THREE.Vector3(0, 1, 0), effectiveYaw);
      this.worldCamera.position.copy(eyeWorldPos).add(fwdOffset);
    } else {
      // Keep the character to the left of the aim point so the shoulder and
      // the forward-mounted rifle are visible instead of hiding behind the back.
      // Limit only the chase camera's orbit, not its look direction: at steep
      // pitch the original full rotation put the camera below the floor or far
      // above the player, making the external pose look backwards/distorted.
      const orbitPitch = THREE.MathUtils.clamp(effectivePitch, -0.48, 0.48);
      const orbit = new THREE.Quaternion().setFromEuler(new THREE.Euler(orbitPitch, effectiveYaw, 0, 'YXZ'));
      const shoulderOffset = new THREE.Vector3(0.72, 0.1, 2.05).applyQuaternion(orbit);
      this.worldCamera.position.copy(eyeWorldPos).add(shoulderOffset);
      if (this.worldCamera.position.y < 0.35) this.worldCamera.position.y = 0.35;
    }

    this.worldMuzzleLight.position.copy(eyeWorldPos);

    // 6. Update Full Articulated 3D Warzone Tactical Operator Model & Animations!
    this.operator.root.position.copy(this.playerPos);
    this.operator.root.rotation.y = effectiveYaw;
    this.operator.update({
      dt,
      time: this.totalTime,
      speed: horizSpeed,
      maxSprintSpeed: SPRINT_SPEED,
      forwardMove: forwardInput,
      strafeMove: strafeInput,
      isSprinting,
      crouchAmount: this.crouchAmount,
      grounded: this.grounded,
      verticalVel: this.playerVel.y,
      landImpact: this.landImpact,
      aimPitch: effectivePitch,
      adsAmount: this.adsAmount,
      recoilKick: this.boltCycle,
      isReloading: this.isReloading,
      reloadProgress,
      activeWeapon: this.activeWeapon,
      firstPersonHideUpper: this.cameraPerspective === 'FPV',
      isDryReload: this.isDryReload,
      ammoInMag: this.ammoInMag[this.activeWeapon],
      boltCycle: this.boltCycle,
      muzzleFlashTimer: this.muzzleFlashTimer,
    });

    // Keep sun shadow frustum centered near player for razor-sharp shadows across the arena
    this.sunLight.target.position.set(this.playerPos.x, 0, this.playerPos.z);
    this.sunLight.target.updateMatrixWorld();
    this.sunLight.position.set(this.playerPos.x + 22, 36, this.playerPos.z + 18);

    // 7. Update Active First-Person Weapon Rig & Tactical Hands Animation
    const activeRig = this.fpWeapons[this.activeWeapon];
    updateWeaponAnimation(activeRig, {
      dt,
      time: this.totalTime,
      adsAmount: this.adsAmount,
      isSprinting,
      moveSpeedNorm: Math.min(1, horizSpeed / WALK_SPEED),
      grounded: this.grounded,
      verticalVel: this.playerVel.y,
      landDip: this.landImpact,
      mouseSwayX: this.mouseSwayX,
      mouseSwayY: this.mouseSwayY,
      recoilPosZ: this.recoilPosZ,
      recoilPitch: this.recoilPitch,
      recoilRoll: this.recoilRoll,
      boltCycle: this.boltCycle,
      ammoInMag: this.ammoInMag[this.activeWeapon],
      isReloading: this.isReloading,
      reloadProgress,
      isDryReload: this.isDryReload,
      firstPerson: true,
      equipAlpha: this.equipAlpha,
      muzzleFlashTimer: this.muzzleFlashTimer,
    });
    this.fpArms.update(activeRig);

    // 8. Update Placed Tactical Recording Camera ([H]) & Schedule Frame Capture
    if (this.cameraNoticeTimer > 0) {
      this.cameraNoticeTimer = Math.max(0, this.cameraNoticeTimer - dt);
      if (this.cameraNoticeTimer === 0) {
        this.cameraNotice = null;
      }
    }

    if (this.recordingCamera.isPlaced) {
      const playerTorso = new THREE.Vector3(
        this.playerPos.x,
        this.playerPos.y + 1.22 - this.crouchAmount * 0.3,
        this.playerPos.z
      );
      this.recordingCamera.update(dt, playerTorso);

      if (!this.isViewingClip) {
        this.recordAccum += dt;
        const frameInterval = 1 / REC_FPS;
        if (this.recordAccum >= frameInterval) {
          this.recordAccum %= frameInterval;
          this.shouldCaptureRecFrame = true;
        }
      }
    }

    // 9. Emit Throttled Live HUD Telemetry (~30Hz + immediate on events)
    this.hudEmitAccum += dt;
    if (this.hudEmitAccum >= 0.033) {
      this.hudEmitAccum = 0;
      this.emitHudState();
    }
  }

  private updateVfxAndTargets(dt: number) {
    // Update Spinning 3D Brass Shell Casings
    for (let i = this.shells.length - 1; i >= 0; i--) {
      const s = this.shells[i];
      s.life -= dt;
      s.vel.y -= 18.5 * dt;
      s.mesh.position.addScaledVector(s.vel, dt);
      s.mesh.rotation.x += s.rotVel.x * dt;
      s.mesh.rotation.y += s.rotVel.y * dt;
      s.mesh.rotation.z += s.rotVel.z * dt;

      if (s.mesh.position.y <= 0.012) {
        s.mesh.position.y = 0.012;
        s.vel.y = Math.abs(s.vel.y) * 0.36;
        s.vel.x *= 0.65;
        s.vel.z *= 0.65;
        s.rotVel.multiplyScalar(0.5);
        if (!s.bounced) {
          s.bounced = true;
          soundEngine.playShellBounce();
        }
      }

      if (s.life <= 0) {
        this.worldScene.remove(s.mesh);
        this.shells.splice(i, 1);
      }
    }

    // Update Impact Sparks & Muzzle Smoke Wisps
    for (let i = this.particles.length - 1; i >= 0; i--) {
      const p = this.particles[i];
      p.life -= dt;
      if (!p.isSmoke) {
        p.vel.y -= 14 * dt;
      } else {
        p.mesh.quaternion.copy(this.worldCamera.quaternion);
        const grow = 1 + (1 - p.life / p.maxLife) * 2.4;
        p.mesh.scale.setScalar(grow);
        (p.mesh.material as THREE.MeshBasicMaterial).opacity = Math.max(0, (p.life / p.maxLife) * 0.24);
      }
      p.mesh.position.addScaledVector(p.vel, dt);

      if (p.life <= 0) {
        this.worldScene.remove(p.mesh);
        if (p.isSmoke) (p.mesh.material as THREE.Material).dispose();
        this.particles.splice(i, 1);
      }
    }

    // Update Reactive Steel Targets Spring Hinge
    for (const t of this.targets) {
      const springForce = -t.flinchAngle * 48 - t.flinchVel * 8.5;
      t.flinchVel += springForce * dt;
      t.flinchAngle += t.flinchVel * dt;
      t.pivot.rotation.x = -t.flinchAngle;
    }
  }

  private captureRecordingFrame() {
    const fullW = Math.max(1, this.container.clientWidth);
    const fullH = Math.max(1, this.container.clientHeight);
    const rw = Math.min(REC_WIDTH, fullW);
    const rh = Math.min(REC_HEIGHT, fullH);

    // Unhide the player's full 3rd-person Xbot upper body & weapon for the external camera pass!
    this.operator.setExternalCameraPass(true);
    this.recordingCamera.root.visible = false;

    this.renderer.setViewport(0, 0, rw, rh);
    this.renderer.setScissor(0, 0, rw, rh);
    this.renderer.setScissorTest(true);
    this.renderer.clear();
    this.renderer.render(this.worldScene, this.recordingCamera.renderCam);

    // Grab or allocate a frame canvas in the rolling buffer
    let frameCanvas: HTMLCanvasElement;
    if (this.recordedFrames.length >= MAX_REC_FRAMES) {
      frameCanvas = this.recordedFrames.shift()!;
    } else if (this.framePool.length > 0) {
      frameCanvas = this.framePool.pop()!;
    } else {
      frameCanvas = document.createElement('canvas');
      frameCanvas.width = REC_WIDTH;
      frameCanvas.height = REC_HEIGHT;
    }

    const ctx = frameCanvas.getContext('2d');
    if (ctx) {
      const dpr = this.renderer.getPixelRatio();
      const srcW = Math.round(rw * dpr);
      const srcH = Math.round(rh * dpr);
      const srcY = Math.max(0, this.renderer.domElement.height - srcH);
      ctx.drawImage(
        this.renderer.domElement,
        0,
        srcY,
        srcW,
        srcH,
        0,
        0,
        REC_WIDTH,
        REC_HEIGHT
      );

      // Update live PiP monitor in the HUD if mounted
      if (this.livePipCanvas) {
        const pipCtx = this.livePipCanvas.getContext('2d');
        pipCtx?.drawImage(
          frameCanvas,
          0,
          0,
          this.livePipCanvas.width,
          this.livePipCanvas.height
        );
      }
    }

    this.recordedFrames.push(frameCanvas);

    // Restore scene & full-screen viewport for the main player camera
    this.recordingCamera.root.visible = true;
    this.operator.setExternalCameraPass(false);
    this.renderer.setScissorTest(false);
    this.renderer.setViewport(0, 0, fullW, fullH);
  }

  private renderFrame() {
    if (this.shouldCaptureRecFrame && this.recordingCamera.isPlaced && !this.isMenuMode) {
      this.shouldCaptureRecFrame = false;
      this.captureRecordingFrame();
    }

    this.renderer.clear();
    this.renderer.render(this.worldScene, this.worldCamera);

    // Render crisp First-Person Weapon & Tactical Hands on cleared depth buffer when deployed in FPV
    if (!this.isMenuMode && this.cameraPerspective === 'FPV') {
      this.renderer.clearDepth();
      this.renderer.render(this.viewScene, this.viewCamera);
    }
  }

  private emitHudState() {
    const horizSpeed = Math.hypot(this.playerVel.x, this.playerVel.z);
    const isSprinting =
      this.keys.has('ShiftLeft') &&
      this.keys.has('KeyW') &&
      this.crouchAmount < 0.25 &&
      !this.mouseRightDown &&
      horizSpeed > 3.5;

    let stance: HudState['stance'] = 'STAND';
    if (!this.grounded) stance = 'AIR';
    else if (this.crouchAmount > 0.5) stance = 'CROUCH';
    else if (isSprinting) stance = 'SPRINT';

    const spec = WEAPON_SPECS[this.activeWeapon];
    const basePx = spec.id === 'ar' ? 14 : 10;
    const movePx = Math.min(18, horizSpeed * 2.4) + (this.grounded ? 0 : 16);
    const recoilPx = this.dynamicSpread * 620;
    const crosshairSpread = (basePx + movePx + recoilPx) * (1 - this.adsAmount * 0.85);

    this.onHudUpdate({
      activeWeapon: this.activeWeapon,
      ammoInMag: { ...this.ammoInMag },
      ammoReserve: { ...this.ammoReserve },
      isReloading: this.isReloading,
      reloadProgress: this.isReloading ? Math.min(1, this.reloadElapsed / this.reloadDuration) : 0,
      adsAmount: this.adsAmount,
      crosshairSpread,
      stance,
      elevationY: Math.max(0, Number(this.playerPos.y.toFixed(2))),
      cameraPerspective: this.cameraPerspective,
      hitmarkerTime: this.hitmarkerTime,
      isHeadshotHit: this.isHeadshotHit,
      targetsHit: this.targetsHit,
      pointerLocked: this.pointerLocked,
      cameraPlaced: this.recordingCamera?.isPlaced ?? false,
      recordedFramesCount: this.recordedFrames.length,
      recordedDurationSec: Number((this.recordedFrames.length / REC_FPS).toFixed(1)),
      isViewingClip: this.isViewingClip,
      cameraNotice: this.cameraNotice,
    });
  }
}
