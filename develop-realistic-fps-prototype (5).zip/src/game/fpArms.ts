import * as THREE from 'three';
import { decodeXbotPayload, type DecodedXbotPayload } from './playerModel';
import type { HandGripPose } from './types';
import { XBOT_BONES } from './xbotModelData';

type Side = 'Left' | 'Right';
type FingerName = 'Index' | 'Middle' | 'Ring' | 'Pinky';

interface JointChain {
  bones: THREE.Bone[];
  axes: THREE.Vector3[]; // flexion axis of each joint, in the joint's local (bind) frame
}

interface ArmSideRig {
  arm: THREE.Bone;
  fore: THREE.Bone;
  hand: THREE.Bone;
  upperLen: number; // cm
  foreLen: number; // cm
  lenAxis: THREE.Vector3; // bone axis pointing to the child joint (bind pose)
  handBindBasisT: THREE.Matrix4; // transpose of the hand's bind frame (fingers, palm, side)
  fingers: Record<FingerName, JointChain>;
  thumb: JointChain;
  shoulderRest: THREE.Vector3; // armature space (cm)
}

/** Hand IK targets + finger poses (implemented by every WeaponRig) */
export interface FpArmTargets {
  rightHandTarget: THREE.Object3D;
  leftHandTarget: THREE.Object3D;
  rightElbowHint: THREE.Object3D;
  leftElbowHint: THREE.Object3D;
  rightGrip: HandGripPose;
  leftGrip: HandGripPose;
}

const FINGERS: FingerName[] = ['Index', 'Middle', 'Ring', 'Pinky'];
// Xbot T-pose: palms face down (-Y), fingers point along the arm, thumbs point forward (+Z)
const PALM_BIND = new THREE.Vector3(0, -1, 0);
const THUMB_OPPOSITION_AXIS = new THREE.Vector3(1, 0, 0);

// Shoulder sockets in armature space (cm). The armature is the Xbot rotated 180° to face the
// view camera's -Z, so view (x, y, z) = armature (-x, y, -z) / 100. Both sit off-screen.
const SHOULDER_REST: Record<Side, THREE.Vector3> = {
  Right: new THREE.Vector3(-17, -24, -16), // view (0.17, -0.24, 0.16)
  Left: new THREE.Vector3(15, -25, -8), // view (-0.15, -0.25, 0.08)
};

// Scratch objects (no per-frame allocations)
const _armInv = new THREE.Matrix4();
const _qArmInv = new THREE.Quaternion();
const _qTarget = new THREE.Quaternion();
const _qHand = new THREE.Quaternion();
const _qFore = new THREE.Quaternion();
const _qUpper = new THREE.Quaternion();
const _qTmp = new THREE.Quaternion();
const _W = new THREE.Vector3();
const _H = new THREE.Vector3();
const _S = new THREE.Vector3();
const _E = new THREE.Vector3();
const _dir = new THREE.Vector3();
const _pole = new THREE.Vector3();
const _e1 = new THREE.Vector3();
const _e2 = new THREE.Vector3();
const _hinge = new THREE.Vector3();
const _hingeLocal = new THREE.Vector3();
const _fwdT = new THREE.Vector3();
const _palmT = new THREE.Vector3();
const _sideT = new THREE.Vector3();
const _palmPerp = new THREE.Vector3();
const _a3 = new THREE.Vector3();
const _b3 = new THREE.Vector3();
const _mA = new THREE.Matrix4();
const _mB = new THREE.Matrix4();

/** Rotation that maps the orthonormal pair (a1, a2) onto the orthonormal pair (b1, b2) */
function basisRotation(
  a1: THREE.Vector3,
  a2: THREE.Vector3,
  b1: THREE.Vector3,
  b2: THREE.Vector3,
  out: THREE.Quaternion
): THREE.Quaternion {
  _a3.crossVectors(a1, a2);
  _b3.crossVectors(b1, b2);
  _mA.makeBasis(a1, a2, _a3).transpose();
  _mB.makeBasis(b1, b2, _b3).multiply(_mA);
  return out.setFromRotationMatrix(_mB);
}

/**
 * First-person viewmodel arms built from the real Mixamo Xbot mesh (same model as the
 * third-person player). Two-bone IK places each wrist on its weapon hand target, the elbow
 * bends toward a pole hint, and every finger joint is curled around the grip.
 */
export class FirstPersonArms {
  public readonly root = new THREE.Group();
  public readonly whenReady: Promise<void>;
  private readonly armature = new THREE.Group();
  private sides: Partial<Record<Side, ArmSideRig>> = {};
  private ready = false;

  constructor() {
    this.root.name = 'FirstPersonXbotArms';
    this.armature.scale.setScalar(0.01);
    this.armature.rotation.y = Math.PI;
    this.root.add(this.armature);
    this.whenReady = decodeXbotPayload().then((payload) => this.build(payload));
  }

  private build(payload: DecodedXbotPayload) {
    const nameToIdx = new Map<string, number>();
    XBOT_BONES.forEach((b, i) => nameToIdx.set(b.name.replace('mixamorig:', ''), i));

    // 1. Arm-chain skeleton subset: <Side>Arm, <Side>ForeArm, <Side>Hand + all 20 finger bones
    const keep: number[] = [];
    XBOT_BONES.forEach((b, i) => {
      const n = b.name.replace('mixamorig:', '');
      for (const side of ['Left', 'Right'] as Side[]) {
        if (n === `${side}Arm` || n === `${side}ForeArm` || n.startsWith(`${side}Hand`)) keep.push(i);
      }
    });

    const origToNew = new Map<number, number>();
    const bones = keep.map((orig, ni) => {
      origToNew.set(orig, ni);
      const bone = new THREE.Bone();
      bone.name = XBOT_BONES[orig].name;
      bone.position.fromArray(XBOT_BONES[orig].t);
      return bone;
    });
    keep.forEach((orig, ni) => {
      const parentNew = origToNew.get(XBOT_BONES[orig].parent);
      if (parentNew === undefined) this.armature.add(bones[ni]); // upper-arm roots
      else bones[parentNew].add(bones[ni]);
    });
    const inverses = keep.map((orig) => new THREE.Matrix4().fromArray(payload.ibmFloats, orig * 16));
    const skeleton = new THREE.Skeleton(bones, inverses);

    // 2. Geometry subset: only triangles whose vertices all belong to the arm chains
    const jointsMat = new THREE.MeshStandardMaterial({
      color: new THREE.Color().setRGB(0.33333334, 0.12452888, 0.10101473, THREE.SRGBColorSpace),
      metalness: 0.5,
      roughness: 0.8585786,
      side: THREE.DoubleSide,
    });
    const surfaceMat = new THREE.MeshStandardMaterial({
      color: new THREE.Color().setRGB(0.837, 0.302308, 0.263655, THREE.SRGBColorSpace),
      metalness: 0.0,
      roughness: 0.80829155,
      side: THREE.DoubleSide,
    });

    payload.meshes.forEach((m, mi) => {
      const vCount = m.pos.length / 3;
      const dominant = new Int32Array(vCount);
      for (let v = 0; v < vCount; v++) {
        let best = 0;
        let bestW = -1;
        for (let c = 0; c < 4; c++) {
          const w = m.skinWeight[v * 4 + c];
          if (w > bestW) {
            bestW = w;
            best = m.skinIndex[v * 4 + c];
          }
        }
        dominant[v] = best;
      }

      const remap = new Int32Array(vCount).fill(-1);
      const used: number[] = [];
      const tris: number[] = [];
      for (let t = 0; t < m.indices.length; t += 3) {
        const a = m.indices[t];
        const b = m.indices[t + 1];
        const c = m.indices[t + 2];
        if (!origToNew.has(dominant[a]) || !origToNew.has(dominant[b]) || !origToNew.has(dominant[c])) continue;
        for (const v of [a, b, c]) {
          if (remap[v] === -1) {
            remap[v] = used.length;
            used.push(v);
          }
          tris.push(remap[v]);
        }
      }

      const n = used.length;
      const pos = new Float32Array(n * 3);
      const nor = new Float32Array(n * 3);
      const si = new Uint16Array(n * 4);
      const sw = new Float32Array(n * 4);
      used.forEach((v, k) => {
        pos.set(m.pos.subarray(v * 3, v * 3 + 3), k * 3);
        nor.set(m.norm.subarray(v * 3, v * 3 + 3), k * 3);
        // Re-target influences onto the subset skeleton (anything outside follows the dominant bone)
        const domNew = origToNew.get(dominant[v])!;
        const acc = new Map<number, number>();
        for (let c = 0; c < 4; c++) {
          const w = m.skinWeight[v * 4 + c];
          if (w <= 0) continue;
          const j = origToNew.get(m.skinIndex[v * 4 + c]) ?? domNew;
          acc.set(j, (acc.get(j) ?? 0) + w);
        }
        const entries = [...acc.entries()].sort((x, y) => y[1] - x[1]).slice(0, 4);
        const sum = entries.reduce((s, e) => s + e[1], 0) || 1;
        entries.forEach(([j, w], c) => {
          si[k * 4 + c] = j;
          sw[k * 4 + c] = w / sum;
        });
      });

      const geo = new THREE.BufferGeometry();
      geo.setAttribute('position', new THREE.BufferAttribute(pos, 3));
      geo.setAttribute('normal', new THREE.BufferAttribute(nor, 3));
      geo.setAttribute('skinIndex', new THREE.BufferAttribute(si, 4));
      geo.setAttribute('skinWeight', new THREE.BufferAttribute(sw, 4));
      geo.setIndex(tris);

      const mesh = new THREE.SkinnedMesh(geo, mi === 0 ? jointsMat : surfaceMat);
      mesh.name = mi === 0 ? 'FP_Beta_Joints' : 'FP_Beta_Surface';
      mesh.frustumCulled = false;
      this.root.add(mesh);
      mesh.bind(skeleton, new THREE.Matrix4());
    });

    // 3. Per-side IK data
    const byName = (n: string) => bones[origToNew.get(nameToIdx.get(n)!)!];
    const chain = (side: Side, finger: string): JointChain => {
      const jointBones = [1, 2, 3].map((k) => byName(`${side}Hand${finger}${k}`));
      const axes = [2, 3, 4].map((k) => {
        const segDir = byName(`${side}Hand${finger}${k}`).position.clone().normalize();
        return new THREE.Vector3().crossVectors(segDir, PALM_BIND).normalize();
      });
      return { bones: jointBones, axes };
    };

    for (const side of ['Left', 'Right'] as Side[]) {
      const arm = byName(`${side}Arm`);
      const fore = byName(`${side}ForeArm`);
      const hand = byName(`${side}Hand`);
      const fwdBind = byName(`${side}HandMiddle1`).position.clone().normalize();
      const sideBind = new THREE.Vector3().crossVectors(fwdBind, PALM_BIND);
      this.sides[side] = {
        arm,
        fore,
        hand,
        upperLen: fore.position.length(),
        foreLen: hand.position.length(),
        lenAxis: fore.position.clone().normalize(),
        handBindBasisT: new THREE.Matrix4().makeBasis(fwdBind, PALM_BIND, sideBind).transpose(),
        fingers: {
          Index: chain(side, 'Index'),
          Middle: chain(side, 'Middle'),
          Ring: chain(side, 'Ring'),
          Pinky: chain(side, 'Pinky'),
        },
        thumb: chain(side, 'Thumb'),
        shoulderRest: SHOULDER_REST[side].clone(),
      };
    }

    this.ready = true;
  }

  public update(targets: FpArmTargets) {
    if (!this.ready) return;
    this.armature.updateWorldMatrix(true, false);
    _armInv.copy(this.armature.matrixWorld).invert();
    this.armature.getWorldQuaternion(_qArmInv).invert();

    this.solveSide(this.sides.Right!, targets.rightHandTarget, targets.rightElbowHint, targets.rightGrip);
    this.solveSide(this.sides.Left!, targets.leftHandTarget, targets.leftElbowHint, targets.leftGrip);
  }

  private solveSide(rig: ArmSideRig, target: THREE.Object3D, hint: THREE.Object3D, grip: HandGripPose) {
    // Wrist target + hand frame (-Z = fingers, -Y = palm) in armature space
    target.updateWorldMatrix(true, false);
    hint.updateWorldMatrix(true, false);
    _W.setFromMatrixPosition(target.matrixWorld).applyMatrix4(_armInv);
    target.getWorldQuaternion(_qTarget).premultiply(_qArmInv);
    _fwdT.set(0, 0, -1).applyQuaternion(_qTarget);
    _palmT.set(0, -1, 0).applyQuaternion(_qTarget);
    _H.setFromMatrixPosition(hint.matrixWorld).applyMatrix4(_armInv);

    // Shoulder socket — slides (off-screen) so the wrist is always reachable with a natural elbow bend
    const a = rig.upperLen;
    const b = rig.foreLen;
    _S.copy(rig.shoulderRest);
    _dir.subVectors(_W, _S);
    let d = _dir.length();
    if (d < 1e-4) {
      _dir.set(0, 0, 1);
      d = 1e-4;
    } else {
      _dir.divideScalar(d);
    }
    const maxD = (a + b) * 0.93;
    const minD = (a + b) * 0.4;
    if (d > maxD) {
      _S.addScaledVector(_dir, d - maxD);
      d = maxD;
    } else if (d < minD) {
      _S.addScaledVector(_dir, d - minD);
      d = minD;
    }

    // Bend plane toward the elbow hint
    _pole.subVectors(_H, _S);
    _pole.addScaledVector(_dir, -_pole.dot(_dir));
    if (_pole.lengthSq() < 1e-6) {
      _pole.set(0, -1, 0).addScaledVector(_dir, _dir.y);
      if (_pole.lengthSq() < 1e-6) _pole.set(1, 0, 0);
    }
    _pole.normalize();

    // Two-bone IK (law of cosines)
    const cosA = THREE.MathUtils.clamp((a * a + d * d - b * b) / (2 * a * d), -1, 1);
    const sinA = Math.sqrt(Math.max(0, 1 - cosA * cosA));
    _e1.copy(_dir).multiplyScalar(cosA).addScaledVector(_pole, sinA);
    _E.copy(_S).addScaledVector(_e1, a);
    _e2.subVectors(_W, _E).normalize();
    _hinge.crossVectors(_dir, _pole).normalize();

    // Hand: exact target frame
    _palmT.addScaledVector(_fwdT, -_palmT.dot(_fwdT)).normalize();
    _sideT.crossVectors(_fwdT, _palmT);
    _mB.makeBasis(_fwdT, _palmT, _sideT).multiply(rig.handBindBasisT);
    _qHand.setFromRotationMatrix(_mB);

    // Forearm: points at the wrist, twisted so its palm side matches the hand (no candy-wrapped wrist)
    _palmPerp.copy(_palmT).addScaledVector(_e2, -_palmT.dot(_e2));
    if (_palmPerp.lengthSq() < 1e-4) _palmPerp.crossVectors(_hinge, _e2);
    _palmPerp.normalize();
    basisRotation(rig.lenAxis, PALM_BIND, _e2, _palmPerp, _qFore);

    // Upper arm: points at the elbow and shares the forearm's hinge axis (pure elbow flexion)
    _hingeLocal.copy(_hinge).applyQuaternion(_qTmp.copy(_qFore).invert());
    _hingeLocal.addScaledVector(rig.lenAxis, -_hingeLocal.dot(rig.lenAxis)).normalize();
    basisRotation(rig.lenAxis, _hingeLocal, _e1, _hinge, _qUpper);

    rig.arm.position.copy(_S);
    rig.arm.quaternion.copy(_qUpper);
    rig.fore.quaternion.copy(_qUpper).invert().multiply(_qFore);
    rig.hand.quaternion.copy(_qFore).invert().multiply(_qHand);

    // Fingers wrap the grip
    const curls: Record<FingerName, [number, number, number]> = {
      Index: grip.index,
      Middle: grip.middle,
      Ring: grip.ring,
      Pinky: grip.pinky,
    };
    for (const f of FINGERS) {
      const c = rig.fingers[f];
      const ang = curls[f];
      for (let k = 0; k < 3; k++) c.bones[k].quaternion.setFromAxisAngle(c.axes[k], ang[k]);
    }
    const th = rig.thumb;
    th.bones[0].quaternion
      .setFromAxisAngle(THUMB_OPPOSITION_AXIS, grip.thumbOpp)
      .multiply(_qTmp.setFromAxisAngle(th.axes[0], grip.thumb[0]));
    th.bones[1].quaternion.setFromAxisAngle(th.axes[1], grip.thumb[1]);
    th.bones[2].quaternion.setFromAxisAngle(th.axes[2], grip.thumb[2]);
  }
}
