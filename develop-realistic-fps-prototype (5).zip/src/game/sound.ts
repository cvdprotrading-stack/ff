import { WeaponId } from './types';

class TacticalSoundEngine {
  private ctx: AudioContext | null = null;
  private noiseBuffer: AudioBuffer | null = null;
  private masterGain: GainNode | null = null;

  private ensureContext(): AudioContext | null {
    if (typeof window === 'undefined') return null;
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (!AudioCtx) return null;
      this.ctx = new AudioCtx();
      this.masterGain = this.ctx.createGain();
      this.masterGain.gain.value = 0.58;
      this.masterGain.connect(this.ctx.destination);

      // Pre-build 1.5s white noise buffer
      const length = Math.floor(this.ctx.sampleRate * 1.5);
      this.noiseBuffer = this.ctx.createBuffer(1, length, this.ctx.sampleRate);
      const data = this.noiseBuffer.getChannelData(0);
      for (let i = 0; i < length; i++) {
        data[i] = Math.random() * 2 - 1;
      }
    }
    if (this.ctx.state === 'suspended') {
      this.ctx.resume().catch(() => {});
    }
    return this.ctx;
  }

  public unlock() {
    this.ensureContext();
  }

  public playGunshot(weapon: WeaponId) {
    const ctx = this.ensureContext();
    if (!ctx || !this.masterGain || !this.noiseBuffer) return;
    const now = ctx.currentTime;

    if (weapon === 'ar') {
      // 1. Sub-bass muzzle thump
      const subOsc = ctx.createOscillator();
      const subGain = ctx.createGain();
      subOsc.type = 'sine';
      subOsc.frequency.setValueAtTime(145, now);
      subOsc.frequency.exponentialRampToValueAtTime(34, now + 0.13);
      subGain.gain.setValueAtTime(0.95, now);
      subGain.gain.exponentialRampToValueAtTime(0.001, now + 0.14);
      subOsc.connect(subGain);
      subGain.connect(this.masterGain);
      subOsc.start(now);
      subOsc.stop(now + 0.15);

      // 2. Supersonic 5.56 propellant crack (bandpass noise + distortion)
      const crackNoise = ctx.createBufferSource();
      crackNoise.buffer = this.noiseBuffer;
      const bp = ctx.createBiquadFilter();
      bp.type = 'bandpass';
      bp.frequency.setValueAtTime(1750 + (Math.random() - 0.5) * 160, now);
      bp.Q.value = 0.85;
      const crackGain = ctx.createGain();
      crackGain.gain.setValueAtTime(1.0, now);
      crackGain.gain.exponentialRampToValueAtTime(0.18, now + 0.045);
      crackGain.gain.exponentialRampToValueAtTime(0.001, now + 0.28);
      crackNoise.connect(bp);
      bp.connect(crackGain);
      crackGain.connect(this.masterGain);
      crackNoise.start(now);
      crackNoise.stop(now + 0.3);

      // 3. Outdoor arena tail echo
      const tailNoise = ctx.createBufferSource();
      tailNoise.buffer = this.noiseBuffer;
      const lp = ctx.createBiquadFilter();
      lp.type = 'lowpass';
      lp.frequency.setValueAtTime(950, now + 0.02);
      lp.frequency.exponentialRampToValueAtTime(260, now + 0.52);
      const tailGain = ctx.createGain();
      tailGain.gain.setValueAtTime(0.28, now + 0.02);
      tailGain.gain.exponentialRampToValueAtTime(0.001, now + 0.55);
      tailNoise.connect(lp);
      lp.connect(tailGain);
      tailGain.connect(this.masterGain);
      tailNoise.start(now + 0.02);
      tailNoise.stop(now + 0.56);

      // 4. Mechanical bolt carrier clack
      this.playMetallicClick(now + 0.032, 3100, 0.16);
    } else {
      // 9mm Combat Pistol: sharp snappy pop + crisp slide cycle
      const subOsc = ctx.createOscillator();
      const subGain = ctx.createGain();
      subOsc.type = 'triangle';
      subOsc.frequency.setValueAtTime(195, now);
      subOsc.frequency.exponentialRampToValueAtTime(48, now + 0.09);
      subGain.gain.setValueAtTime(0.8, now);
      subGain.gain.exponentialRampToValueAtTime(0.001, now + 0.1);
      subOsc.connect(subGain);
      subGain.connect(this.masterGain);
      subOsc.start(now);
      subOsc.stop(now + 0.11);

      const snapNoise = ctx.createBufferSource();
      snapNoise.buffer = this.noiseBuffer;
      const hp = ctx.createBiquadFilter();
      hp.type = 'bandpass';
      hp.frequency.setValueAtTime(2300 + (Math.random() - 0.5) * 200, now);
      hp.Q.value = 1.05;
      const snapGain = ctx.createGain();
      snapGain.gain.setValueAtTime(0.88, now);
      snapGain.gain.exponentialRampToValueAtTime(0.001, now + 0.21);
      snapNoise.connect(hp);
      hp.connect(snapGain);
      snapGain.connect(this.masterGain);
      snapNoise.start(now);
      snapNoise.stop(now + 0.23);

      this.playMetallicClick(now + 0.024, 3750, 0.2);
    }
  }

  public playShellBounce() {
    const ctx = this.ensureContext();
    if (!ctx || !this.masterGain) return;
    const now = ctx.currentTime;
    const baseFreq = 4600 + Math.random() * 1100;
    [0, 0.09].forEach((offset, idx) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(baseFreq * (idx === 0 ? 1 : 1.12), now + offset);
      gain.gain.setValueAtTime(idx === 0 ? 0.045 : 0.024, now + offset);
      gain.gain.exponentialRampToValueAtTime(0.0005, now + offset + 0.055);
      osc.connect(gain);
      gain.connect(this.masterGain!);
      osc.start(now + offset);
      osc.stop(now + offset + 0.06);
    });
  }

  public playDryClick() {
    const ctx = this.ensureContext();
    if (!ctx) return;
    this.playMetallicClick(ctx.currentTime, 2750, 0.22);
  }

  public playReloadStep(step: 'magOut' | 'magIn' | 'chargingPull' | 'boltSlap') {
    const ctx = this.ensureContext();
    if (!ctx || !this.masterGain || !this.noiseBuffer) return;
    const now = ctx.currentTime;

    if (step === 'magOut') {
      // Mag catch click + polymer/steel friction slide
      this.playMetallicClick(now, 2100, 0.2);
      const slide = ctx.createBufferSource();
      slide.buffer = this.noiseBuffer;
      const bp = ctx.createBiquadFilter();
      bp.type = 'bandpass';
      bp.frequency.setValueAtTime(1100, now + 0.02);
      bp.frequency.linearRampToValueAtTime(650, now + 0.16);
      bp.Q.value = 2.4;
      const g = ctx.createGain();
      g.gain.setValueAtTime(0.16, now + 0.02);
      g.gain.exponentialRampToValueAtTime(0.001, now + 0.17);
      slide.connect(bp);
      bp.connect(g);
      g.connect(this.masterGain);
      slide.start(now + 0.02);
      slide.stop(now + 0.18);
    } else if (step === 'magIn') {
      // Heavy seated thump + sharp latch lock click
      const thump = ctx.createOscillator();
      const tg = ctx.createGain();
      thump.type = 'triangle';
      thump.frequency.setValueAtTime(150, now);
      thump.frequency.exponentialRampToValueAtTime(55, now + 0.075);
      tg.gain.setValueAtTime(0.36, now);
      tg.gain.exponentialRampToValueAtTime(0.001, now + 0.08);
      thump.connect(tg);
      tg.connect(this.masterGain);
      thump.start(now);
      thump.stop(now + 0.085);

      this.playMetallicClick(now + 0.038, 2500, 0.28);
    } else if (step === 'chargingPull') {
      this.playMetallicClick(now, 2400, 0.18);
      this.playMetallicClick(now + 0.065, 1700, 0.12);
    } else if (step === 'boltSlap') {
      // Crisp metallic bolt carrier / slide slam forward into battery
      this.playMetallicClick(now, 3200, 0.24);
      this.playMetallicClick(now + 0.045, 1950, 0.34);
    }
  }

  public playAdsToggle(entering: boolean) {
    const ctx = this.ensureContext();
    if (!ctx || !this.masterGain || !this.noiseBuffer) return;
    const now = ctx.currentTime;
    const rustle = ctx.createBufferSource();
    rustle.buffer = this.noiseBuffer;
    const bp = ctx.createBiquadFilter();
    bp.type = 'bandpass';
    bp.frequency.value = entering ? 850 : 680;
    bp.Q.value = 1.6;
    const g = ctx.createGain();
    g.gain.setValueAtTime(0.06, now);
    g.gain.exponentialRampToValueAtTime(0.001, now + 0.09);
    rustle.connect(bp);
    bp.connect(g);
    g.connect(this.masterGain);
    rustle.start(now);
    rustle.stop(now + 0.095);
  }

  public playWeaponSwitch() {
    const ctx = this.ensureContext();
    if (!ctx) return;
    const now = ctx.currentTime;
    this.playAdsToggle(true);
    this.playMetallicClick(now + 0.07, 1850, 0.14);
  }

  public playFootstep(sprinting: boolean) {
    const ctx = this.ensureContext();
    if (!ctx || !this.masterGain || !this.noiseBuffer) return;
    const now = ctx.currentTime;

    const osc = ctx.createOscillator();
    const og = ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(sprinting ? 105 : 84, now);
    osc.frequency.exponentialRampToValueAtTime(34, now + 0.075);
    og.gain.setValueAtTime(sprinting ? 0.22 : 0.13, now);
    og.gain.exponentialRampToValueAtTime(0.001, now + 0.08);
    osc.connect(og);
    og.connect(this.masterGain);
    osc.start(now);
    osc.stop(now + 0.085);

    const grit = ctx.createBufferSource();
    grit.buffer = this.noiseBuffer;
    const lp = ctx.createBiquadFilter();
    lp.type = 'bandpass';
    lp.frequency.value = 950 + Math.random() * 250;
    lp.Q.value = 1.4;
    const gg = ctx.createGain();
    gg.gain.setValueAtTime(sprinting ? 0.085 : 0.045, now);
    gg.gain.exponentialRampToValueAtTime(0.001, now + 0.065);
    grit.connect(lp);
    lp.connect(gg);
    gg.connect(this.masterGain);
    grit.start(now);
    grit.stop(now + 0.07);
  }

  public playJump() {
    this.playAdsToggle(true);
    this.playFootstep(true);
  }

  public playLand(intensity = 1) {
    const ctx = this.ensureContext();
    if (!ctx || !this.masterGain) return;
    const now = ctx.currentTime;
    const clamped = Math.min(1.4, Math.max(0.3, intensity));
    const osc = ctx.createOscillator();
    const g = ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(120, now);
    osc.frequency.exponentialRampToValueAtTime(28, now + 0.12);
    g.gain.setValueAtTime(0.3 * clamped, now);
    g.gain.exponentialRampToValueAtTime(0.001, now + 0.13);
    osc.connect(g);
    g.connect(this.masterGain);
    osc.start(now);
    osc.stop(now + 0.135);
    this.playAdsToggle(false);
  }

  public playHitmarker(headshot: boolean) {
    const ctx = this.ensureContext();
    if (!ctx || !this.masterGain) return;
    const now = ctx.currentTime;
    // Crisp Warzone-style double tick + steel target ring
    this.playMetallicClick(now, headshot ? 3800 : 2850, 0.32);
    if (headshot) {
      const ring = ctx.createOscillator();
      const rg = ctx.createGain();
      ring.type = 'triangle';
      ring.frequency.setValueAtTime(1680, now + 0.01);
      ring.frequency.exponentialRampToValueAtTime(1320, now + 0.18);
      rg.gain.setValueAtTime(0.18, now + 0.01);
      rg.gain.exponentialRampToValueAtTime(0.001, now + 0.19);
      ring.connect(rg);
      rg.connect(this.masterGain);
      ring.start(now + 0.01);
      ring.stop(now + 0.2);
    }
  }

  public playCameraPlace() {
    const ctx = this.ensureContext();
    if (!ctx || !this.masterGain) return;
    const now = ctx.currentTime;
    // Mechanical tripod lock clack + dual ascending cinema camera REC chime
    this.playMetallicClick(now, 1950, 0.25);
    [980, 1480].forEach((freq, i) => {
      const osc = ctx.createOscillator();
      const g = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, now + 0.04 + i * 0.075);
      g.gain.setValueAtTime(0.16, now + 0.04 + i * 0.075);
      g.gain.exponentialRampToValueAtTime(0.001, now + 0.11 + i * 0.075);
      osc.connect(g);
      g.connect(this.masterGain!);
      osc.start(now + 0.04 + i * 0.075);
      osc.stop(now + 0.12 + i * 0.075);
    });
  }

  public playClipToggle(opening: boolean) {
    const ctx = this.ensureContext();
    if (!ctx || !this.masterGain) return;
    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const g = ctx.createGain();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(opening ? 740 : 1120, now);
    osc.frequency.exponentialRampToValueAtTime(opening ? 1240 : 620, now + 0.09);
    g.gain.setValueAtTime(0.18, now);
    g.gain.exponentialRampToValueAtTime(0.001, now + 0.1);
    osc.connect(g);
    g.connect(this.masterGain);
    osc.start(now);
    osc.stop(now + 0.11);
  }

  private playMetallicClick(time: number, freq: number, volume: number) {
    if (!this.ctx || !this.masterGain || !this.noiseBuffer) return;
    const noise = this.ctx.createBufferSource();
    noise.buffer = this.noiseBuffer;
    const bp = this.ctx.createBiquadFilter();
    bp.type = 'bandpass';
    bp.frequency.setValueAtTime(freq, time);
    bp.Q.value = 4.2;
    const g = this.ctx.createGain();
    g.gain.setValueAtTime(volume, time);
    g.gain.exponentialRampToValueAtTime(0.001, time + 0.038);
    noise.connect(bp);
    bp.connect(g);
    g.connect(this.masterGain);
    noise.start(time);
    noise.stop(time + 0.042);
  }
}

export const soundEngine = new TacticalSoundEngine();
