import * as THREE from 'three';
import { RoundedBoxGeometry } from 'three/addons/geometries/RoundedBoxGeometry.js';
import { mergeGeometries, toCreasedNormals } from 'three/addons/utils/BufferGeometryUtils.js';

export type Point2 = [number, number];
export type Point3 = [number, number, number];

export function mesh(
  parent: THREE.Object3D,
  geometry: THREE.BufferGeometry,
  material: THREE.Material,
  position: Point3 = [0, 0, 0],
  name = ''
) {
  const object = new THREE.Mesh(geometry, material);
  object.position.set(...position);
  object.name = name;
  object.castShadow = !material.transparent;
  object.receiveShadow = true;
  parent.add(object);
  return object;
}

export function roundedBox(
  parent: THREE.Object3D,
  material: THREE.Material,
  size: Point3,
  position: Point3,
  radius = 0.001,
  name = ''
) {
  return mesh(parent, new RoundedBoxGeometry(...size, 3, Math.min(radius, ...size.map((v) => v * 0.45))), material, position, name);
}

/** Points use forward distance and height; the resulting extrusion is across X. */
export function polygon(points: Point2[]): THREE.Shape {
  const shape = new THREE.Shape();
  points.forEach(([x, y], i) => i ? shape.lineTo(x, y) : shape.moveTo(x, y));
  shape.closePath();
  return shape;
}

export function roundedRect(x: number, y: number, w: number, h: number, radius: number): THREE.Shape {
  const r = Math.min(radius, w / 2, h / 2);
  const s = new THREE.Shape();
  s.moveTo(x + r, y);
  s.lineTo(x + w - r, y);
  s.quadraticCurveTo(x + w, y, x + w, y + r);
  s.lineTo(x + w, y + h - r);
  s.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
  s.lineTo(x + r, y + h);
  s.quadraticCurveTo(x, y + h, x, y + h - r);
  s.lineTo(x, y + r);
  s.quadraticCurveTo(x, y, x + r, y);
  s.closePath();
  return s;
}

export function cutHole(shape: THREE.Shape, hole: THREE.Shape) {
  shape.holes.push(new THREE.Path(hole.getPoints(10).reverse()));
  return shape;
}

export function extrusion(shape: THREE.Shape, thickness: number, bevel = 0.0006) {
  const depth = Math.max(0.0002, thickness - 2 * bevel);
  const geo = new THREE.ExtrudeGeometry(shape, {
    depth,
    bevelEnabled: bevel > 0,
    bevelThickness: bevel,
    bevelSize: bevel,
    bevelSegments: 3,
    steps: 1,
    curveSegments: 10,
  });
  geo.translate(0, 0, -depth / 2);
  // Extrusion UVs are in meters. Keep micro-textures at consistent world scale.
  const uv = geo.getAttribute('uv');
  for (let i = 0; i < uv.count; i++) uv.setXY(i, uv.getX(i) * 16, uv.getY(i) * 16);
  // The utility hashes positions at 0.01-unit precision. Smooth in millimeters
  // so distinct machined edges are not accidentally welded a centimeter apart.
  const flatNormals = geo.getAttribute('normal').clone();
  geo.scale(1000, 1000, 1000);
  const smoothed = toCreasedNormals(geo, Math.PI / 3);
  smoothed.scale(0.001, 0.001, 0.001);
  const normals = smoothed.getAttribute('normal');
  // Preserve the flat machined faces; only the bevels need interpolated normals.
  for (let i = 0; i < normals.count; i++) {
    if (Math.abs(flatNormals.getZ(i)) > 0.99999) normals.setXYZ(i, 0, 0, flatNormals.getZ(i));
  }
  return smoothed;
}

export function sideProfile(
  parent: THREE.Object3D,
  material: THREE.Material,
  shape: THREE.Shape,
  width: number,
  x = 0,
  bevel = 0.0007,
  name = ''
) {
  const geo = extrusion(shape, width, bevel);
  geo.rotateY(Math.PI / 2);
  return mesh(parent, geo, material, [x, 0, 0], name);
}

export function cylinder(
  parent: THREE.Object3D,
  material: THREE.Material,
  radius: number,
  length: number,
  position: Point3,
  axis: 'x' | 'y' | 'z' = 'z',
  segments = 32,
  endRadius = radius
) {
  const geo = new THREE.CylinderGeometry(radius, endRadius, length, segments);
  if (axis === 'z') geo.rotateX(Math.PI / 2);
  if (axis === 'x') geo.rotateZ(Math.PI / 2);
  return mesh(parent, geo, material, position);
}

export function tube(
  parent: THREE.Object3D,
  material: THREE.Material,
  outer: number,
  inner: number,
  length: number,
  position: Point3,
  axis: 'x' | 'y' | 'z' = 'z'
) {
  const s = new THREE.Shape();
  s.absarc(0, 0, outer, 0, Math.PI * 2, false);
  const h = new THREE.Path();
  h.absarc(0, 0, inner, 0, Math.PI * 2, true);
  s.holes.push(h);
  const geo = extrusion(s, length, 0.00015);
  if (axis === 'x') geo.rotateY(Math.PI / 2);
  if (axis === 'y') geo.rotateX(Math.PI / 2);
  return mesh(parent, geo, material, position);
}

export function screw(parent: THREE.Object3D, material: THREE.Material, position: Point3, radius = 0.0028, axis: 'x' | 'y' | 'z' = 'x') {
  const screwGroup = new THREE.Group();
  screwGroup.position.set(...position);
  if (axis === 'x') screwGroup.rotation.y = Math.PI / 2;
  if (axis === 'y') screwGroup.rotation.x = -Math.PI / 2;
  parent.add(screwGroup);
  cylinder(screwGroup, material, radius, 0.0011, [0, 0, 0]);
  const socket = new THREE.Shape();
  socket.absarc(0, 0, radius * 0.48, 0, Math.PI * 2, false);
  const recess = mesh(screwGroup, new THREE.ShapeGeometry(socket, 6), fastenerRecess, [0, 0, 0.00057]);
  recess.rotation.z = Math.PI / 6;
  return screwGroup;
}

const fastenerRecess = new THREE.MeshStandardMaterial({ color: 0x090b0e, roughness: 0.8 });

export function curveStrip(parent: THREE.Object3D, material: THREE.Material, points: Point3[], radius: number) {
  const curve = new THREE.CatmullRomCurve3(points.map((p) => new THREE.Vector3(...p)));
  return mesh(parent, new THREE.TubeGeometry(curve, 24, radius, 6, false), material);
}

export interface MagazineBodyOptions {
  top: number;
  bottom: number;
  width: number;
  depth: number;
  curve: number;
  ribs?: boolean;
}

/** One closed, UV-mapped magazine shell. Cap vertices are separate so the seam stays crisp. */
export function magazineBody(options: MagazineBodyOptions) {
  const { top, bottom, width, depth, curve, ribs } = options;
  const sections = 36;
  const ring = roundedRect(-width / 2, -depth / 2, width, depth, 0.0028).getSpacedPoints(96);
  ring.pop();
  const positions: number[] = [];
  const uvs: number[] = [];
  const indices: number[] = [];
  const n = ring.length;
  const shift = (t: number) => curve * Math.pow(Math.max(0, (t - 0.22) / 0.78), 1.65);
  for (let i = 0; i <= sections; i++) {
    const t = i / sections;
    for (let j = 0; j <= n; j++) {
      const p = ring[j % n];
      const side = Math.abs(p.x) > width * 0.36;
      let x = p.x * (1 - 0.015 * t);
      if (ribs && side && t > 0.24 && t < 0.95) {
        const groove = [-0.017, 0, 0.017].reduce((v, c) => Math.max(v, Math.exp(-Math.pow((p.y - c) / 0.0024, 4))), 0);
        x -= Math.sign(x) * groove * 0.00065;
      }
      positions.push(x, THREE.MathUtils.lerp(top, bottom, t), p.y + shift(t));
      uvs.push(j / n * 2, t * 2);
    }
  }
  for (let i = 0; i < sections; i++) {
    for (let j = 0; j < n; j++) {
      const a = i * (n + 1) + j;
      const b = a + 1;
      const d = a + n + 1;
      indices.push(a, b, d, b, d + 1, d);
    }
  }
  for (const end of [0, 1]) {
    const center = positions.length / 3;
    const y = end ? bottom : top;
    positions.push(0, y, shift(end));
    uvs.push(0.5, 0.5);
    for (let j = 0; j <= n; j++) {
      const p = ring[j % n];
      positions.push(p.x * (1 - end * 0.015), y, p.y + shift(end));
      uvs.push(p.x / width + 0.5, p.y / depth + 0.5);
    }
    for (let j = 0; j < n; j++) {
      const a = center + j + 1;
      if (end) indices.push(center, a, a + 1);
      else indices.push(center, a + 1, a);
    }
  }
  const geo = new THREE.BufferGeometry();
  geo.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
  geo.setAttribute('uv', new THREE.Float32BufferAttribute(uvs, 2));
  geo.setIndex(indices);
  geo.computeVertexNormals();
  return geo;
}

export function engraving(parent: THREE.Object3D, lines: string[], position: Point3, size: [number, number], side: 1 | -1 = 1) {
  const canvas = document.createElement('canvas');
  canvas.width = 512;
  canvas.height = 256;
  const ctx = canvas.getContext('2d')!;
  ctx.clearRect(0, 0, 512, 256);
  ctx.fillStyle = '#9a9c9b';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  lines.forEach((line, i) => {
    ctx.font = `${i === 0 ? '600' : '400'} ${i === 0 ? 60 : 32}px monospace`;
    ctx.fillText(line, 256, 65 + i * 56, 490);
  });
  const map = new THREE.CanvasTexture(canvas);
  map.colorSpace = THREE.SRGBColorSpace;
  map.anisotropy = 8;
  const material = new THREE.MeshStandardMaterial({ map, transparent: true, depthWrite: false, roughness: 0.58, polygonOffset: true, polygonOffsetFactor: -1 });
  const marking = mesh(parent, new THREE.PlaneGeometry(...size), material, position);
  marking.rotation.y = side * Math.PI / 2;
  marking.castShadow = false;
  return marking;
}

// Batch only unnamed rigid pieces. Named meshes and separate animation groups
// retain their transforms, including magazine bodies and the stock contact pad.
export function batchRigidParts(group: THREE.Group) {
  for (const child of [...group.children]) {
    if (child instanceof THREE.Group) batchRigidParts(child);
  }
  const buckets = new Map<THREE.Material, THREE.Mesh[]>();
  for (const child of group.children) {
    if (!(child instanceof THREE.Mesh) || child.name || Array.isArray(child.material) || child.material.transparent || child.children.length) continue;
    const list = buckets.get(child.material) ?? [];
    list.push(child);
    buckets.set(child.material, list);
  }
  for (const [material, objects] of buckets) {
    if (objects.length < 2) continue;
    const geometries = objects.map((object) => {
      object.updateMatrix();
      const geo = object.geometry.index ? object.geometry.toNonIndexed() : object.geometry.clone();
      return geo.applyMatrix4(object.matrix);
    });
    const merged = mergeGeometries(geometries, false);
    geometries.forEach((g) => g.dispose());
    if (!merged) continue;
    objects.forEach((object) => {
      group.remove(object);
      object.geometry.dispose();
    });
    mesh(group, merged, material);
  }
}