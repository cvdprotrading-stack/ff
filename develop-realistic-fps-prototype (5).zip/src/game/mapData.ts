import { BoxObstacle } from './types';

export interface TargetPlacement {
  id: string;
  x: number;
  y: number; // base height
  z: number;
  facingYaw: number;
}

export const ARENA_HALF_SIZE = 28; // 56m x 56m clean blockout floor
export const PLAYER_SPAWN = { x: 0, y: 0, z: 20 };

// Strictly basic geometric boxes:
// - variant 'height1' => h === 1.0m (Player CAN jump on top)
// - variant 'height1Plus' => h > 1.0m (1.35m, 1.5m, 1.8m, 2.0m, 2.5m — Player CANNOT jump on top)
export const MAP_BOXES: BoxObstacle[] = [
  // Perimeter Boundary Walls (h = 4.0m)
  { id: 'wall-n', x: 0, y: 0, z: -ARENA_HALF_SIZE, w: ARENA_HALF_SIZE * 2 + 1, h: 4.0, d: 1.0, variant: 'wall', label: 'WALL' },
  { id: 'wall-s', x: 0, y: 0, z: ARENA_HALF_SIZE, w: ARENA_HALF_SIZE * 2 + 1, h: 4.0, d: 1.0, variant: 'wall', label: 'WALL' },
  { id: 'wall-w', x: -ARENA_HALF_SIZE, y: 0, z: 0, w: 1.0, h: 4.0, d: ARENA_HALF_SIZE * 2 + 1, variant: 'wall', label: 'WALL' },
  { id: 'wall-e', x: ARENA_HALF_SIZE, y: 0, z: 0, w: 1.0, h: 4.0, d: ARENA_HALF_SIZE * 2 + 1, variant: 'wall', label: 'WALL' },

  // --- FRONT CALIBRATION ROW (Right ahead of spawn at z = 11.5) ---
  // Spaced cleanly apart so 1.0m is jumpable and 1+ boxes are strictly non-jumpable
  {
    id: 'cal-h1-left',
    x: -7.5,
    y: 0,
    z: 11.5,
    w: 2.4,
    h: 1.0,
    d: 2.4,
    variant: 'height1',
    label: 'H: 1.0M',
  },
  {
    id: 'cal-h1-midleft',
    x: -2.6,
    y: 0,
    z: 11.5,
    w: 2.4,
    h: 1.0,
    d: 2.4,
    variant: 'height1',
    label: 'H: 1.0M',
  },
  {
    id: 'cal-h1plus-135',
    x: 2.6,
    y: 0,
    z: 11.5,
    w: 2.4,
    h: 1.35,
    d: 2.4,
    variant: 'height1Plus',
    label: 'H: 1.35M',
  },
  {
    id: 'cal-h1plus-200',
    x: 7.5,
    y: 0,
    z: 11.5,
    w: 2.4,
    h: 2.0,
    d: 2.4,
    variant: 'height1Plus',
    label: 'H: 2.0M',
  },

  // --- CENTER ARENA COVER BOXES ---
  // Central 1+ High Blockout Cover (h = 2.2m & h = 1.6m)
  {
    id: 'mid-core-22',
    x: 0,
    y: 0,
    z: 0,
    w: 4.4,
    h: 2.2,
    d: 4.4,
    variant: 'height1Plus',
    label: 'H: 2.2M',
  },
  {
    id: 'mid-flank-w-16',
    x: -6.8,
    y: 0,
    z: 1.5,
    w: 2.6,
    h: 1.6,
    d: 3.6,
    variant: 'height1Plus',
    label: 'H: 1.6M',
  },
  {
    id: 'mid-flank-e-15',
    x: 6.8,
    y: 0,
    z: -1.5,
    w: 2.6,
    h: 1.5,
    d: 3.6,
    variant: 'height1Plus',
    label: 'H: 1.5M',
  },

  // --- WEST LANE TACTICAL BOXES ---
  {
    id: 'west-h1-a',
    x: -15.5,
    y: 0,
    z: 13.0,
    w: 3.2,
    h: 1.0,
    d: 2.4,
    variant: 'height1',
    label: 'H: 1.0M',
  },
  {
    id: 'west-h1-b',
    x: -17.0,
    y: 0,
    z: 4.5,
    w: 2.6,
    h: 1.0,
    d: 4.0,
    variant: 'height1',
    label: 'H: 1.0M',
  },
  {
    id: 'west-h1plus-18',
    x: -15.5,
    y: 0,
    z: -5.5,
    w: 3.4,
    h: 1.8,
    d: 3.4,
    variant: 'height1Plus',
    label: 'H: 1.8M',
  },
  {
    id: 'west-h1-north',
    x: -18.5,
    y: 0,
    z: -15.0,
    w: 3.0,
    h: 1.0,
    d: 3.0,
    variant: 'height1',
    label: 'H: 1.0M',
  },

  // --- EAST LANE TACTICAL BOXES ---
  {
    id: 'east-h1-a',
    x: 15.5,
    y: 0,
    z: 14.0,
    w: 2.8,
    h: 1.0,
    d: 2.8,
    variant: 'height1',
    label: 'H: 1.0M',
  },
  {
    id: 'east-h1plus-25',
    x: 16.5,
    y: 0,
    z: 4.0,
    w: 3.6,
    h: 2.5,
    d: 3.6,
    variant: 'height1Plus',
    label: 'H: 2.5M',
  },
  {
    id: 'east-h1-b',
    x: 16.0,
    y: 0,
    z: -7.5,
    w: 3.6,
    h: 1.0,
    d: 2.4,
    variant: 'height1',
    label: 'H: 1.0M',
  },
  {
    id: 'east-h1plus-14',
    x: 18.0,
    y: 0,
    z: -16.5,
    w: 3.0,
    h: 1.4,
    d: 3.0,
    variant: 'height1Plus',
    label: 'H: 1.4M',
  },

  // --- NORTH FIRING RANGE / BACKFIELD BOXES ---
  {
    id: 'north-h1-center',
    x: 0,
    y: 0,
    z: -10.5,
    w: 4.2,
    h: 1.0,
    d: 2.2,
    variant: 'height1',
    label: 'H: 1.0M',
  },
  {
    id: 'north-h1plus-w',
    x: -8.5,
    y: 0,
    z: -17.5,
    w: 3.4,
    h: 2.0,
    d: 2.6,
    variant: 'height1Plus',
    label: 'H: 2.0M',
  },
  {
    id: 'north-h1plus-e',
    x: 8.5,
    y: 0,
    z: -17.5,
    w: 3.4,
    h: 1.5,
    d: 2.6,
    variant: 'height1Plus',
    label: 'H: 1.5M',
  },
];

export const MAP_TARGETS: TargetPlacement[] = [
  { id: 't-close-w', x: -5.2, y: 0, z: 5.5, facingYaw: 0 },
  { id: 't-close-e', x: 5.2, y: 0, z: 4.5, facingYaw: 0 },
  { id: 't-mid-top', x: 0, y: 1.0, z: -10.5, facingYaw: 0 },
  { id: 't-long-mid', x: 0, y: 0, z: -23.5, facingYaw: 0 },
  { id: 't-long-w', x: -13.0, y: 0, z: -22.0, facingYaw: 0.18 },
  { id: 't-long-e', x: 13.0, y: 0, z: -22.0, facingYaw: -0.18 },
  { id: 't-flank-w', x: -21.5, y: 0, z: -2.0, facingYaw: 0.45 },
];
