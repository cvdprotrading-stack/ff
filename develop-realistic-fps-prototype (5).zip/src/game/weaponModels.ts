import * as THREE from 'three';
import {
  batchRigidParts, curveStrip, cutHole, cylinder, engraving, extrusion,
  magazineBody, mesh, polygon, roundedBox, roundedRect, screw, sideProfile, tube,
} from './weaponGeometry';
import { createGunMaterials, type GunMaterials } from './weaponMaterials';

export interface GunModel {
  root: THREE.Group;
  gunBody: THREE.Group;
  magGroup: THREE.Group;
  magazineSocket: THREE.Object3D;
  magazineGrip: THREE.Object3D;
  magazineBody: THREE.Mesh;
  magRestPos: THREE.Vector3;
  boltOrSlide: THREE.Group;
  chargingOrHammer: THREE.Group;
  trigger: THREE.Mesh;
  muzzleFlash: THREE.Group;
  muzzleAnchor: THREE.Object3D;
  ejectionAnchor: THREE.Object3D;
  reticleMat?: THREE.MeshBasicMaterial;
  stockAssembly?: THREE.Group;
  stockPad?: THREE.Mesh;
}

function group(parent?: THREE.Object3D, name = '') {
  const g = new THREE.Group();
  g.name = name;
  parent?.add(g);
  return g;
}

function muzzleFlash() {
  const canvas = document.createElement('canvas');
  canvas.width = canvas.height = 128;
  const ctx = canvas.getContext('2d')!;
  const gradient = ctx.createRadialGradient(64, 64, 2, 64, 64, 64);
  gradient.addColorStop(0, 'rgba(255,255,238,1)');
  gradient.addColorStop(0.2, 'rgba(255,220,135,0.9)');
  gradient.addColorStop(0.5, 'rgba(255,126,35,0.45)');
  gradient.addColorStop(1, 'rgba(255,80,0,0)');
  ctx.fillStyle = gradient;
  ctx.fillRect(0, 0, 128, 128);
  const material = new THREE.MeshBasicMaterial({ map: new THREE.CanvasTexture(canvas), transparent: true, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide, toneMapped: false });
  const g = group(undefined, 'muzzle-flash');
  mesh(g, new THREE.PlaneGeometry(0.15, 0.15), material).castShadow = false;
  for (const angle of [0, Math.PI / 2]) {
    const flame = mesh(g, new THREE.PlaneGeometry(0.2, 0.09), material, [0, 0, -0.07]);
    flame.rotation.set(angle, Math.PI / 2, 0);
    flame.castShadow = false;
  }
  g.visible = false;
  return g;
}

function makeBase(name: string): GunModel {
  const root = group(undefined, name);
  const gunBody = group(root, 'body');
  const magazineSocket = new THREE.Object3D();
  magazineSocket.name = 'magazine-socket';
  gunBody.add(magazineSocket);
  const magGroup = group(gunBody, 'magazine');
  const magazineGrip = new THREE.Object3D();
  magazineGrip.name = 'magazine-hand-contact';
  magGroup.add(magazineGrip);
  const boltOrSlide = group(gunBody, 'bolt-or-slide');
  const chargingOrHammer = group(gunBody, 'charging-handle');
  const muzzleAnchor = new THREE.Object3D();
  const ejectionAnchor = new THREE.Object3D();
  muzzleAnchor.name = 'muzzle';
  ejectionAnchor.name = 'ejection-port';
  gunBody.add(muzzleAnchor, ejectionAnchor);
  const flash = muzzleFlash();
  gunBody.add(flash);
  // The two named meshes are filled by the model builder below.
  return { root, gunBody, magazineSocket, magGroup, magazineGrip, boltOrSlide, chargingOrHammer,
    muzzleAnchor, ejectionAnchor, muzzleFlash: flash, magRestPos: new THREE.Vector3(),
    magazineBody: null!, trigger: null! };
}

function seatMagazine(g: GunModel, handPosition: THREE.Vector3) {
  // Both magazines are direct children of gunBody. The socket is the only
  // source of the seated transform, so grip parenting cannot double-offset it.
  g.magRestPos.copy(g.magazineSocket.position);
  g.magGroup.position.copy(g.magRestPos);
  g.magGroup.quaternion.copy(g.magazineSocket.quaternion);
  g.magazineGrip.position.copy(handPosition).sub(g.magRestPos)
    .applyQuaternion(g.magazineSocket.quaternion.clone().invert());
  g.muzzleFlash.position.copy(g.muzzleAnchor.position);
  batchRigidParts(g.gunBody);
}

function cartridge(parent: THREE.Object3D, m: GunMaterials, x: number, y: number, z: number, pistol = false) {
  const casingLength = pistol ? 0.019 : 0.035;
  cylinder(parent, m.brass, 0.0045, casingLength, [x, y, z], 'z', 16);
  cylinder(parent, m.brass, 0.0049, 0.0015, [x, y, z + casingLength / 2], 'z', 16);
  const tip = mesh(parent, pistol ? new THREE.SphereGeometry(0.0044, 16, 10) : new THREE.ConeGeometry(0.0043, 0.014, 16), m.copper,
    [x, y, z - casingLength / 2 - (pistol ? 0.0025 : 0.006)]);
  if (!pistol) tip.rotation.x = -Math.PI / 2;
}

function rail(parent: THREE.Object3D, m: GunMaterials, start: number, end: number) {
  roundedBox(parent, m.darkMetal, [0.025, 0.004, end - start], [0, 0.037, -(start + end) / 2], 0.0006);
  for (let forward = start + 0.004; forward < end; forward += 0.01) {
    // Chamfered cross-section rather than a row of square blocks.
    const cross = polygon([[-0.0115, 0], [0.0115, 0], [0.0125, 0.0012], [0.01, 0.0035], [-0.01, 0.0035], [-0.0125, 0.0012]]);
    const tooth = mesh(parent, extrusion(cross, 0.0056, 0.00025), m.darkMetal, [0, 0.039, -forward]);
    tooth.castShadow = true;
  }
}

function holoSight(parent: THREE.Object3D, m: GunMaterials) {
  const mount = group(parent, 'holographic-sight');
  roundedBox(mount, m.darkMetal, [0.05, 0.008, 0.085], [0, 0.046, -0.015], 0.0018);
  roundedBox(mount, m.polymer, [0.045, 0.015, 0.028], [0, 0.056, 0.038], 0.002);
  const hoodShape = roundedRect(-0.03, -0.026, 0.06, 0.053, 0.010);
  cutHole(hoodShape, roundedRect(-0.023, -0.019, 0.046, 0.039, 0.0065));
  mesh(mount, extrusion(hoodShape, 0.051, 0.0011), m.receiver, [0, 0.08, -0.014], 'optic-open-hood');
  const bezel = roundedRect(-0.025, -0.021, 0.05, 0.043, 0.008);
  cutHole(bezel, roundedRect(-0.0225, -0.0185, 0.045, 0.038, 0.006));
  mesh(mount, extrusion(bezel, 0.0018, 0.0002), m.rubber, [0, 0.08, 0.013]);
  mesh(mount, new THREE.PlaneGeometry(0.044, 0.037), m.glass, [0, 0.08, -0.005]).castShadow = false;
  cylinder(mount, m.darkMetal, 0.006, 0.005, [0.032, 0.065, -0.001], 'x');
  screw(mount, m.steel, [0.035, 0.065, -0.001], 0.004, 'x');
  screw(mount, m.darkMetal, [-0.031, 0.056, -0.024], 0.0032, 'x');
  for (const x of [-0.009, 0.009]) roundedBox(mount, m.rubber, [0.011, 0.004, 0.01], [x, 0.065, 0.034], 0.0015);
  engraving(mount, ['REFLEX', '1 x  /  01'], [-0.0312, 0.071, -0.01], [0.033, 0.015], -1);

  const canvas = document.createElement('canvas');
  canvas.width = canvas.height = 256;
  const ctx = canvas.getContext('2d')!;
  ctx.strokeStyle = '#ff3020';
  ctx.lineWidth = 3;
  ctx.shadowBlur = 6;
  ctx.shadowColor = '#ff2515';
  ctx.beginPath(); ctx.arc(128, 128, 60, 0, Math.PI * 2); ctx.stroke();
  ctx.fillStyle = '#ff4934';
  ctx.beginPath(); ctx.arc(128, 128, 3, 0, Math.PI * 2); ctx.fill();
  const material = new THREE.MeshBasicMaterial({ map: new THREE.CanvasTexture(canvas), transparent: true, blending: THREE.AdditiveBlending, depthWrite: false, toneMapped: false });
  mesh(mount, new THREE.PlaneGeometry(0.026, 0.026), material, [0, 0.08, 0.01], 'reticle').castShadow = false;
  return material;
}

export function createAR15Model(m: GunMaterials = createGunMaterials()): GunModel {
  const g = makeBase('AR-15');
  const b = g.gunBody;

  const upper = polygon([[-0.122, 0.005], [-0.122, 0.025], [-0.112, 0.034], [0.092, 0.034], [0.106, 0.025], [0.107, -0.006], [-0.108, -0.006]]);
  // Real solid forged receiver core with thin, separate side faces. The older
  // pair of narrow extrusions left a hollow center, so the gun read as two
  // plates instead of a receiver.
  sideProfile(b, m.receiver, upper, 0.039, 0, 0.0018, 'ar15-upper-core');
  sideProfile(b, m.darkMetal, upper, 0.0016, -0.0203, 0.0008, 'ar15-left-side');
  const ejectionSide = upper.clone();
  cutHole(ejectionSide, roundedRect(-0.023, 0.005, 0.073, 0.022, 0.0035));
  sideProfile(b, m.receiver, ejectionSide, 0.0016, 0.0203, 0.0005, 'ar15-ejection-wall');
  roundedBox(b, m.receiver, [0.035, 0.006, 0.222], [0, 0.0305, 0.005], 0.0015);
  roundedBox(b, m.darkMetal, [0.035, 0.006, 0.222], [0, -0.003, 0.005], 0.0013);
  // Recessed port liner and correctly outward-facing bolt face on the right.
  roundedBox(b, m.inset, [0.001, 0.014, 0.060], [0.0192, 0.015, -0.014], 0.0015, 'ejection-recess');
  cylinder(g.boltOrSlide, m.steel, 0.011, 0.078, [0.006, 0.015, 0.004], 'z');
  roundedBox(g.boltOrSlide, m.steel, [0.0014, 0.010, 0.044], [0.0198, 0.015, -0.017], 0.0006, 'bolt-face');
  const cover = group(b, 'dust-cover');
  cover.position.set(0.024, 0.002, -0.014);
  cover.rotation.z = -1.15;
  roundedBox(cover, m.darkMetal, [0.002, 0.018, 0.071], [0, -0.008, 0], 0.0011);
  cylinder(b, m.steel, 0.0015, 0.073, [0.023, 0.001, -0.014]);
  sideProfile(b, m.receiver, polygon([[-0.048, 0.027], [-0.031, 0.02], [-0.027, 0.005], [-0.052, 0.005]]), 0.013, 0.023, 0.0015);
  const assist = cylinder(b, m.receiver, 0.008, 0.036, [0.024, 0.015, 0.081]);
  assist.rotation.y = 0.35;
  cylinder(b, m.darkMetal, 0.0075, 0.009, [0.030, 0.015, 0.101]);
  roundedBox(g.chargingOrHammer, m.darkMetal, [0.012, 0.005, 0.054], [0, 0.031, 0.119], 0.001);
  roundedBox(g.chargingOrHammer, m.darkMetal, [0.053, 0.009, 0.013], [0, 0.031, 0.143], 0.002);
  roundedBox(g.chargingOrHammer, m.darkMetal, [0.009, 0.011, 0.027], [-0.025, 0.027, 0.133], 0.002);

  sideProfile(b, m.receiver, polygon([[-0.119, -0.006], [0.007, -0.006], [0.007, -0.041], [-0.049, -0.042], [-0.065, -0.036], [-0.107, -0.038], [-0.12, -0.026]]), 0.039, 0, 0.0018, 'ar15-lower');
  const well = roundedRect(-0.022, -0.039, 0.044, 0.078, 0.004);
  cutHole(well, roundedRect(-0.0155, -0.032, 0.031, 0.064, 0.0025));
  const wellGeo = extrusion(well, 0.066, 0.0008);
  wellGeo.rotateX(Math.PI / 2);
  mesh(b, wellGeo, m.receiver, [0, -0.038, -0.046], 'ar15-magwell');
  const mouth = roundedRect(-0.024, -0.041, 0.048, 0.082, 0.005);
  cutHole(mouth, roundedRect(-0.0157, -0.0322, 0.0314, 0.0644, 0.0025));
  const mouthGeo = extrusion(mouth, 0.005, 0.0006);
  mouthGeo.rotateX(Math.PI / 2);
  mesh(b, mouthGeo, m.receiver, [0, -0.0715, -0.046], 'ar15-magwell-lip');

  const guard = roundedRect(-0.055, -0.073, 0.063, 0.037, 0.012);
  cutHole(guard, roundedRect(-0.049, -0.067, 0.052, 0.027, 0.008));
  sideProfile(b, m.darkMetal, guard, 0.014, 0, 0.0008);
  const triggerShape = new THREE.Shape();
  triggerShape.moveTo(-0.019, -0.039);
  triggerShape.bezierCurveTo(-0.014, -0.05, -0.024, -0.064, -0.029, -0.064);
  triggerShape.lineTo(-0.032, -0.06);
  triggerShape.bezierCurveTo(-0.026, -0.057, -0.021, -0.047, -0.025, -0.04);
  triggerShape.closePath();
  g.trigger = sideProfile(b, m.steel, triggerShape, 0.0055, 0, 0.0005, 'trigger');
  // Keep the animation pivot at the trigger pin, not at world origin.
  g.trigger.geometry.translate(0, 0.047, -0.022);
  g.trigger.position.set(0, -0.047, 0.022);

  const gripShape = new THREE.Shape();
  gripShape.moveTo(-0.061, -0.035);
  gripShape.lineTo(-0.091, -0.035);
  gripShape.bezierCurveTo(-0.093, -0.069, -0.125, -0.131, -0.113, -0.147);
  gripShape.lineTo(-0.079, -0.147);
  gripShape.bezierCurveTo(-0.069, -0.116, -0.049, -0.066, -0.049, -0.044);
  gripShape.closePath();
  sideProfile(b, m.polymer, gripShape, 0.031, 0, 0.0035, 'ar15-grip');
  const panel = polygon([[-0.067, -0.064], [-0.088, -0.062], [-0.112, -0.135], [-0.084, -0.137]]);
  for (const side of [-1, 1]) sideProfile(b, m.stipple, panel, 0.0012, side * 0.016, 0.00045);
  for (const z of [-0.092, 0.101]) for (const side of [-1, 1]) screw(b, m.darkMetal, [side * 0.022, -0.017, z], 0.0032);
  cylinder(b, m.darkMetal, 0.006, 0.004, [-0.023, -0.023, 0.073], 'x');
  roundedBox(b, m.darkMetal, [0.004, 0.006, 0.026], [-0.025, -0.026, 0.084], 0.001);
  roundedBox(b, m.darkMetal, [0.005, 0.011, 0.012], [0.024, -0.03, -0.003], 0.002);
  roundedBox(b, m.darkMetal, [0.006, 0.023, 0.011], [-0.025, -0.006, -0.006], 0.0014);
  engraving(b, ['AR-15', 'CAL. 5.56', 'A150024'], [-0.0225, -0.044, -0.047], [0.045, 0.027], -1);
  engraving(b, ['SAFE  FIRE'], [-0.0235, -0.012, 0.073], [0.042, 0.009], -1);

  g.stockAssembly = group(b, 'adjustable-stock');
  cylinder(b, m.darkMetal, 0.019, 0.012, [0, 0.010, 0.128]);
  cylinder(g.stockAssembly, m.darkMetal, 0.015, 0.205, [0, 0.010, 0.227]);
  const stockShape = polygon([[-0.182, 0.031], [-0.333, 0.031], [-0.338, -0.079], [-0.311, -0.074], [-0.215, -0.02], [-0.181, -0.018]]);
  cutHole(stockShape, polygon([[-0.237, -0.024], [-0.311, -0.024], [-0.311, -0.061]]));
  sideProfile(g.stockAssembly, m.polymer, stockShape, 0.039, 0, 0.0022);
  roundedBox(g.stockAssembly, m.polymer, [0.037, 0.015, 0.123], [0, 0.029, 0.263], 0.004);
  roundedBox(g.stockAssembly, m.darkMetal, [0.012, 0.009, 0.052], [0, -0.022, 0.224], 0.002);
  g.stockPad = roundedBox(g.stockAssembly, m.rubber, [0.046, 0.113, 0.016], [0, -0.023, 0.342], 0.005, 'stock-contact-pad');
  for (let i = 0; i < 10; i++) roundedBox(g.stockAssembly, m.polymer, [0.043, 0.0013, 0.002], [0, -0.071 + i * 0.01, 0.350], 0.0003);
  tube(g.stockAssembly, m.darkMetal, 0.0055, 0.0036, 0.002, [-0.021, 0.006, 0.293], 'x');
  screw(g.stockAssembly, m.darkMetal, [0.022, 0.006, 0.293], 0.004);

  // The side panels have real openings. There is no cylinder or black decal
  // behind the M-LOK slots; the inner barrel is visible through the rail.
  const handguard = group(b, 'mlok-handguard');
  for (const side of [-1, 1]) {
    const panelShape = roundedRect(0.11, -0.011, 0.355, 0.043, 0.003);
    for (let i = 0; i < 7; i++) {
      cutHole(panelShape, roundedRect(0.131 + i * 0.047, -0.006, 0.032, 0.007, 0.002));
      cutHole(panelShape, roundedRect(0.131 + i * 0.047, 0.019, 0.032, 0.007, 0.002));
    }
    sideProfile(handguard, m.receiver, panelShape, 0.0025, side * 0.0235, 0.00035);
    roundedBox(handguard, m.receiver, [0.011, 0.0025, 0.356], [side * 0.019, 0.033, -0.287], 0.0005).rotation.z = side * -0.65;
    roundedBox(handguard, m.receiver, [0.01, 0.0025, 0.356], [side * 0.019, -0.013, -0.287], 0.0005).rotation.z = side * 0.65;
    screw(handguard, m.darkMetal, [side * 0.025, 0.010, -0.12], 0.0035);
  }
  const bottom = roundedRect(-0.015, 0.11, 0.03, 0.355, 0.002);
  for (let i = 0; i < 7; i++) cutHole(bottom, roundedRect(-0.004, 0.132 + i * 0.047, 0.008, 0.031, 0.002));
  const bottomGeo = extrusion(bottom, 0.0025, 0.0003);
  bottomGeo.rotateX(-Math.PI / 2);
  mesh(handguard, bottomGeo, m.receiver, [0, -0.016, 0]);
  roundedBox(handguard, m.receiver, [0.033, 0.003, 0.355], [0, 0.036, -0.287], 0.0007);
  const end = polygon([[-0.017, -0.027], [0.017, -0.027], [0.025, -0.019], [0.025, 0.019], [0.017, 0.027], [-0.017, 0.027], [-0.025, 0.019], [-0.025, -0.019]]);
  cutHole(end, roundedRect(-0.0205, -0.022, 0.041, 0.044, 0.006));
  mesh(handguard, extrusion(end, 0.004, 0.00035), m.receiver, [0, 0.01, -0.464]);
  rail(b, m, -0.109, 0.46);
  cylinder(b, m.barrel, 0.008, 0.456, [0, 0.011, -0.311]);
  cylinder(b, m.darkMetal, 0.017, 0.016, [0, 0.011, -0.11]);
  roundedBox(b, m.barrel, [0.022, 0.022, 0.024], [0, 0.016, -0.37], 0.003);
  cylinder(b, m.steel, 0.002, 0.265, [0, 0.025, -0.235], 'z', 16);
  tube(b, m.darkMetal, 0.012, 0.005, 0.009, [0, 0.011, -0.537]);
  tube(b, m.barrel, 0.012, 0.005, 0.008, [0, 0.011, -0.571]);
  for (let i = 0; i < 6; i++) {
    const angle = i / 6 * Math.PI * 2;
    const strut = roundedBox(b, m.darkMetal, [0.004, 0.004, 0.033], [Math.cos(angle) * 0.01, 0.011 + Math.sin(angle) * 0.01, -0.554], 0.0007);
    strut.rotation.z = angle;
  }

  // Low-profile flip-up front sight, sized to stay behind the muzzle device.
  {
    const buis = group(b, 'front-buis');
    buis.position.set(0, 0.042, -0.415);
    roundedBox(buis, m.darkMetal, [0.021, 0.006, 0.028], [0, 0.002, 0], 0.002);
    roundedBox(buis, m.darkMetal, [0.005, 0.017, 0.006], [0, 0.012, -0.003], 0.002);
    cylinder(buis, m.steel, 0.004, 0.003, [0, 0.016, -0.003], 'x', 16);
  }
  // Folded rear aperture sits low on the top rail rather than becoming a
  // second raised tower behind the holographic sight.
  roundedBox(b, m.darkMetal, [0.024, 0.003, 0.016], [0, 0.042, 0.078], 0.0015);

  g.reticleMat = holoSight(b, m);

  // Feed lips sit nearly flush with the magwell's open top, making the
  // inserted magazine visibly continuous with the receiver from the sides.
  g.magazineSocket.position.set(0, -0.033, -0.046);
  g.magazineBody = mesh(g.magGroup, magazineBody({ top: 0.023, bottom: -0.153, width: 0.0275, depth: 0.058, curve: -0.024, ribs: true }), m.magazine, [0, 0, 0], 'ar15-magazine-shell');
  for (const side of [-1, 1]) {
    for (const z of [-0.018, 0.018]) curveStrip(g.magGroup, m.magazine,
      Array.from({ length: 8 }, (_, i) => [side * 0.0137, -0.035 - i * 0.015, z - 0.024 * Math.pow(i / 7, 1.65)]), 0.00055);
    roundedBox(g.magGroup, m.steel, [0.003, 0.008, 0.044], [side * 0.0115, 0.024, 0.003], 0.0008);
  }
  roundedBox(g.magGroup, m.darkMetal, [0.0305, 0.007, 0.063], [0, -0.155, -0.024], 0.0013, 'magazine-floorplate');
  // Subtle recessed witness marks, not raised details that read as rungs.
  for (let i = 0; i < 5; i++) {
    const y = -0.045 - i * 0.024;
    const z = -0.024 * Math.pow(Math.max(0, (-y - 0.023) / 0.176), 1.65) + 0.01;
    cylinder(g.magGroup, m.inset, 0.00125, 0.0005, [-0.01405, y, z], 'x', 12);
  }
  cartridge(g.magGroup, m, 0.0047, 0.024, 0.003);
  cartridge(g.magGroup, m, -0.0047, 0.022, 0.003);
  engraving(g.magGroup, ['5.56', '30'], [-0.014, -0.12, -0.018], [0.022, 0.025], -1);

  g.muzzleAnchor.position.set(0, 0.011, -0.578);
  g.ejectionAnchor.position.set(0.026, 0.016, -0.012);
  seatMagazine(g, new THREE.Vector3(-0.042, -0.11, -0.01));
  return g;
}

export function createGlock17Model(m: GunMaterials = createGunMaterials()): GunModel {
  const g = makeBase('Glock-17');
  const b = g.gunBody;
  const frame = new THREE.Shape();
  frame.moveTo(-0.079, 0.004);
  frame.lineTo(0.115, 0.004);
  frame.lineTo(0.115, -0.017);
  frame.lineTo(0.039, -0.017);
  frame.quadraticCurveTo(0.029, -0.020, 0.029, -0.039);
  frame.quadraticCurveTo(0.027, -0.053, 0.016, -0.053);
  frame.lineTo(-0.028, -0.053);
  frame.lineTo(-0.054, -0.122);
  frame.quadraticCurveTo(-0.055, -0.128, -0.063, -0.128);
  frame.lineTo(-0.102, -0.126);
  frame.quadraticCurveTo(-0.108, -0.124, -0.105, -0.116);
  frame.lineTo(-0.076, -0.033);
  frame.quadraticCurveTo(-0.074, -0.02, -0.086, -0.017);
  frame.lineTo(-0.088, -0.009);
  frame.closePath();
  cutHole(frame, roundedRect(-0.026, -0.045, 0.049, 0.025, 0.008));
  sideProfile(b, m.polymer, frame, 0.029, 0, 0.0021, 'glock-frame');
  const stipple = polygon([[-0.036, -0.054], [-0.072, -0.043], [-0.099, -0.116], [-0.059, -0.118]]);
  for (const side of [-1, 1]) sideProfile(b, m.stipple, stipple, 0.0009, side * 0.0152, 0.0003, `glock-grip-panel-${side}`);
  engraving(b, ['GLOCK'], [-0.0159, -0.066, 0.063], [0.02, 0.012], -1);
  for (const y of [-0.067, -0.088, -0.108]) {
    roundedBox(b, m.polymer, [0.026, 0.005, 0.005], [0, y, 0.034 + (-y - 0.05) * 0.35], 0.002);
  }
  roundedBox(b, m.darkMetal, [0.004, 0.008, 0.012], [-0.016, -0.025, 0.025], 0.001);
  roundedBox(b, m.darkMetal, [0.003, 0.006, 0.02], [-0.016, -0.002, 0.024], 0.001);
  for (const side of [-1, 1]) roundedBox(b, m.darkMetal, [0.003, 0.007, 0.008], [side * 0.015, -0.006, -0.008], 0.0008);
  for (const z of [0.019, 0.049]) for (const side of [-1, 1]) cylinder(b, m.darkMetal, 0.002, 0.0015, [side * 0.0154, -0.01, z], 'x', 16);
  for (const z of [-0.074, -0.092]) roundedBox(b, m.inset, [0.021, 0.001, 0.004], [0, -0.0188, z], 0.00025);

  const triggerShape = new THREE.Shape();
  triggerShape.moveTo(-0.008, -0.018);
  triggerShape.bezierCurveTo(0.001, -0.027, -0.004, -0.038, -0.012, -0.043);
  triggerShape.lineTo(-0.016, -0.038);
  triggerShape.quadraticCurveTo(-0.007, -0.026, -0.014, -0.021);
  triggerShape.closePath();
  g.trigger = sideProfile(b, m.polymer, triggerShape, 0.007, 0, 0.0006, 'trigger');
  g.trigger.geometry.translate(0, 0.022, -0.004);
  g.trigger.position.set(0, -0.022, 0.004);
  roundedBox(g.trigger, m.darkMetal, [0.0018, 0.012, 0.003], [0, -0.010, 0.005], 0.0004);

  // The slide is a shell: open barrel channel, actual ejection window and
  // machined serrations. The barrel stays on the frame when the slide cycles.
  const slide = g.boltOrSlide;
  slide.name = 'glock-slide';
  for (const side of [-1, 1]) {
    const wall = polygon([[-0.074, 0.006], [0.119, 0.006], [0.119, 0.024], [0.112, 0.0305], [-0.067, 0.0305], [-0.074, 0.026]]);
    if (side === 1) cutHole(wall, roundedRect(-0.018, 0.014, 0.046, 0.020, 0.003));
    for (let i = 0; i < 8; i++) cutHole(wall, roundedRect(-0.066 + i * 0.0046, 0.009, 0.0013, 0.017, 0.0004));
    // Front cocking serrations, machined into the same wall
    for (let i = 0; i < 4; i++) cutHole(wall, roundedRect(0.102 - i * 0.0044, 0.010, 0.0013, 0.013, 0.0004));
    sideProfile(slide, m.slide, wall, 0.0041, side * 0.012, 0.0005);
    roundedBox(slide, m.darkMetal, [0.001, 0.017, 0.04], [side * 0.0099, 0.0175, 0.048], 0.00025);
  }
  const roof = roundedRect(-0.0105, -0.071, 0.021, 0.188, 0.002);
  cutHole(roof, roundedRect(-0.007, -0.018, 0.019, 0.046, 0.0025));
  const roofGeo = extrusion(roof, 0.0025, 0.0004);
  roofGeo.rotateX(-Math.PI / 2);
  mesh(slide, roofGeo, m.slide, [0, 0.030, 0]);
  for (const side of [-1, 1]) roundedBox(slide, m.slide, [0.006, 0.003, 0.182], [side * 0.0106, 0.0288, -0.023], 0.0006).rotation.z = side * -0.65;
  const front = roundedRect(-0.014, 0.0015, 0.028, 0.031, 0.004);
  const bore = new THREE.Path(); bore.absarc(0, 0.016, 0.0076, 0, Math.PI * 2, true); front.holes.push(bore);
  const rod = new THREE.Path(); rod.absarc(0, 0.005, 0.0033, 0, Math.PI * 2, true); front.holes.push(rod);
  mesh(slide, extrusion(front, 0.0035, 0.0003), m.slide, [0, 0, -0.118]);
  roundedBox(slide, m.darkMetal, [0.024, 0.024, 0.003], [0, 0.0165, 0.072], 0.002);
  roundedBox(slide, m.darkMetal, [0.017, 0.017, 0.0012], [0, 0.014, 0.074], 0.002);
  roundedBox(slide, m.barrel, [0.002, 0.005, 0.021], [0.0142, 0.019, 0.014], 0.0006);
  engraving(slide, ['GLOCK  17', 'AUSTRIA   9 x 19'], [-0.0142, 0.019, -0.052], [0.059, 0.018], -1);
  engraving(slide, ['G17  02486'], [0.0142, 0.010, -0.045], [0.042, 0.008]);
  tube(b, m.barrel, 0.0069, 0.0045, 0.143, [0, 0.016, -0.047]);
  roundedBox(b, m.barrel, [0.018, 0.014, 0.042], [0, 0.022, 0.004], 0.001, 'glock-chamber');
  cylinder(b, m.steel, 0.0028, 0.132, [0, 0.005, -0.048]);
  cylinder(b, m.darkMetal, 0.0031, 0.004, [0, 0.005, -0.116]);
  for (let i = 0; i < 18; i++) {
    tube(b, m.barrel, 0.0042, 0.003, 0.001, [0, 0.005, -0.018 - i * 0.0045]);
  }
  // The notch opens at the top, unlike an enclosed decorative cutout.
  const rearOutline = polygon([[-0.012, 0.031], [0.012, 0.031], [0.012, 0.039], [0.003, 0.039], [0.003, 0.034], [-0.003, 0.034], [-0.003, 0.039], [-0.012, 0.039]]);
  mesh(slide, extrusion(rearOutline, 0.008, 0.0003), m.darkMetal, [0, 0, 0.061]);
  for (const side of [-1, 1]) roundedBox(slide, m.sightPaint, [0.0012, 0.0042, 0.0004], [side * 0.0044, 0.0365, 0.0655], 0.00015);
  roundedBox(slide, m.sightPaint, [0.0095, 0.0011, 0.0004], [0, 0.0348, 0.0655], 0.00015);
  roundedBox(slide, m.darkMetal, [0.0042, 0.008, 0.009], [0, 0.035, -0.106], 0.0007);
  mesh(slide, new THREE.CircleGeometry(0.00145, 20), m.sightPaint, [0, 0.0365, -0.1013]);

  // ===== High-detail hardware pass =====
  // Rounded slide-stop and takedown-lever tips (left side)
  cylinder(b, m.steel, 0.0024, 0.005, [-0.0162, -0.025, 0.025], 'x', 14);
  cylinder(b, m.steel, 0.0021, 0.005, [-0.0162, -0.002, 0.024], 'x', 14);
  // Round magazine-release button
  cylinder(b, m.steel, 0.0026, 0.0032, [-0.016, -0.012, 0.018], 'x', 16);
  // Two frame pins + grip screws
  for (const z of [0.03, 0.062]) cylinder(b, m.steel, 0.0018, 0.033, [0, -0.004, z], 'x', 12);
  cylinder(b, m.steel, 0.002, 0.002, [-0.015, -0.075, 0.02], 'x', 10);
  cylinder(b, m.steel, 0.002, 0.002, [-0.015, -0.102, 0.031], 'x', 10);
  // Barrel crown ring at the muzzle + recoil-spring front plug
  tube(b, m.barrel, 0.0069, 0.005, 0.0022, [0, 0.016, -0.118]);
  cylinder(b, m.darkMetal, 0.003, 0.004, [0, 0.005, -0.114], 'z', 14);
  // Slide rear takedown latch
  roundedBox(slide, m.darkMetal, [0.026, 0.02, 0.011], [0, 0.017, 0.068], 0.003);
  // Muzzle bevel ring
  tube(slide, m.slide, 0.013, 0.0105, 0.002, [0, 0.016, -0.1175]);

  g.magazineSocket.position.set(0, -0.027, 0.057);
  g.magazineSocket.rotation.x = -0.29;
  g.magazineBody = mesh(g.magGroup, magazineBody({ top: 0.016, bottom: -0.091, width: 0.022, depth: 0.033, curve: 0 }), m.darkMetal, [0, 0, 0], 'glock-magazine-shell');
  roundedBox(g.magGroup, m.polymer, [0.0295, 0.007, 0.045], [0, -0.094, 0.001], 0.0018, 'glock-magazine-baseplate');
  for (const side of [-1, 1]) roundedBox(g.magGroup, m.barrel, [0.003, 0.008, 0.023], [side * 0.009, 0.016, 0], 0.0007);
  // Vertical row of witness holes on the magazine front face
  for (let i = 0; i < 5; i++) {
    cylinder(g.magGroup, m.inset, 0.0017, 0.0016, [0, -0.005 - i * 0.019, -0.0167], 'z', 12);
  }
  cartridge(g.magGroup, m, 0.002, 0.016, 0.001, true);
  g.muzzleAnchor.position.set(0, 0.016, -0.122);
  g.ejectionAnchor.position.set(0.017, 0.024, 0.004);
  seatMagazine(g, new THREE.Vector3(-0.014, -0.155, 0.104));
  return g;
}