import * as THREE from 'three';
import { RoundedBoxGeometry } from 'three/addons/geometries/RoundedBoxGeometry.js';

/**
 * 3D Tactical Field Recording Camera on a Tripod:
 * - Placed in the arena when the player presses [H]
 * - Smoothly pans/tilts its fluid head to frame the player
 * - Contains a PerspectiveCamera at the front glass element to record clips for [I] playback
 */
export class TacticalRecordingCamera {
  public readonly root = new THREE.Group();
  public readonly panGroup = new THREE.Group();
  public readonly tiltGroup = new THREE.Group();
  public readonly renderCam: THREE.PerspectiveCamera;

  private readonly tallyFrontMat: THREE.MeshBasicMaterial;
  private readonly tallyRearMat: THREE.MeshBasicMaterial;
  private readonly tallyLight: THREE.PointLight;
  private readonly screenCanvas: HTMLCanvasElement;
  private readonly screenCtx: CanvasRenderingContext2D;
  private readonly screenTex: THREE.CanvasTexture;

  public isPlaced = false;
  private blinkTime = 0;

  constructor() {
    this.root.name = 'TacticalRecordingCamera';
    this.root.visible = false;

    const darkMetal = new THREE.MeshStandardMaterial({
      color: 0x1b1f26,
      metalness: 0.82,
      roughness: 0.32,
    });
    const bodyCharcoal = new THREE.MeshStandardMaterial({
      color: 0x262b33,
      metalness: 0.65,
      roughness: 0.42,
    });
    const chromeSteel = new THREE.MeshStandardMaterial({
      color: 0x94a3b8,
      metalness: 0.92,
      roughness: 0.2,
    });
    const crimsonAccent = new THREE.MeshStandardMaterial({
      color: 0xd93829,
      metalness: 0.35,
      roughness: 0.45,
    });
    const rubberMat = new THREE.MeshStandardMaterial({
      color: 0x111317,
      metalness: 0.1,
      roughness: 0.85,
    });
    const lensGlassMat = new THREE.MeshPhysicalMaterial({
      color: 0x1e3a5f,
      metalness: 0.1,
      roughness: 0.06,
      clearcoat: 1.0,
      clearcoatRoughness: 0.05,
      reflectivity: 0.95,
    });

    this.tallyFrontMat = new THREE.MeshBasicMaterial({ color: 0xff2a2a });
    this.tallyRearMat = new THREE.MeshBasicMaterial({ color: 0xff2a2a });

    // -------------------------------------------------------------------
    // 1. TACTICAL TRIPOD LEGS & CENTER COLUMN (y = 0.0m to 1.08m)
    // -------------------------------------------------------------------
    const hubY = 0.92;
    const hub = new THREE.Mesh(new THREE.CylinderGeometry(0.055, 0.062, 0.09, 16), darkMetal);
    hub.position.y = hubY;
    hub.castShadow = true;
    this.root.add(hub);

    const column = new THREE.Mesh(new THREE.CylinderGeometry(0.028, 0.028, 0.34, 14), chromeSteel);
    column.position.y = hubY + 0.14;
    column.castShadow = true;
    this.root.add(column);

    // 3 angled telescoping tripod legs
    const legLength = 1.02;
    for (let i = 0; i < 3; i++) {
      const angle = (i * Math.PI * 2) / 3 + Math.PI / 3;
      const legPivot = new THREE.Group();
      legPivot.position.set(Math.sin(angle) * 0.042, hubY, Math.cos(angle) * 0.042);
      legPivot.rotation.y = angle;
      legPivot.rotation.x = 0.34; // splay outward

      const upperLeg = new THREE.Mesh(
        new THREE.CylinderGeometry(0.016, 0.013, legLength, 10),
        darkMetal
      );
      upperLeg.position.y = -legLength / 2;
      upperLeg.castShadow = true;
      legPivot.add(upperLeg);

      const foot = new THREE.Mesh(new THREE.CylinderGeometry(0.022, 0.028, 0.04, 10), rubberMat);
      foot.position.y = -legLength + 0.02;
      legPivot.add(foot);

      this.root.add(legPivot);
    }

    // Mid-level stabilizer triangle spreader
    const spreader = new THREE.Mesh(new THREE.CylinderGeometry(0.19, 0.19, 0.014, 3), rubberMat);
    spreader.position.y = 0.48;
    this.root.add(spreader);

    // -------------------------------------------------------------------
    // 2. FLUID PAN / TILT CAMERA HEAD (y = 1.18m)
    // -------------------------------------------------------------------
    this.panGroup.position.set(0, 1.18, 0);
    this.root.add(this.panGroup);

    const panBase = new THREE.Mesh(new THREE.CylinderGeometry(0.048, 0.045, 0.05, 16), bodyCharcoal);
    this.panGroup.add(panBase);

    this.tiltGroup.position.set(0, 0.05, 0);
    this.panGroup.add(this.tiltGroup);

    // -------------------------------------------------------------------
    // 3. CINEMA / RECON CAMERA BODY, TELEPHOTO LENS & VIEWFINDER
    //    Local +Z points forward out of the lens!
    // -------------------------------------------------------------------
    const camBody = new THREE.Mesh(
      new RoundedBoxGeometry(0.15, 0.16, 0.24, 3, 0.018),
      bodyCharcoal
    );
    camBody.castShadow = true;
    this.tiltGroup.add(camBody);

    // Red tactical side accent stripes
    const sideAccentL = new THREE.Mesh(new THREE.BoxGeometry(0.006, 0.032, 0.19), crimsonAccent);
    sideAccentL.position.set(0.076, 0.01, 0);
    const sideAccentR = sideAccentL.clone();
    sideAccentR.position.x = -0.076;
    this.tiltGroup.add(sideAccentL, sideAccentR);

    // Top carry handle + directional shotgun mic
    const handleArch = new THREE.Mesh(
      new RoundedBoxGeometry(0.032, 0.045, 0.17, 2, 0.008),
      darkMetal
    );
    handleArch.position.set(0, 0.105, -0.01);
    this.tiltGroup.add(handleArch);

    const shotgunMic = new THREE.Mesh(
      new THREE.CylinderGeometry(0.012, 0.012, 0.19, 10),
      rubberMat
    );
    shotgunMic.rotation.x = Math.PI / 2;
    shotgunMic.position.set(0.045, 0.105, 0.05);
    this.tiltGroup.add(shotgunMic);

    // Telephoto lens barrel + matte box hood (pointing along +Z)
    const lensBarrel = new THREE.Mesh(
      new THREE.CylinderGeometry(0.052, 0.056, 0.14, 20),
      darkMetal
    );
    lensBarrel.rotation.x = Math.PI / 2;
    lensBarrel.position.set(0, 0, 0.17);
    lensBarrel.castShadow = true;
    this.tiltGroup.add(lensBarrel);

    const focusRing = new THREE.Mesh(
      new THREE.CylinderGeometry(0.056, 0.056, 0.025, 20),
      chromeSteel
    );
    focusRing.rotation.x = Math.PI / 2;
    focusRing.position.set(0, 0, 0.165);
    this.tiltGroup.add(focusRing);

    const matteBox = new THREE.Mesh(
      new RoundedBoxGeometry(0.135, 0.11, 0.045, 2, 0.008),
      rubberMat
    );
    matteBox.position.set(0, 0, 0.245);
    this.tiltGroup.add(matteBox);

    const lensGlass = new THREE.Mesh(new THREE.CircleGeometry(0.046, 20), lensGlassMat);
    lensGlass.position.set(0, 0, 0.269);
    this.tiltGroup.add(lensGlass);

    // Front & Rear glowing REC Tally Lights
    const frontTally = new THREE.Mesh(
      new RoundedBoxGeometry(0.036, 0.016, 0.016, 2, 0.004),
      this.tallyFrontMat
    );
    frontTally.position.set(0, 0.068, 0.245);
    this.tiltGroup.add(frontTally);

    const rearTally = new THREE.Mesh(
      new THREE.SphereGeometry(0.01, 10, 10),
      this.tallyRearMat
    );
    rearTally.position.set(0, 0.055, -0.125);
    this.tiltGroup.add(rearTally);

    this.tallyLight = new THREE.PointLight(0xff2a2a, 1.2, 2.2);
    this.tallyLight.position.set(0, 0.08, 0.28);
    this.tiltGroup.add(this.tallyLight);

    // Flip-out side LCD monitor screen (on +X side of camera body)
    this.screenCanvas = document.createElement('canvas');
    this.screenCanvas.width = 128;
    this.screenCanvas.height = 80;
    this.screenCtx = this.screenCanvas.getContext('2d')!;
    this.screenTex = new THREE.CanvasTexture(this.screenCanvas);
    this.screenTex.colorSpace = THREE.SRGBColorSpace;
    this.drawLcdBadge(true);

    const lcdHousing = new THREE.Mesh(
      new RoundedBoxGeometry(0.11, 0.075, 0.012, 2, 0.004),
      darkMetal
    );
    lcdHousing.position.set(0.135, 0.01, -0.02);
    lcdHousing.rotation.y = -0.35;
    this.tiltGroup.add(lcdHousing);

    const lcdScreen = new THREE.Mesh(
      new THREE.PlaneGeometry(0.096, 0.062),
      new THREE.MeshBasicMaterial({ map: this.screenTex, side: THREE.DoubleSide })
    );
    lcdScreen.position.set(0, 0, 0.007);
    lcdHousing.add(lcdScreen);

    // -------------------------------------------------------------------
    // 4. LENS PERSPECTIVE CAMERA (placed just in front of lens glass)
    //    In Three.js, PerspectiveCamera looks down its local -Z, so we
    //    rotate it by Math.PI around Y so it looks out along +Z of tiltGroup!
    // -------------------------------------------------------------------
    this.renderCam = new THREE.PerspectiveCamera(58, 16 / 9, 0.1, 160);
    this.renderCam.position.set(0, 0, 0.28);
    this.renderCam.rotation.y = Math.PI;
    this.tiltGroup.add(this.renderCam);
  }

  private drawLcdBadge(recOn: boolean) {
    const ctx = this.screenCtx;
    ctx.fillStyle = '#0d131a';
    ctx.fillRect(0, 0, 128, 80);
    ctx.strokeStyle = '#38bdf8';
    ctx.lineWidth = 3;
    ctx.strokeRect(4, 4, 120, 72);

    if (recOn) {
      ctx.fillStyle = '#ef4444';
      ctx.beginPath();
      ctx.arc(24, 26, 7, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.fillStyle = '#f8fafc';
    ctx.font = 'bold 18px monospace';
    ctx.fillText('REC', 38, 32);
    ctx.fillStyle = '#38bdf8';
    ctx.font = 'bold 14px monospace';
    ctx.fillText('CAM-01 LIVE', 16, 58);
    this.screenTex.needsUpdate = true;
  }

  public placeAt(pos: THREE.Vector3, lookAtTarget: THREE.Vector3) {
    this.root.position.copy(pos);
    this.root.visible = true;
    this.isPlaced = true;
    this.blinkTime = 0;
    this.aimAt(lookAtTarget, 1.0);
  }

  public aimAt(targetWorld: THREE.Vector3, lerpFactor: number) {
    if (!this.isPlaced) return;

    const headWorld = new THREE.Vector3(
      this.root.position.x,
      this.root.position.y + 1.23,
      this.root.position.z
    );
    const dx = targetWorld.x - headWorld.x;
    const dy = targetWorld.y - headWorld.y;
    const dz = targetWorld.z - headWorld.z;
    const horizDist = Math.hypot(dx, dz);
    if (horizDist < 0.05) return;

    // Desired yaw so local +Z of panGroup points toward (dx, dz)
    const desiredYaw = Math.atan2(dx, dz);
    // Desired pitch so local +Z of tiltGroup tilts toward dy
    const desiredPitch = THREE.MathUtils.clamp(-Math.atan2(dy, horizDist), -0.65, 0.65);

    if (lerpFactor >= 0.99) {
      this.panGroup.rotation.y = desiredYaw;
      this.tiltGroup.rotation.x = desiredPitch;
    } else {
      // Shortest-angle angular interpolation for pan yaw
      let diff = desiredYaw - this.panGroup.rotation.y;
      while (diff > Math.PI) diff -= Math.PI * 2;
      while (diff < -Math.PI) diff += Math.PI * 2;
      this.panGroup.rotation.y += diff * lerpFactor;
      this.tiltGroup.rotation.x = THREE.MathUtils.lerp(
        this.tiltGroup.rotation.x,
        desiredPitch,
        lerpFactor
      );
    }
  }

  public update(dt: number, playerTorsoWorld: THREE.Vector3) {
    if (!this.isPlaced) return;

    // Smoothly pan/tilt the tripod fluid head to keep the player framed
    this.aimAt(playerTorsoWorld, Math.min(1, dt * 6.5));

    // Blink the REC tally light
    this.blinkTime += dt;
    const blinkOn = Math.floor(this.blinkTime * 2.5) % 2 === 0;
    this.tallyFrontMat.color.setHex(blinkOn ? 0xff2a2a : 0x551111);
    this.tallyRearMat.color.setHex(blinkOn ? 0xff2a2a : 0x551111);
    this.tallyLight.intensity = blinkOn ? 1.4 : 0.2;
  }
}
